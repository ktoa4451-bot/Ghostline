# What Ghostline connects to and stores

**No telemetry, no analytics, no update checks, no hidden requests.** Found by searching the sources for every network call:

| Connection | When | Data |
|---|---|---|
| `https://api.telegram.org` | only if you enter your own bot token + chat id and enable Telegram notifications (BaseFinder, TreeFarm, AutoWarden) | the notification text |
| the friends server you type in *FriendsHelp > Server URL* (https, or http only for localhost) | only while FriendsHelp is on | session token (Authorization header), your messages, status, help requests; coordinates only after your explicit confirmation |

Nothing else opens a network connection. Redirects are never followed, so a token cannot be forwarded to another address.

**Secrets:** tokens and the server address are stored encrypted (AES-GCM; key from a random salt file plus user name / OS / home path of this computer). That protects against a leaked or copied config, not against malware running as you on the same PC. Secrets are never written to share codes, `.cfg` files or named configs, and the mod writes no log lines of its own (no logger is used); its journals contain only findings and raid actions, never tokens or passwords.

**Local files:** `config/ghostline*.{properties,salt,txt,dat,log}` and `config/ghostline-configs/`. The findings and raid journals contain coordinates and your server address; delete them whenever you like.

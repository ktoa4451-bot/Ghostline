#!/usr/bin/env bash
# Checks the finished mod jar. Usage: bash tools/verify-jar.sh build/libs/ghostline-1.4.0.jar   (from the project root)
set -u
cd "$(dirname "$0")/.."
JAR="${1:-}"
[ -f "$JAR" ] || { echo "FAIL jar not found: $JAR"; exit 2; }
FAIL=0
bad() { echo "FAIL $*"; FAIL=1; }
ok() { echo "ok   $*"; }

LIST="$(unzip -Z1 "$JAR")" || { echo "FAIL not a zip/jar"; exit 2; }
has() { echo "$LIST" | grep -qxF "$1"; }
SIZE=$(stat -c%s "$JAR" 2>/dev/null || wc -c < "$JAR")
echo "jar: $JAR ($SIZE bytes)"
echo "sha256: $(sha256sum "$JAR" | cut -d' ' -f1)"

for f in fabric.mod.json ghostline.mixins.json assets/ghostline/icon.png assets/ghostline/textures/gui/logo.png assets/ghostline/textures/gui/logo_bg.png; do
  has "$f" && ok "contains $f" || bad "missing $f"
done

# fabric.mod.json: version substituted, id and entrypoint right
MOD="$(unzip -p "$JAR" fabric.mod.json)"
echo "$MOD" | grep -q '\${version}' && bad "fabric.mod.json still contains \${version} (resources were not expanded)" || ok "fabric.mod.json version expanded"
echo "$MOD" | grep -q '"id": *"ghostline"' && ok "mod id is ghostline" || bad "mod id is not ghostline"
echo "$MOD" | grep -q 'com.ghostline.mod.CheatMod' && ok "entrypoint declared" || bad "entrypoint missing in fabric.mod.json"
echo "$MOD" | grep -q '"minecraft": *"1.21.11"' && ok "targets Minecraft 1.21.11" || bad "Minecraft 1.21.11 dependency not found"

# every source class must be in the jar
MISSING=0
for s in $(find src/main/java -name '*.java'); do
  rel="${s#src/main/java/}"; cls="${rel%.java}.class"
  has "$cls" || { bad "class missing in jar: $cls"; MISSING=1; }
done
[ $MISSING -eq 0 ] && ok "all $(find src/main/java -name '*.java' | wc -l) source classes are in the jar"
# mixins listed in the config exist as classes
for m in $(unzip -p "$JAR" ghostline.mixins.json | grep -oE '"[A-Za-z]+Mixin"' | tr -d '"'); do
  has "com/ghostline/mod/mixin/$m.class" && ok "mixin class $m" || bad "mixin class $m missing"
done

# things that must NOT be in the mod jar
for pat in '\.js$' '^server/' '^tests/' '\.java$' 'data\.json' 'ghostline\.properties' 'ghostline\.salt' 'ghostline-session' '\.log$' '\.cfg$'; do
  if echo "$LIST" | grep -qE "$pat"; then bad "unexpected content matching '$pat': $(echo "$LIST" | grep -E "$pat" | head -3 | tr '\n' ' ')"; fi
done
echo "$LIST" | grep -qE '\.js$|^server/|^tests/|\.java$|data\.json|ghostline\.properties|ghostline\.salt|ghostline-session|\.log$|\.cfg$' || ok "no server, tests, sources, settings or logs inside the jar"
# no obvious secrets in text-like entries
if unzip -p "$JAR" 2>/dev/null | strings | grep -qiE 'bot[0-9]{6,}:[A-Za-z0-9_-]{30,}'; then bad "a Telegram bot token pattern was found in the jar"; else ok "no Telegram token pattern in the jar"; fi

[ $FAIL -eq 0 ] && echo "JAR OK" || echo "JAR CHECK FAILED"
exit $FAIL

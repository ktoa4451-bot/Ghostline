#!/usr/bin/env bash
# Runs the pure-Java test suites (no Minecraft, no Gradle needed): Java 21 and Node 18+ are enough.
# Usage: bash tools/run-tests.sh   (from the project root)
set -u
cd "$(dirname "$0")/.."
SRC=src/main/java/com/ghostline/mod
OUT="$(mktemp -d)"
FAILED=0
JAVAC="javac"; command -v javac >/dev/null 2>&1 || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"

run() { # name, test class, sources...
  local name="$1" cls="$2"; shift 2
  local dir="$OUT/$cls"; mkdir -p "$dir"
  local srcs=(); for s in "$@"; do srcs+=("$SRC/$s.java"); done
  if ! $JAVAC -d "$dir" "${srcs[@]}" "tests/$cls.java" 2> "$dir/compile.log"; then echo "FAIL  $name: compile error"; cat "$dir/compile.log"; FAILED=1; return; fi
  local res; res="$(timeout 180 java -cp "$dir" "$cls" 2>&1)"; local rc=$?
  echo "$res" | grep -E "FAIL|Exception" | head -20
  echo "$(echo "$res" | grep -E "passed," | tail -1)   <- $name"
  [ $rc -eq 0 ] || FAILED=1
}

run "config file format + secret store" CfgCodecSecretStoreTest CfgCodec SecretStore
run "saved bases"                        BasesTest Bases
run "HUD layout + notification queue"    HudLayoutToastQueueTest HudLayout ToastQueue
run "debounce / async / perf"            DebounceAsyncPerfTest Debounce Async Perf
run "menu layout over resolutions"       UiLayoutTest UiLayout
run "network client vs hostile servers"  NetworkHardeningTest MiniJson Async SocialClient

# friends server + client, end to end (needs Node)
if command -v node >/dev/null 2>&1; then
  DATA="$OUT/data.json"
  REG_PER_MIN=50 PORT=18787 DATA="$DATA" node server/ghostline-server.js > "$OUT/server.log" 2>&1 &
  SERVER_PID=$!
  sleep 2
  run "friends server + client (end to end)" FriendsProtocolTest MiniJson Async SocialClient
  kill "$SERVER_PID" 2>/dev/null
  if grep -qiE "pass|token|secret" "$OUT/server.log"; then echo "FAIL  server log mentions passwords/tokens"; FAILED=1; else echo "ok    server log contains no passwords or tokens ($(wc -l < "$OUT/server.log") lines)"; fi
else
  echo "SKIP  friends server test: node not found"
fi
[ $FAILED -eq 0 ] && echo "ALL SUITES PASSED" || echo "SOME SUITES FAILED"
exit $FAILED

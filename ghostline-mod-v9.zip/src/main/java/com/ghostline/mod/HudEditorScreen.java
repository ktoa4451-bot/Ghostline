package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/**
 * HUD editor: the real HUD is drawn live (with sample content for empty elements), every element can be dragged,
 * resized with the mouse wheel or the buttons, switched on/off and reset. Positions are stored as fractions of the
 * screen and saved with the config, so they survive restarts and window size changes.
 */
public final class HudEditorScreen extends GhostScreen {
    private String selected;
    private boolean dragging;
    private float grabX, grabY;
    private boolean guideV, guideH;
    private int toolbarY, toolbarH = 44, toolbarRows = 1;

    public HudEditorScreen() { super("HUD editor"); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    private float hs() { return Math.max(0.1f, Config.HUD.get(13).f()); }

    /** Element under a screen position (topmost first). */
    private String elementAt(double x, double y) {
        float s = hs();
        for (int i = HudLayout.IDS.length - 1; i >= 0; i--) {
            int[] b = Hud.BOUNDS.get(HudLayout.IDS[i]);
            if (b == null) continue;
            if (x >= b[0] * s && y >= b[1] * s && x < (b[0] + b[2]) * s && y < (b[1] + b[3]) * s) return HudLayout.IDS[i];
        }
        return null;
    }

    private void changeScale(String id, float delta) {
        int[] b = Hud.BOUNDS.get(id);
        HudLayout.Entry e = HudLayout.get(id);
        float old = e.scale, ns = HudLayout.clampScale(old + delta);
        if (ns == old) return;
        e.scale = ns;
        if (e.custom && b != null) { // keep the top-left corner where it is
            float s = hs();
            int sw = (int) (width / s), sh = (int) (height / s);
            int nw = Math.round(b[2] * ns / old), nh = Math.round(b[3] * ns / old);
            HudLayout.setPosition(e, b[0], b[1], nw, nh, sw, sh);
        }
        Config.save();
    }

    private void nudge(String id, int dx, int dy) {
        int[] b = Hud.BOUNDS.get(id);
        if (b == null) return;
        float s = hs();
        int sw = (int) (width / s), sh = (int) (height / s);
        int nx = Mth.clamp(b[0] + dx, 0, Math.max(0, sw - b[2])), ny = Mth.clamp(b[1] + dy, 0, Math.max(0, sh - b[3]));
        HudLayout.setPosition(HudLayout.get(id), nx, ny, b[2], b[3], sw, sh);
        Config.save();
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        beginFrame(mouseX, mouseY);
        Minecraft mc = Minecraft.getInstance();
        g.fill(0, 0, width, height, Ui.c(0x000000, 0.38f));
        toolbarRows = UiLayout.toolbarRows(width);   // two rows when the window is too narrow for one
        toolbarH = toolbarRows == 1 ? 44 : 66;
        toolbarY = height - toolbarH - 4;

        if (mc.player != null) Hud.drawHud(g, mc, true); // live preview with the current settings and positions

        float s = hs();
        String hover = dragging ? null : elementAt(mouseX, mouseY);
        for (String id : HudLayout.IDS) {
            int[] b = Hud.BOUNDS.get(id);
            if (b == null) continue;
            int x = Math.round(b[0] * s), y = Math.round(b[1] * s), w = Math.max(6, Math.round(b[2] * s)), h = Math.max(6, Math.round(b[3] * s));
            boolean sel = id.equals(selected);
            if (sel) {
                Ui.box(g, x - 2, y - 2, x + w + 2, y + h + 2, 1, Ui.c(Ui.accent(), 1f));
                int[] hx = {x - 3, x + w, x - 3, x + w}, hy = {y - 3, y - 3, y + h, y + h};
                for (int i = 0; i < 4; i++) g.fill(hx[i], hy[i], hx[i] + 3, hy[i] + 3, Ui.c(Ui.accent(), 1f));
                String name = Hud.label(id) + "  " + Math.round(HudLayout.get(id).scale * 100) + "%";
                int ty = y - 13 >= 2 ? y - 13 : y + h + 4;
                Ui.rect(g, x, ty, Ui.tw(name) + 8, 11, 3, Ui.c(Ui.bg(), 0.92f));
                Ui.text(g, name, x + 4, ty + 2, Ui.c(Ui.TEXT, 1f));
            } else if (id.equals(hover)) {
                Ui.box(g, x - 1, y - 1, x + w + 1, y + h + 1, 1, Ui.c(Ui.accent(), 0.55f));
            } else if (!Hud.elementOn(id)) {
                Ui.box(g, x - 1, y - 1, x + w + 1, y + h + 1, 1, Ui.c(Ui.MUTED, 0.35f));
            }
        }
        if (dragging) {
            if (guideV) g.fill(width / 2, 0, width / 2 + 1, height, Ui.c(Ui.accent(), 0.5f));
            if (guideH) g.fill(0, height / 2, width, height / 2 + 1, Ui.c(Ui.accent(), 0.5f));
        }
        drawToolbar(g);
    }

    private void drawToolbar(GuiGraphics g) {
        int y = toolbarY;
        Ui.rect(g, 4, y, width - 8, toolbarH, 7, Ui.c(Ui.bg(), 0.94f));
        Ui.ring(g, 4, y, width - 8, toolbarH, 7, Ui.c(Ui.border(), 0.95f));

        String info;
        if (selected == null) info = Lang.t("hed.hint");
        else {
            info = Hud.label(selected) + (Hud.elementOn(selected) ? "" : "  (" + Lang.t("hed.off") + ")");
            String gate = Hud.gate(selected);
            if (!gate.isEmpty() && Hud.elementOn(selected)) info += "  - " + String.format(Lang.t("hed.module_off"), gate);
        }
        Ui.text(g, Ui.ellipsize(info, width - 24), 12, y + 6, Ui.c(selected == null ? Ui.MUTED : Ui.TEXT, 1f));

        int bx = 10, by = y + 20, bh = 18;
        int by2 = toolbarRows == 1 ? by : by + 22;
        if (selected != null) {
            final String id = selected;
            boolean on = Hud.elementOn(id);
            button(g, "hedOn", bx, by, 54, bh, on ? Lang.t("hed.hide") : Lang.t("hed.show"), () -> Hud.setElementOn(id, !Hud.elementOn(id)));
            bx += 58;
            button(g, "hedMinus", bx, by, 22, bh, "-", () -> changeScale(id, -HudLayout.STEP));
            bx += 24;
            Ui.textC(g, Math.round(HudLayout.get(id).scale * 100) + "%", bx + 17, by + 5, Ui.c(Ui.TEXT, 1f));
            bx += 36;
            button(g, "hedPlus", bx, by, 22, bh, "+", () -> changeScale(id, HudLayout.STEP));
            bx += 26;
            button(g, "hedResetOne", bx, by, 62, bh, Lang.t("hed.reset_one"), () -> { HudLayout.reset(id); Config.save(); });
        }
        // right side
        int rx = width - 10;
        rx -= 50; button(g, "hedDone", rx, by2, 50, bh, Lang.t("hed.done"), this::onClose);
        boolean pend = pendingReset();
        rx -= 74; button(g, "hedResetAll", rx, by2, 70, bh, pend ? Lang.t("cfg.sure") : Lang.t("hed.reset_all"), () -> {
            if (!pend) { resetAt = System.currentTimeMillis(); return; }
            HudLayout.resetAll();
            Config.save();
            selected = null;
        });
        rx -= 62; button(g, "hedTest", rx, by2, 58, bh, Lang.t("hed.test"), Toasts::test);
    }

    private long resetAt;
    private boolean pendingReset() { return System.currentTimeMillis() - resetAt < 3000; }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double x = event.x(), y = event.y();
        if (y >= toolbarY - 2) return super.mouseClicked(event, doubleClick);
        String id = elementAt(x, y);
        selected = id;
        dragging = false;
        if (id != null) {
            int[] b = Hud.BOUNDS.get(id);
            float s = hs();
            grabX = (float) (x / s - b[0]);
            grabY = (float) (y / s - b[1]);
            dragging = true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (!dragging || selected == null) return super.mouseDragged(event, dragX, dragY);
        int[] b = Hud.BOUNDS.get(selected);
        if (b == null) return true;
        float s = hs();
        int sw = (int) (width / s), sh = (int) (height / s);
        int nx = Math.round((float) (event.x() / s) - grabX), ny = Math.round((float) (event.y() / s) - grabY);
        int w = b[2], h = b[3];
        guideV = guideH = false;
        int snap = 4;
        if (Math.abs(nx) <= snap) nx = 0;
        else if (Math.abs(nx + w - sw) <= snap) nx = sw - w;
        else if (Math.abs(nx + w / 2 - sw / 2) <= snap) { nx = sw / 2 - w / 2; guideV = true; }
        if (Math.abs(ny) <= snap) ny = 0;
        else if (Math.abs(ny + h - sh) <= snap) ny = sh - h;
        else if (Math.abs(ny + h / 2 - sh / 2) <= snap) { ny = sh / 2 - h / 2; guideH = true; }
        nx = Mth.clamp(nx, 0, Math.max(0, sw - w));
        ny = Mth.clamp(ny, 0, Math.max(0, sh - h));
        HudLayout.setPosition(HudLayout.get(selected), nx, ny, w, h, sw, sh);
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging) {
            dragging = false;
            guideV = guideH = false;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        String id = elementAt(mouseX, mouseY);
        if (id == null) id = selected;
        if (id == null || scrollY == 0) return true;
        selected = id;
        changeScale(id, scrollY > 0 ? HudLayout.STEP : -HudLayout.STEP);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == GLFW.GLFW_KEY_TAB) {
            int i = -1;
            for (int k = 0; k < HudLayout.IDS.length; k++) if (HudLayout.IDS[k].equals(selected)) i = k;
            for (int n = 1; n <= HudLayout.IDS.length; n++) {
                String c = HudLayout.IDS[(i + n) % HudLayout.IDS.length];
                if (Hud.BOUNDS.containsKey(c)) { selected = c; break; }
            }
            return true;
        }
        if (selected != null) {
            switch (key) {
                case GLFW.GLFW_KEY_LEFT -> { nudge(selected, -1, 0); return true; }
                case GLFW.GLFW_KEY_RIGHT -> { nudge(selected, 1, 0); return true; }
                case GLFW.GLFW_KEY_UP -> { nudge(selected, 0, -1); return true; }
                case GLFW.GLFW_KEY_DOWN -> { nudge(selected, 0, 1); return true; }
                case GLFW.GLFW_KEY_R -> { HudLayout.reset(selected); Config.save(); return true; }
                default -> { }
            }
        }
        return super.keyPressed(event);
    }
}

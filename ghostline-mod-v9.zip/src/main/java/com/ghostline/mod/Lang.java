package com.ghostline.mod;

import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

public class Lang {
    private static final Map<String, String[]> M = new HashMap<>();

    private static void p(String k, String en, String ru) { M.put(k, new String[]{en, ru}); }

    static {
        p("page.0", "Combat", "Бой");
        p("page.1", "Movement", "Движение");
        p("page.2", "Player", "Игрок");
        p("page.3", "Visuals", "Визуалы");
        p("page.4", "Misc", "Разное");
        p("page.5", "Theme", "Тема");
        p("page.6", "HUD", "HUD");
        p("page.7", "Configs", "Конфиги");
        p("page.8", "Cosmetics", "Косметика");
        p("desc.AimAssist", "Smoothly aims at targets", "Плавно наводится на цели");
        p("desc.AutoMace", "Mace smash while you fall", "Удар булавой в тайминг падения");
        p("desc.AutoSwap", "Swaps the item in your hand on a key", "Меняет предмет в руке по кнопке");
        p("desc.AutoTotem", "Keeps a totem in your offhand", "Держит тотем в левой руке");
        p("desc.KeyPearl", "Throws an ender pearl on a key", "Кидает эндер-жемчуг по кнопке");
        p("desc.KeyWind", "Throws a wind charge under you on a key", "Кидает заряд ветра под себя по кнопке");
        p("desc.NoFriendDamage", "Never hits or targets friends", "Не бьёт и не берёт в цель друзей");
        p("desc.TriggerBot", "Attacks when the crosshair is on a target", "Бьёт, когда прицел на цели");
        p("desc.AutoSprint", "Sprints automatically", "Автоматический бег");
        p("desc.Fly", "Creative-style flight", "Полёт как в креативе");
        p("desc.GuiMove", "Move while a menu is open", "Движение при открытом меню");
        p("desc.Speed", "Faster ground movement", "Ускоряет бег");
        p("desc.AutoTool", "Picks the best tool for the block", "Выбирает лучший инструмент для блока");
        p("desc.ChestStealer", "Takes everything from an opened chest", "Забирает всё из открытого сундука");
        p("desc.Friends", "Middle click on a player adds or removes a friend", "СКМ по игроку добавляет или убирает друга");
        p("desc.Fullbright", "Everything is bright (night vision)", "Везде светло (ночное зрение)");
        p("desc.ViewModel", "Moves and scales your hand and item", "Двигает и меняет размер руки и предмета");
        p("desc.Panic", "Turns everything off until the game restarts", "Отключает всё до перезапуска игры");
        p("desc.Trail", "Particles around your character", "Частицы вокруг персонажа");
        p("set.Speed", "Speed", "Скорость");
        p("set.FOV", "Field of view", "Угол обзора");
        p("set.Distance", "Distance", "Дистанция");
        p("set.Vertical", "Vertical", "По вертикали");
        p("set.Weapon only", "Weapons only", "Только с оружием");
        p("set.Priority", "Priority", "Приоритет");
        p("set.Only on click", "Only while clicking", "Только с кликом");
        p("set.Players", "Players", "Игроки");
        p("set.Mobs", "Mobs", "Мобы");
        p("set.Through walls", "Through walls", "Сквозь стены");
        p("set.Invisible", "Invisible", "Невидимые");
        p("set.Naked", "Naked", "Голые");
        p("set.In armor", "In armor", "В броне");
        p("set.Min fall height", "Min fall height", "Мин. высота удара");
        p("set.Max fall height", "Max fall height", "Макс. высота удара");
        p("set.While falling", "Mace while falling", "Булава в падении");
        p("set.After charge", "Mace after charge", "Булава после заряда");
        p("set.Swap to mace", "Swap to mace", "Свап на булаву");
        p("set.Return slot", "Return slot", "Вернуть слот");
        p("set.From", "From", "От");
        p("set.To", "To", "На");
        p("set.From name", "From name contains", "Имя «От» содержит");
        p("set.To name", "To name contains", "Имя «На» содержит");
        p("set.Hand", "Hand", "Рука");
        p("set.Swap key", "Swap key", "Кнопка свапа");
        p("set.Wheel button", "Wheel button", "Кнопка колеса");
        p("set.Health threshold", "Health threshold", "Порог здоровья");
        p("set.Delay", "Delay", "Задержка");
        p("set.Not while eating", "Not while eating", "Не во время еды");
        p("set.Switch back", "Return item", "Возвращать предмет");
        p("set.Look down", "Throw under yourself", "Бросать под себя");
        p("set.Charge", "Attack charge", "Заряд удара");
        p("set.Crits only", "Crits only", "Только криты");
        p("set.Fly speed", "Fly speed", "Скорость полёта");
        p("set.Multiplier", "Multiplier", "Множитель");
        p("set.Jump", "Jump", "Прыжок");
        p("set.In Ghostline menu", "In Ghostline menu", "В меню клиента");
        p("set.Auto close", "Close the chest", "Закрывать сундук");
        p("set.Click range", "Click range", "Дальность клика");
        p("set.Scale", "Scale", "Размер");
        p("set.Style", "Style", "Стиль");
        p("set.Density", "Density", "Плотность");
        p("set.First person", "First person", "От первого лица");
        p("set.Preset", "Preset", "Тема");
        p("set.Panel opacity", "Panel opacity", "Прозрачность панели");
        p("set.Background logo", "Background logo", "Фоновый логотип");
        p("set.Animations", "Animations", "Анимации");
        p("set.Custom R", "Red", "Красный");
        p("set.Custom G", "Green", "Зелёный");
        p("set.Custom B", "Blue", "Синий");
        p("set.Module list", "Module list", "Список модулей");
        p("set.Watermark", "Watermark", "Ватермарка");
        p("set.Coordinates", "Coordinates", "Координаты");
        p("set.Binds", "Binds", "Бинды");
        p("set.Target", "Target", "Цель");
        p("set.Armor", "Armor", "Броня");
        p("set.Potions", "Potions", "Зелья");
        p("set.List position", "List position", "Позиция списка");
        p("set.Watermark position", "Watermark position", "Позиция ватермарки");
        p("set.Coords position", "Coords position", "Позиция координат");
        p("set.Extras position", "Extras position", "Позиция бинд/цель/броня/зелья");
        p("set.Sort", "Sort", "Сортировка");
        p("set.Color", "Color", "Цвет");
        p("set.Opacity", "Opacity", "Прозрачность");
        p("opt.Off", "Off", "Выкл");
        p("opt.On", "On", "Вкл");
        p("opt.Angle", "Angle", "Угол");
        p("opt.Distance", "Distance", "Дистанция");
        p("opt.Any", "Any (by name)", "Любой (по имени)");
        p("opt.Totem", "Totem", "Тотем");
        p("opt.Enchanted totem", "Ench. totem", "Зачар. тотем");
        p("opt.Head", "Sphere (head)", "Сфера (голова)");
        p("opt.Shield", "Shield", "Щит");
        p("opt.Gapple", "Golden apple", "Золотое яблоко");
        p("opt.Pearl", "Ender pearl", "Эндер-жемчуг");
        p("opt.Firework", "Firework", "Фейерверк");
        p("opt.Crystal", "End crystal", "Кристалл");
        p("opt.Offhand", "Offhand", "Левая рука");
        p("opt.Mainhand", "Mainhand", "Основная");
        p("opt.Top right", "Top right", "Сверху справа");
        p("opt.Top left", "Top left", "Сверху слева");
        p("opt.Bottom right", "Bottom right", "Снизу справа");
        p("opt.Bottom left", "Bottom left", "Снизу слева");
        p("opt.Length", "By length", "По длине");
        p("opt.A-Z", "A-Z", "По алфавиту");
        p("opt.Accent", "Accent", "Акцент");
        p("opt.White", "White", "Белый");
        p("opt.Rainbow", "Rainbow", "Радуга");
        p("opt.End rod", "End rod", "Эндер-свет");
        p("opt.Soul fire", "Soul fire", "Огонь душ");
        p("opt.Heart", "Hearts", "Сердца");
        p("opt.Note", "Notes", "Ноты");
        p("opt.Enchant", "Enchant", "Чары");
        p("opt.Cloud", "Clouds", "Облака");
        p("opt.Ghost", "Ghost", "Ghost");
        p("opt.Graphite", "Graphite", "Графит");
        p("opt.Obsidian", "Obsidian", "Обсидиан");
        p("opt.Midnight", "Midnight", "Полночь");
        p("opt.Tokyo Night", "Tokyo Night", "Tokyo Night");
        p("opt.Rose Pine", "Rose Pine", "Rose Pine");
        p("opt.Blue neon", "Blue neon", "Синий неон");
        p("opt.Crimson", "Crimson", "Алый");
        p("opt.Emerald", "Emerald", "Изумруд");
        p("opt.Sunset", "Sunset", "Закат");
        p("opt.Violet", "Violet", "Фиолет");
        p("opt.Arctic", "Arctic", "Арктика");
        p("opt.Cyberpunk", "Cyberpunk", "Киберпанк");
        p("opt.Ocean", "Ocean", "Океан");
        p("opt.Ice", "Ice", "Лёд");
        p("opt.Custom", "Custom", "Своя");
        p("theme.title", "Theme", "Тема");
        p("theme.g0", "Signature", "Фирменная");
        p("theme.g1", "Dark", "Тёмные");
        p("theme.g2", "Colored", "Цветные");
        p("theme.g3", "Custom", "Своя");
        p("theme.interface", "Interface", "Интерфейс");
        p("theme.custom", "Custom theme", "Своя тема");
        p("cos.title", "Cosmetics", "Косметика");
        p("cos.trail", "Trail", "След");
        p("cos.remove", "Remove all", "Снять всё");
        p("hud.title", "HUD", "HUD");
        p("hud.elements", "Elements", "Элементы");
        p("hud.layout", "Layout", "Расположение");
        p("hud.style", "Style", "Оформление");
        p("ui.on", "ON", "ВКЛ");
        p("ui.off", "OFF", "ВЫКЛ");
        p("ui.close", "Close", "Закрыть");
        p("ui.back", "Back", "Назад");
        p("ui.reset", "Reset", "Сброс");
        p("ui.menu_key", "Menu key", "Клавиша меню");
        p("ui.enabled", "Enabled", "Включено");
        p("ui.bind", "Bind", "Бинд");
        p("ui.press_key", "Press a key...", "Нажми клавишу...");
        p("ui.count", "%d of %d on", "%d из %d вкл");
        p("ui.confirm", "Press again to confirm", "Нажми ещё раз для подтверждения");
        p("ui.lang_label", "Language", "Язык");
        p("ui.none", "None", "Нет");
        p("ui.settings", "settings", "настройки");
        p("ui.choose_lang", "Choose language / Выберите язык", "Choose language / Выберите язык");
        p("ui.singleplayer", "Singleplayer", "Одиночная игра");
        p("ui.multiplayer", "Multiplayer", "Сетевая игра");
        p("ui.options", "Settings", "Настройки");
        p("ui.quit", "Quit game", "Выйти");
        p("ui.ghost_menu", "Ghostline menu", "Меню Ghostline");
        p("ui.add", "Add", "Добавить");
        p("ui.add_looked", "Add player under crosshair", "Добавить игрока в прицеле");
        p("ui.friend_name", "Nickname", "Ник");
        p("ui.friend_added", "Friend added: %s", "Друг добавлен: %s");
        p("ui.friend_removed", "Friend removed: %s", "Друг убран: %s");
        p("fr.empty", "No friends yet", "Друзей пока нет");
        p("fr.remove", "Remove", "Убрать");
        p("cfg.name", "Config name", "Имя конфига");
        p("cfg.code", "Config code", "Код конфига");
        p("cfg.save", "Save", "Сохранить");
        p("cfg.overwrite", "Overwrite?", "Перезаписать?");
        p("cfg.find", "Find", "Найти");
        p("cfg.copy", "Copy code of current config", "Скопировать код текущего конфига");
        p("cfg.load", "Load", "Загрузить");
        p("cfg.delete", "Delete", "Удалить");
        p("cfg.sure", "Sure?", "Точно?");
        p("cfg.empty", "No configs yet", "Конфигов пока нет");
        p("cfg.empty_hint", "Enter a name above and press Save", "Введите имя выше и нажмите «Сохранить»");
        p("cfg.saved", "Saved: %s", "Сохранено: %s");
        p("cfg.loaded", "Loaded: %s", "Загружено: %s");
        p("cfg.deleted", "Deleted: %s", "Удалено: %s");
        p("cfg.copied", "Code copied to clipboard", "Код скопирован в буфер обмена");
        p("cfg.imported", "Config imported from code", "Конфиг загружен по коду");
        p("cfg.bad_name", "Enter a valid name", "Введите корректное имя");
        p("cfg.bad_code", "Invalid or empty code", "Неверный или пустой код");
        p("cfg.error", "Error: %s", "Ошибка: %s");
        p("desc.AutoWarden", "Walks to the farm point with Baritone, eats, respawns, leaves when a player is near", "Идёт на точку фарма через Baritone, ест, респавнится, уходит при игроке рядом");
        p("set.Farm point", "Farm point (x y z)", "Точка фарма (x y z)");
        p("set.Set farm here", "Set farm point here", "Точка фарма = моя позиция");
        p("set.Leave command", "Leave command (to base)", "Команда ухода на базу");
        p("set.Return command", "Return command (to farm)", "Команда возврата на фарм");
        p("set.Player radius", "Player radius", "Радиус игроков");
        p("set.Wait time", "Wait on base", "Ждать на базе");
        p("set.Eat threshold", "Eat below", "Есть ниже");
        p("set.Auto respawn", "Auto respawn", "Авто-респавн");
        p("set.Look along path", "Look along path", "Поворот по пути");
        p("set.Telegram token", "Telegram bot token", "Токен Telegram-бота");
        p("set.Telegram chat", "Telegram chat ID", "ID чата Telegram");
        p("aw.status", "Status", "Статус");
        p("aw.nobaritone", "Baritone not found (put it in mods)", "Baritone не найден (положи в mods)");
        p("aw.badpoint", "Set the farm point", "Укажи точку фарма");
        p("aw.going", "Going to the farm point", "Иду на точку фарма");
        p("aw.atpoint", "At the farm point", "На точке фарма");
        p("aw.eating", "Eating golden carrot", "Ем золотую морковь");
        p("aw.away", "Leaving: %s is near", "Уход от игрока: %s");
        p("aw.waiting", "Waiting on base: %d s", "Жду на базе: %d с");
        p("aw.returning", "Returning to farm", "Возврат на фарм");
        p("aw.dead", "Died, respawning", "Умер, респавн");
        p("aw.tg.death", "Died at %s", "Умер: %s");
        p("aw.tg.player", "Player %s is near, leaving to base", "Рядом игрок %s, ухожу на базу");
        p("desc.Wings", "Particle wings behind your character", "Крылья из частиц за спиной");
        p("desc.Waypoints", "Saved coordinates with distance and direction on the HUD", "Метки координат с расстоянием и направлением на HUD");
        p("set.Wallpaper", "Wallpaper", "Обои");
        p("set.Max shown", "Shown on HUD", "Показывать на HUD");
        p("opt.None", "None", "Нет");
        p("opt.Snow", "Snow", "Снег");
        p("opt.Aurora", "Aurora", "Аврора");
        p("opt.Embers", "Embers", "Искры");
        p("opt.Angel", "Angel", "Ангел");
        p("opt.Demon", "Demon", "Демон");
        p("opt.Fairy", "Fairy", "Фея");
        p("opt.Frost", "Frost", "Иней");
        p("cos.wings", "Wings", "Крылья");
        p("ui.search", "Search", "Поиск");
        p("ui.no_results", "Nothing found", "Ничего не найдено");
        p("wp.name", "Name", "Название");
        p("wp.empty", "No waypoints yet", "Меток пока нет");
        p("hk.title", "Hotkeys", "Горячие клавиши");
        p("hk.empty", "No binds yet", "Бинды не назначены");
    }


    static {
        // ---- Visuals: Player ESP, weather
        p("desc.PlayerESP", "Boxes, tracers, arrows, health, armor and names for players (screen overlay, first person)", "Боксы, трейсеры, стрелки, здоровье, броня и ники игроков (оверлей, от первого лица)");
        p("desc.Weather", "Client-side weather: clear, rain or thunder", "Погода на стороне клиента: ясно, дождь или гроза");
        p("set.Tracers", "Tracers", "Трейсеры");
        p("set.Arrows", "Off-screen arrows", "Стрелки за экраном");
        p("set.Names", "Names", "Ники");
        p("set.Health", "Health", "Здоровье");
        p("set.Mode", "Mode", "Режим");
        p("opt.Box", "Box", "Бокс");
        p("opt.Corners", "Corners", "Углы");
        p("opt.3D", "3D box", "3D бокс");
        p("opt.Filled", "Filled", "Заливка");
        p("opt.Red", "Red", "Красный");
        p("opt.Health", "By health", "По здоровью");
        p("opt.Clear", "Clear", "Ясно");
        p("opt.Rain", "Rain", "Дождь");
        p("opt.Thunder", "Thunder", "Гроза");

        // ---- HUD / watermark
        p("set.Watermark style", "Watermark style", "Стиль watermark");
        p("set.Show FPS", "Show FPS", "Показывать FPS");
        p("set.Show version", "Show version", "Показывать версию");
        p("set.Show ping", "Show ping", "Показывать пинг");
        p("set.Show nick", "Show nickname", "Показывать ник");
        p("set.Show clock", "Show clock", "Показывать время");
        p("opt.Ghostline", "Ghostline", "Ghostline");
        p("opt.Compact", "Compact", "Компактный");
        p("opt.Minimal", "Minimal", "Минимальный");

        // ---- Base Finder
        p("desc.BaseFinder", "Finds possible bases in loaded chunks (block score) and marks containers. Only loaded data, never hidden blocks", "Ищет возможные базы в загруженных чанках (очки блоков) и отмечает контейнеры. Только загруженные данные, скрытое не видит");
        p("set.Scan radius", "Scan radius", "Радиус скана");
        p("set.Vertical range", "Vertical range", "Диапазон по высоте");
        p("set.Scan speed", "Scan speed (blocks/tick)", "Скорость скана (блоков/тик)");
        p("set.World scanner", "World scanner", "Сканер мира");
        p("set.Min score", "Min score", "Мин. очки");
        p("set.Building blocks", "Building blocks", "Строительные блоки");
        p("set.Functional blocks", "Functional blocks", "Функциональные блоки");
        p("set.Extra blocks", "Extra blocks (names, comma)", "Доп. блоки (имена через запятую)");
        p("set.Chest ESP", "Chest ESP", "ESP контейнеров");
        p("set.ESP distance", "ESP distance", "Дистанция ESP");
        p("set.Chests", "Chests", "Сундуки");
        p("set.Trapped chests", "Trapped chests", "Сундуки-ловушки");
        p("set.Barrels", "Barrels", "Бочки");
        p("set.Shulker boxes", "Shulker boxes", "Шалкеры");
        p("set.Ender chests", "Ender chests", "Эндер-сундуки");
        p("set.Workstations", "Hoppers / furnaces / dispensers", "Воронки / печи / раздатчики");
        p("set.Container threshold", "Containers per chunk to report", "Контейнеров в чанке для уведомления");
        p("set.Notify chat", "Notify in chat", "Уведомлять в чате");
        p("set.Notify Telegram", "Notify in Telegram", "Уведомлять в Telegram");
        p("set.Telegram token", "Telegram bot token", "Токен Telegram-бота");
        p("set.Telegram chat", "Telegram chat id", "ID чата Telegram");
        p("set.Cooldown", "Repeat cooldown", "Пауза до повтора");
        p("set.Log on HUD", "Findings on HUD", "Находки на HUD");
        p("set.Log to file", "Write log file", "Писать журнал в файл");
        p("set.Labels", "Labels", "Подписи");
        p("opt.Chest", "Chest", "Сундук");
        p("opt.Trapped chest", "Trapped chest", "Сундук-ловушка");
        p("opt.Barrel", "Barrel", "Бочка");
        p("opt.Shulker box", "Shulker box", "Шалкер");
        p("opt.Ender chest", "Ender chest", "Эндер-сундук");
        p("opt.Workstation", "Workstation", "Станок");
        p("bf.base", "Possible base near %d %d %d (score %d)", "Возможная постройка около %d %d %d (очки %d)");
        p("bf.cont", "Containers: %d near %d %d %d", "Контейнеров: %d около %d %d %d");
        p("bf.none", "BaseFinder: nothing found yet", "BaseFinder: пока ничего");

        // ---- Tree Farm
        p("desc.TreeFarm", "Walks to trees, chops the trunk within reach, collects logs. Stops on danger, no axe, full inventory or lost path", "Идёт к деревьям, рубит ствол в зоне досягаемости, подбирает брёвна. Останавливается при опасности, без топора, с полным инвентарём или потере пути");
        p("set.Radius", "Search radius", "Радиус поиска");
        p("set.Preferred tree", "Preferred tree", "Приоритетное дерево");
        p("set.Oak", "Oak", "Дуб");
        p("set.Spruce", "Spruce", "Ель");
        p("set.Birch", "Birch", "Берёза");
        p("set.Jungle", "Jungle", "Тропическое");
        p("set.Acacia", "Acacia", "Акация");
        p("set.Dark oak", "Dark oak", "Тёмный дуб");
        p("set.Mangrove", "Mangrove", "Мангровое");
        p("set.Cherry", "Cherry", "Вишня");
        p("set.Pale oak", "Pale oak", "Бледный дуб");
        p("set.Require axe", "Require an axe", "Нужен топор");
        p("set.Min tool durability", "Min tool durability", "Мин. прочность инструмента");
        p("set.Stop at HP", "Stop at health", "Стоп при здоровье");
        p("set.Stop near players", "Stop near players", "Стоп рядом с игроками");
        p("set.Player radius", "Player radius", "Радиус игроков");
        p("set.Stop on hostile", "Stop near hostile mobs", "Стоп рядом с мобами");
        p("set.Stuck timeout", "Stuck timeout", "Таймаут застревания");
        p("set.Collect drops", "Collect drops", "Подбирать дроп");
        p("set.Telegram on stop", "Telegram on stop", "Telegram при остановке");
        p("opt.Any tree", "Any tree", "Любое");
        p("opt.Oak", "Oak", "Дуб");
        p("opt.Spruce", "Spruce", "Ель");
        p("opt.Birch", "Birch", "Берёза");
        p("opt.Jungle", "Jungle", "Тропическое");
        p("opt.Acacia", "Acacia", "Акация");
        p("opt.Dark oak", "Dark oak", "Тёмный дуб");
        p("opt.Mangrove", "Mangrove", "Мангровое");
        p("opt.Cherry", "Cherry", "Вишня");
        p("opt.Pale oak", "Pale oak", "Бледный дуб");
        p("tf.searching", "searching for a tree", "ищу дерево");
        p("tf.walking", "walking to the tree", "иду к дереву");
        p("tf.chopping", "chopping", "рублю");
        p("tf.collecting", "collecting logs", "подбираю брёвна");
        p("tf.paused", "paused (screen open)", "пауза (открыт экран)");
        p("tf.summary", "logs %d | trees %d | blocks %d", "брёвен %d | деревьев %d | блоков %d");
        p("tf.s.dead", "stopped: you died", "остановлено: ты умер");
        p("tf.s.hp", "stopped: low health", "остановлено: мало здоровья");
        p("tf.s.fire", "stopped: fire or lava", "остановлено: огонь или лава");
        p("tf.s.fall", "stopped: falling", "остановлено: падение");
        p("tf.s.mob", "stopped: hostile mob nearby", "остановлено: рядом моб");
        p("tf.s.player", "stopped: player %s nearby", "остановлено: рядом игрок %s");
        p("tf.s.full", "stopped: inventory full", "остановлено: инвентарь полон");
        p("tf.s.notool", "stopped: no suitable axe in the hotbar", "остановлено: нет подходящего топора в хотбаре");
        p("tf.s.notrees", "stopped: no trees in range", "остановлено: деревьев в радиусе нет");
        p("tf.s.lost", "stopped: path lost", "остановлено: потерян путь");
        p("tf.s.lava", "stopped: lava ahead", "остановлено: впереди лава");
    }


    static {
        // ---- Config Manager: CFG files
        p("cfg.export", "Export current settings to a .cfg file", "Экспорт настроек в .cfg файл");
        p("cfg.exported", "Saved %s in config/ghostline-configs/exports", "Сохранено: %s (config/ghostline-configs/exports)");
        p("cfg.import", "Import", "Импорт");
        p("cfg.import_ok", "Imported %d settings (%d unknown ignored, %d protected skipped)", "Импортировано настроек: %d (неизвестных пропущено: %d, защищённых пропущено: %d)");
        p("cfg.import_failed", "Import rejected: %s", "Импорт отклонён: %s");
    }


    static {
        // ---- FriendsHelp
        p("desc.FriendsHelp", "Friends, statuses, chat and help requests through a Ghostline server. Coordinates only with your explicit consent", "Друзья, статусы, чат и запросы помощи через сервер Ghostline. Координаты только с твоего явного согласия");
        p("set.Server URL", "Server address (https://...)", "Адрес сервера (https://...)");
        p("set.Pairing code", "Pairing code (from the server page)", "Код привязки (со страницы сервера)");
        p("set.Status", "Status", "Статус");
        p("set.Status note", "Status note", "Заметка к статусу");
        p("set.Visible to", "Online status visible to", "Кто видит мой онлайн");
        p("set.Friend requests", "Friend requests from", "Заявки в друзья от");
        p("set.Notify friend online", "Notify when a friend comes online", "Уведомлять, когда друг в сети");
        p("set.Show friend chat", "Show friend chat", "Показывать чат друзей");
        p("set.Help key", "Help request key", "Клавиша запроса помощи");
        p("set.Share coordinates", "Share coordinates", "Передача координат");
        p("set.Help message", "Help message", "Текст запроса помощи");
        p("set.Intercept /help", "Use /help for help requests", "/help отправляет запрос помощи");
        p("set.Friends on HUD", "Friends on HUD", "Друзья на HUD");
        p("opt.Online", "Online", "В сети");
        p("opt.Away", "Away", "Отошёл");
        p("opt.Busy", "Busy", "Занят");
        p("opt.Invisible", "Invisible", "Невидимка");
        p("opt.Friends", "Friends", "Друзья");
        p("opt.Nobody", "Nobody", "Никто");
        p("opt.Everyone", "Everyone", "Все");
        p("opt.Never", "Never", "Никогда");
        p("opt.Ask each time", "Only when I confirm", "Только с моим подтверждением");
        p("fh.need_code", "FriendsHelp: open the server page, create an account, get a pairing code and enter it in the module settings", "FriendsHelp: открой страницу сервера, создай аккаунт, получи код привязки и введи его в настройках модуля");
        p("fh.claim_failed", "Pairing failed", "Не удалось привязать");
        p("fh.paired", "Paired. The session is stored encrypted.", "Привязано. Сессия хранится в зашифрованном виде.");
        p("fh.connected", "Connected as %s: %d friends, %d requests", "Подключено как %s: друзей %d, заявок %d");
        p("fh.lost", "Connection lost, reconnecting...", "Связь потеряна, переподключаюсь...");
        p("fh.expired", "Session expired. Get a new pairing code.", "Сессия истекла. Получи новый код привязки.");
        p("fh.logged_out", "Logged out", "Выход выполнен");
        p("fh.online", "is online", "в сети");
        p("fh.offline", "went offline", "вышел");
        p("fh.request", "%s wants to be friends. Accept: /gl accept %s", "%s хочет дружить. Принять: /gl accept %s");
        p("fh.added", "%s is now your friend", "%s теперь твой друг");
        p("fh.removed", "%s was removed from friends", "%s удалён из друзей");
        p("fh.no_coords", "no coordinates", "без координат");
        p("fh.help_from", "Help request from", "Просьба о помощи от");
        p("fh.off", "FriendsHelp is off", "FriendsHelp выключен");
        p("fh.not_connected", "Not connected to the friends server", "Нет подключения к серверу друзей");
        p("fh.coords_off", "Sharing coordinates is set to Never in the settings", "Передача координат выключена в настройках");
        p("fh.help_sent", "Help request sent to %d friends online. Coordinates were NOT shared.", "Запрос помощи отправлен друзьям онлайн: %d. Координаты НЕ переданы.");
        p("fh.help_sent_coords", "Help request with coordinates sent to %d friends online", "Запрос помощи с координатами отправлен друзьям онлайн: %d");
        p("fh.coords_ask", "To share your coordinates too, press the help key again or run /ghelp coords within 15 seconds", "Чтобы передать ещё и координаты, нажми клавишу помощи ещё раз или выполни /ghelp coords в течение 15 секунд");
        p("fh.failed", "Failed", "Ошибка");
        p("fh.done", "Done", "Готово");
        p("fh.no_friends", "No friends yet. Use /gl add <name>", "Друзей пока нет. Используй /gl add <ник>");
        p("fh.requests", "Friend requests", "Заявки в друзья");
        p("fh.hud_off", "off", "выкл");
        p("fh.hud_wait", "connecting...", "подключение...");
        p("fh.hud_friends", "Friends online:", "Друзья онлайн:");

        // ---- Raid Assistant
        p("desc.RaidAssistant", "Saved bases with a second point and route, valuables list, loot accounting, warnings, container hints. Assists only; automation is optional and off by default", "Сохранённые базы со второй точкой и маршрутом, список ценностей, учёт добычи, предупреждения, подсказки по контейнерам. Только помощь; автоматизация по желанию и выключена по умолчанию");
        p("set.Valuables", "Valuables (item names, comma)", "Ценности (имена предметов через запятую)");
        p("set.Reserve slots", "Free slots to keep", "Свободных слотов в запасе");
        p("set.Auto take valuables", "Auto take valuables from chests", "Автоматически брать ценности из сундуков");
        p("set.Take delay", "Take delay", "Задержка взятия");
        p("set.Tool warning", "Tool wear warning", "Предупреждение об износе");
        p("set.Min totems", "Min totems", "Мин. тотемов");
        p("set.Auto return", "Auto return (needs Baritone)", "Авто-возврат (нужен Baritone)");
        p("set.Return at HP", "Return at health", "Возврат при здоровье");
        p("set.Return to", "Return to", "Вернуться в");
        p("set.Stop key", "Emergency stop key", "Клавиша аварийной остановки");
        p("set.Container hints", "Container hints", "Подсказки по контейнерам");
        p("set.Log actions", "Write action log", "Писать журнал действий");
        p("opt.Second point", "Second point", "Вторая точка");
        p("opt.Base", "Base", "База");
        p("raid.name", "Base name", "Название базы");
        p("raid.save_here", "Save here", "Сохранить тут");
        p("raid.empty", "No saved bases. Stand at a base, type a name and press Save.", "Баз нет. Встань у базы, введи название и нажми «Сохранить».");
        p("raid.select", "Select", "Выбрать");
        p("raid.second", "2nd point", "2-я точка");
        p("raid.route_add", "+ Route", "+ Маршрут");
        p("raid.route_clear", "Clear route", "Сброс маршрута");
        p("raid.route", "route", "маршрут");
        p("raid.go", "Go to base", "К базе");
        p("raid.return", "Return", "Возврат");
        p("raid.stop", "STOP", "СТОП");
        p("raid.no_baritone", "Baritone is not installed: go/return buttons only show the way on the HUD", "Baritone не установлен: кнопки пути только подсказывают направление на HUD");
        p("raid.no_player", "Join a world first", "Сначала зайди в мир");
        p("raid.bad_name", "Enter a base name", "Введи название базы");
        p("raid.saved", "Base %s saved", "База %s сохранена");
        p("raid.no_base", "Select a base first", "Сначала выбери базу");
        p("raid.return_hint", "Baritone is not installed: follow the HUD arrow back", "Baritone не установлен: возвращайся по стрелке на HUD");
        p("raid.stopped", "Raid Assistant stopped", "Raid Assistant остановлен");
        p("raid.reserve", "Free-slot reserve reached: auto take paused", "Достигнут запас свободных слотов: автовзятие остановлено");
        p("raid.totems", "Totems: %d", "Тотемов: %d");
        p("raid.slots", "Free slots: %d", "Свободных слотов: %d");
        p("raid.base", "Base", "База");
        p("raid.returning", "Returning to", "Возврат:");
        p("raid.other_dim", "other dimension", "другое измерение");
        p("raid.loot", "Loot:", "Добыча:");
        p("raid.nearest", "Nearest container:", "Ближайший контейнер:");
        p("raid.drop", "Valuable drop:", "Ценный дроп:");
        p("raid.need_finder", "Turn on BaseFinder to get container hints", "Включи BaseFinder, чтобы получать подсказки по контейнерам");

        // ---- Invisibility Helper
        p("desc.InvisibilityHelper", "Own invisibility timer and reminders, potion count, and players the server flags as invisible. Players the server does not send cannot be seen", "Таймер своей невидимости и напоминания, число зелий и игроки, которых сервер помечает невидимыми. Игроков, которых сервер не присылает, увидеть нельзя");
        p("set.Own timer", "Own timer", "Свой таймер");
        p("set.Remind at", "Remind when left", "Напомнить за");
        p("set.Remind on expiry", "Remind when it ends", "Напомнить об окончании");
        p("set.Item keywords", "Item name keywords", "Слова в названии предмета");
        p("set.Watch nearby", "Watch invisible players nearby", "Следить за невидимыми рядом");
        p("set.Watch radius", "Watch radius", "Радиус слежения");
        p("set.Alert nearby", "Alert in chat", "Оповещение в чате");
        p("set.Show on HUD", "Show on HUD", "Показывать на HUD");
        p("inv.infinite", "Invisible (no time limit)", "Невидимость (без ограничения)");
        p("inv.timer", "Invisible: %d:%02d left", "Невидимость: осталось %d:%02d");
        p("inv.ending", "Invisibility ends in %d s", "Невидимость закончится через %d с");
        p("inv.left", "%d potions left", "осталось зелий: %d");
        p("inv.ended", "Invisibility ended", "Невидимость закончилась");
        p("inv.armor", "armor", "броня");
        p("inv.hand", "held items", "предметы в руках");
        p("inv.visible", "Still visible to others:", "Остаётся видимым для других:");
        p("inv.unknown", "Invisible (source unknown, no timer)", "Невидим (источник неизвестен, таймера нет)");
        p("inv.items", "Invisibility items: %d", "Предметов невидимости: %d");
        p("inv.nearby", "Invisible nearby:", "Невидим рядом:");
        p("inv.alert", "%s is flagged invisible, %d m away", "%s помечен невидимым, в %d м");
    }


    static {
        // ---- HUD editor
        p("hud.watermark", "Watermark", "Watermark");
        p("hed.title", "HUD editor", "Редактор HUD");
        p("hed.desc", "Drag elements, resize with the mouse wheel, hide or reset them. Changes are live.", "Перетаскивай элементы, меняй размер колёсиком, скрывай и сбрасывай. Изменения видны сразу.");
        p("hed.open", "Open HUD editor", "Открыть редактор HUD");
        p("hed.reset_all", "Reset layout", "Сбросить расположение");
        p("hed.reset_done", "HUD layout reset", "Расположение HUD сброшено");
        p("hed.reset_one", "Reset", "Сброс");
        p("hed.hint", "Drag to move - wheel to resize - Tab next - arrows nudge - R reset - Esc done", "Тяни - колёсико размер - Tab дальше - стрелки сдвиг - R сброс - Esc готово");
        p("hed.off", "hidden", "скрыт");
        p("hed.hide", "Hide", "Скрыть");
        p("hed.show", "Show", "Показать");
        p("hed.done", "Done", "Готово");
        p("hed.test", "Test toast", "Тест");
        p("hed.module_off", "module %s is off, nothing is shown in the game", "модуль %s выключен, в игре ничего не покажется");
        p("set.Editor key", "HUD editor key", "Клавиша редактора HUD");
        p("hud.el.watermark", "Watermark", "Watermark");
        p("hud.el.coords", "Coordinates", "Координаты");
        p("hud.el.modules", "Module list", "Список модулей");
        p("hud.el.status", "AutoWarden status", "Статус AutoWarden");
        p("hud.el.binds", "Binds", "Бинды");
        p("hud.el.target", "Target", "Цель");
        p("hud.el.armor", "Armor", "Броня");
        p("hud.el.effects", "Effects", "Эффекты");
        p("hud.el.waypoints", "Waypoints", "Метки");
        p("hud.el.treefarm", "Tree Farm", "Tree Farm");
        p("hud.el.friends", "Friends", "Друзья");
        p("hud.el.raid", "Raid Assistant", "Raid Assistant");
        p("hud.el.invis", "Invisibility", "Невидимость");
        p("hud.el.findings", "Base Finder log", "Журнал Base Finder");
        p("hud.el.notifications", "Notifications", "Уведомления");

        // ---- Notifications
        p("nt.title", "Notifications", "Уведомления");
        p("desc.Notifications", "On-screen notifications with a queue and animations", "Уведомления на экране с очередью и анимациями");
        p("set.Duration", "Duration", "Длительность");
        p("set.Max visible", "Max on screen", "Макс. на экране");
        p("set.Corner", "Corner", "Угол");
        p("set.Animation", "Animation", "Анимация");
        p("set.Modules", "Module on/off", "Включение модулей");
        p("set.Menu and configs", "Menu and configs", "Меню и конфиги");
        p("set.Friends", "Friends", "Друзья");
        p("set.Warnings", "Warnings (raid, tree farm, finder)", "Предупреждения (рейд, tree farm, finder)");
        p("set.Progress bar", "Progress bar", "Полоса времени");
        p("opt.Slide", "Slide", "Выезд");
        p("opt.Fade", "Fade", "Затухание");
        p("nt.on", "enabled", "включён");
        p("nt.off", "disabled", "выключен");
        p("nt.test", "This is a test notification", "Это тестовое уведомление");
        p("nt.test2", "Everything works", "Всё работает");
        p("nt.test3", "Warnings look like this", "Так выглядят предупреждения");
        p("nt.sample", "Sample", "Пример");
        p("nt.sample_text", "Drag me to a new place", "Перетащи меня на новое место");

        // ---- Module manager
        p("sort.0", "A-Z", "А-Я");
        p("sort.1", "On first", "Включённые");
        p("sort.2", "Favorites", "Избранные");
        p("sort.tip", "Sort modules", "Сортировка модулей");
        p("fav.tip", "Show only favorites", "Только избранное");
        p("fav.add", "Add to favorites", "В избранное");
        p("fav.remove", "Remove from favorites", "Убрать из избранного");
        p("fav.empty", "No favorites yet. Click the + next to a module name.", "Избранного пока нет. Нажми + рядом с названием модуля.");
        p("key.conflict", "Key %s is already used by: %s. Press it again to take it over, Esc to cancel", "Клавиша %s уже занята: %s. Нажми её ещё раз, чтобы забрать, Esc отмена");
        p("key.menu", "Key %s opens the menu and cannot be reused", "Клавиша %s открывает меню, её нельзя использовать");
        p("key.vanilla", "Key %s is also used by Minecraft: %s", "Клавишу %s использует и Minecraft: %s");
        p("key.dup", "This key is used more than once", "Эта клавиша используется несколько раз");
    }

    static {
        p("cfg.keys_cleared", "%d imported hotkeys clashed with yours and were cleared", "Горячих клавиш из импорта конфликтовало с твоими и сброшено: %d");
        p("cfg.corrupt", "Settings file was damaged: kept as ghostline.properties.corrupt, defaults loaded", "Файл настроек повреждён: сохранён как ghostline.properties.corrupt, загружены настройки по умолчанию");
    }

    static {
        p("set.Animation speed", "Animation speed", "Скорость анимаций");
        p("tip.bind", "Click, then press a key. Backspace clears the bind", "Нажми, затем клавишу. Backspace сбрасывает бинд");
        p("tip.search", "Search modules, settings and descriptions", "Поиск по модулям, настройкам и описаниям");
    }

    private static int idx() { return Config.lang == 1 ? 1 : 0; }
    public static boolean has(String k) { return M.containsKey(k); }
    public static String t(String k) { String[] v = M.get(k); return v == null ? k : v[idx()]; }
    public static String tOr(String k, String fb) { String[] v = M.get(k); return v == null ? fb : v[idx()]; }
    public static Component c(String k) { return Component.literal(t(k)); }
    public static String mod(Module m) { return m.name; }
    public static String desc(Module m) { return tOr("desc." + m.name, ""); }
    public static String set(Setting s) { return tOr("set." + s.name, s.name); }
    public static String opt(String o) { return tOr("opt." + o, o); }
}

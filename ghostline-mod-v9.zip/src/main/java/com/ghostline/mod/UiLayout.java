package com.ghostline.mod;

import java.util.function.ToIntFunction;

/**
 * Window geometry for the Ghostline menu and the HUD editor toolbar. No Minecraft dependencies, so it can be tested
 * over many resolutions and GUI scales. Minecraft keeps the logical GUI size (screen pixels / GUI scale) at 320x240 or more,
 * so the menu is designed to be fully usable from 320x240 up.
 */
public final class UiLayout {
    private UiLayout() { }

    public static final int MAX_W = 560, MAX_H = 330;
    public static final int MIN_BODY_W = 200, MIN_BODY_H = 150;
    /** Width the HUD editor toolbar needs: all buttons in one row / in two rows (left and right groups). */
    public static final int TOOLBAR_ONE_ROW = 430, TOOLBAR_TWO_ROWS = 230;

    public record Win(int ww, int wh, int wx, int wy, int sbw, int cx, int bx, int bw, int by, int bh) { }

    /** Menu window for a logical screen of (width x height); rise is the open animation offset in pixels (0 when settled). */
    public static Win window(int width, int height, int rise) {
        int ww = Math.max(100, Math.min(width - 12, MAX_W));
        int wh = Math.max(100, Math.min(height - 12, MAX_H));
        int wx = (width - ww) / 2;
        int wy = (height - wh) / 2 + rise;
        int sbMin = ww < 340 ? 72 : 82;
        int sbw = Math.max(sbMin, Math.min(132, (int) (ww * 0.27f)));
        int cx = wx + sbw;
        int bx = cx + 10;
        int bw = ww - sbw - 20;
        int by = wy + 46;
        int bh = wh - 46 - 8;
        return new Win(ww, wh, wx, wy, sbw, cx, bx, bw, by, bh);
    }

    /** Largest GUI scale Minecraft offers for a window of px x py pixels (logical size stays >= 320x240). */
    public static int maxScale(int px, int py) {
        int s = 1;
        while (px / (s + 1) >= 320 && py / (s + 1) >= 240) s++;
        return s;
    }

    /** Logical size Minecraft uses for a GUI scale. */
    public static int logical(int px, int scale) { return (int) Math.ceil(px / (double) scale); }

    /** Rows of buttons in the HUD editor toolbar for a logical width. */
    public static int toolbarRows(int width) { return width >= TOOLBAR_ONE_ROW ? 1 : 2; }

    /** Cuts a string to fit maxWidth, ending in an ellipsis. width measures a string in pixels. */
    public static String ellipsize(String s, int maxWidth, ToIntFunction<String> width) {
        if (s == null) return "";
        if (width.applyAsInt(s) <= maxWidth) return s;
        String e = "…";
        int lo = 0, hi = s.length();
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (width.applyAsInt(s.substring(0, mid) + e) <= maxWidth) lo = mid; else hi = mid - 1;
        }
        return s.substring(0, lo) + e;
    }
}

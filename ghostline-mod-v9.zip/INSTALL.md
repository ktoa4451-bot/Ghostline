# Install Ghostline (short)

**Needs:** Minecraft **1.21.11**, Fabric Loader **0.18+**, **Fabric API 0.139.4+1.21.11**, Java **21**.
Optional: Baritone (only for the Raid "Go to base / Return" buttons and AutoWarden).

1. Get `ghostline-1.4.0.jar` (see "Build" below).
2. Put the jar into the `mods` folder together with Fabric API.
3. Start the game and press **Right Shift** to open the menu.

## Build
- **GitHub Actions (recommended):** unpack the archive, push **all** its files to your repository (the hidden folder `.github/` must go along; a copy of the workflow is also in `build.yml` next to this file). Open *Actions > build*, download the artifact `ghostline`.
  The workflow runs Gradle 9.2.0, uploads the jar, then runs `tools/verify-jar.sh` and `tools/run-tests.sh`.
- **Locally:** Gradle 9.2.0 + JDK 21: `gradle build` -> `build/libs/ghostline-1.4.0.jar`.
- Check a built jar: `bash tools/verify-jar.sh build/libs/ghostline-1.4.0.jar`.

## Friends server (optional, for FriendsHelp)
`node server/ghostline-server.js` (Node 18+), open the address in a browser, create an account, press *Get pairing code*, enter the server address and the code in *FriendsHelp* settings. Details: `server/README.md`. Use HTTPS (reverse proxy) for anything except localhost.

## Files the mod creates (in `config/`)
`ghostline.properties`, `ghostline.salt`, `ghostline-configs/`, `ghostline-bases.txt`, `ghostline-session.dat`, `ghostline-findings.log`, `ghostline-raid.log`. See `PRIVACY.md`.

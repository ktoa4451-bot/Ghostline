# Changelog

## 1.4.0 - Mega Update (parts 1-4)

> Status: the sources are complete; the Gradle build has not been run by the author of this update (no network in the
> authoring environment). Build it with the included GitHub Actions workflow and check the "Verify jar" step.

### New modules
- **BaseFinder** - scans loaded chunks for player-made blocks (score), marks containers (Chest ESP), groups them, notifies in chat / toasts / your own Telegram bot, keeps a journal. Works only on data the client has.
- **TreeFarm** - finds trees, picks an axe, chops the trunk within reach, collects logs, stops on danger / no tool / full inventory / lost path, shows statistics.
- **PlayerESP** - Box, Corners, 3D, Filled, Tracers, Arrows, Health, Armor, Names (screen overlay, first person).
- **Weather** - client-side clear / rain / thunder.
- **FriendsHelp** - friends, statuses, chat and help requests through a Ghostline server (`server/`). Coordinates only on your explicit confirmation. Passwords never reach the game.
- **RaidAssistant** - saved bases with a second point and route, valuables list, loot accounting, wear / totem / slot warnings, container hints, optional auto-take and auto-return (off by default), emergency stop.
- **InvisibilityHelper** - own invisibility timer and reminders, potion count, players the server flags as invisible.
- **Notifications** - toast queue with animations, per-source switches.

### Interface
- **HUD editor** (menu > HUD, `/glhud`, or a key): drag, snap, resize, show/hide, reset; positions saved as screen fractions.
- Watermark in three styles (Ghostline / Compact / Minimal) with FPS, version, ping, nick, clock.
- Module manager: favorites, sorting (A-Z / enabled first / favorites first), better search, hotkey conflict check, duplicate highlighting.
- Menu: animated page changes and search results, animation speed setting, tooltips, adaptive layout (tested for 320x240 and up).

### Config Manager
- Export / import `.cfg` files (format version, checksum, strict validation), share codes `GL1.`, backups before import.
- Tokens, chat ids and server addresses are never exported or imported; an import can neither switch on automation nor steal your hotkeys.
- Tokens in `ghostline.properties` are stored encrypted. A damaged settings file is set aside as `ghostline.properties.corrupt`.

### Performance
- Config saves are batched and written off the game thread; file and network work uses shared background pools.
- ESP entity query once per tick; cached HUD lists; adaptive BaseFinder scan budget; `/glperf` shows per-module cost.

### Fixes
- Watermark settings were unreachable in the menu (they are on the HUD page now).
- Raid stop key no longer fires while typing in chat or binding keys.
- AutoWarden sends Telegram through the shared, redirect-safe sender.

### Known limitations
- Not verified in a real client: visuals of the HUD editor / toasts / menu animations, TreeFarm and Raid behaviour, performance numbers.
- No time-of-day or particle settings, no in-world (3D) ESP outlines, TreeFarm cuts only logs within arm's reach.
- No Event Bus: Fabric's client tick and HUD callbacks are the only event sources.

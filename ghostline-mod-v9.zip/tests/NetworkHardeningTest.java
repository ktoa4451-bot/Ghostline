import com.ghostline.mod.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class NetworkHardeningTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    static class L implements SocialClient.Listener {
        final List<Map<String,String>> events = Collections.synchronizedList(new ArrayList<>());
        final List<String> states = Collections.synchronizedList(new ArrayList<>());
        public void onEvent(Map<String,String> e) { events.add(e); }
        public void onState(String s) { states.add(s); }
        boolean state(String s, int ms) throws Exception { long end = System.currentTimeMillis() + ms; while (System.currentTimeMillis() < end) { if (states.contains(s)) return true; Thread.sleep(25); } return false; }
    }

    static HttpServer server(HttpHandler h) throws Exception {
        HttpServer s = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        s.createContext("/", h); s.setExecutor(Executors.newCachedThreadPool()); s.start(); return s;
    }
    static String base(HttpServer s) { return "http://127.0.0.1:" + s.getAddress().getPort(); }

    public static void main(String[] a) throws Exception {
        // ---- readLineBounded
        check("normal LF/CRLF lines", "abc".equals(SocialClient.readLineBounded(new StringReader("abc\ndef"))) && "x".equals(SocialClient.readLineBounded(new StringReader("x\r\n"))));
        Reader two = new StringReader("one\ntwo");
        check("lines in sequence then EOF -> null", "one".equals(SocialClient.readLineBounded(two)) && "two".equals(SocialClient.readLineBounded(two)) && SocialClient.readLineBounded(two) == null);
        boolean thrown = false; try { SocialClient.readLineBounded(new StringReader("a".repeat(100_000))); } catch (IOException e) { thrown = true; }
        check("a 100000-char line is refused", thrown);
        check("a line of exactly the limit is accepted", SocialClient.readLineBounded(new StringReader("a".repeat(16 * 1024) + "\n")).length() == 16 * 1024);

        // ---- hostile server: endless line without newline
        AtomicLong sent = new AtomicLong();
        HttpServer endless = server(ex -> {
            ex.getResponseHeaders().add("Content-Type", "text/event-stream"); ex.sendResponseHeaders(200, 0);
            OutputStream o = ex.getResponseBody(); byte[] chunk = ("data: " + "a".repeat(8000)).getBytes();
            try { for (int i = 0; i < 3000; i++) { o.write(chunk); o.flush(); sent.addAndGet(chunk.length); } } catch (IOException e) { /* client hung up: good */ }
            try { ex.close(); } catch (Exception e) { }
        });
        L l1 = new L(); SocialClient c1 = new SocialClient(base(endless), "tok", l1); c1.start();
        boolean reconnecting = l1.state("reconnecting", 5000);
        c1.stop();
        check("endless line: client drops the connection and goes to reconnecting", reconnecting);
        check("endless line: client hung up early (server managed to write " + sent.get() / 1024 + " KB into OS buffers out of 23000 KB it was ready to send)", sent.get() < 12_000_000L);
        check("endless line: no event delivered", l1.events.isEmpty());
        endless.stop(0);

        // ---- garbage events between valid ones
        HttpServer garbage = server(ex -> {
            ex.getResponseHeaders().add("Content-Type", "text/event-stream"); ex.sendResponseHeaders(200, 0);
            PrintWriter w = new PrintWriter(new OutputStreamWriter(ex.getResponseBody(), StandardCharsets.UTF_8), true);
            w.print("data: {\"type\":\"hello\",\"name\":\"X\"}\n\n"); w.print("data: not json\n\n"); w.print("data: {\"a\":{\"nested\":1}}\n\n");
            w.print("data: [1,2,3]\n\n"); w.print("data: {\"type\":\"chat\",\"from\":\"A\",\"text\":\"ok\"}\n\n"); w.print(": heartbeat\n\n");
            w.print("data: {\"unterminated\":\"abc\n\n"); w.print("data: " + "{\"k\":\"" + "v".repeat(10000) + "\"}\n\n");
            w.print("data: {\"type\":\"chat\",\"from\":\"B\",\"text\":\"after\"}\n\n"); w.flush();
            try { Thread.sleep(1500); } catch (Exception e) { } ex.close();
        });
        L l2 = new L(); SocialClient c2 = new SocialClient(base(garbage), "tok", l2); c2.start();
        Thread.sleep(1200); c2.stop();
        List<String> types = new ArrayList<>(); synchronized (l2.events) { for (Map<String,String> e : l2.events) types.add(e.getOrDefault("type", "?") + ":" + e.getOrDefault("text", "")); }
        check("garbage ignored, valid events (incl. a 10 KB one) delivered " + types, types.equals(List.of("hello:", "chat:ok", "?:", "chat:after")));
        garbage.stop(0);

        HttpServer oversize = server(ex -> {
            ex.getResponseHeaders().add("Content-Type", "text/event-stream"); ex.sendResponseHeaders(200, 0);
            PrintWriter w = new PrintWriter(new OutputStreamWriter(ex.getResponseBody(), StandardCharsets.UTF_8), true);
            w.print("data: {\"type\":\"hello\"}\n\n"); w.print("data: {\"k\":\"" + "v".repeat(20000) + "\"}\n\n"); w.print("data: {\"type\":\"chat\",\"text\":\"never\"}\n\n"); w.flush();
            try { Thread.sleep(1500); } catch (Exception e) { } ex.close();
        });
        L l2b = new L(); SocialClient c2b = new SocialClient(base(oversize), "tok", l2b); c2b.start();
        boolean dropped = l2b.state("reconnecting", 3000); c2b.stop();
        boolean sawNever = false; synchronized (l2b.events) { for (Map<String,String> e : l2b.events) if ("never".equals(e.get("text"))) sawNever = true; }
        check("a 20 KB event line makes the client drop the connection (reconnecting), nothing after it is processed", dropped && !sawNever);
        oversize.stop(0);

        // ---- redirect to another host must not be followed (token would leak)
        AtomicInteger otherHits = new AtomicInteger(); AtomicReference<String> otherAuth = new AtomicReference<>();
        HttpServer other = server(ex -> { otherHits.incrementAndGet(); otherAuth.set(ex.getRequestHeaders().getFirst("Authorization")); ex.sendResponseHeaders(200, -1); ex.close(); });
        HttpServer redirector = server(ex -> { ex.getResponseHeaders().add("Location", base(other) + "/api/events"); ex.sendResponseHeaders(302, -1); ex.close(); });
        L l3 = new L(); SocialClient c3 = new SocialClient(base(redirector), "secret-token-123", l3); c3.start();
        Thread.sleep(800); c3.stop();
        check("redirect is not followed: the other server got " + otherHits.get() + " requests", otherHits.get() == 0);
        check("redirect: client keeps reconnecting instead of crashing", l3.states.contains("reconnecting") || l3.states.contains("connecting"));
        Map<String,String> claimRedirect = SocialClient.claim(base(redirector), "ABCD2345");
        check("claim through a redirect is refused (no token returned)", !claimRedirect.containsKey("token") && claimRedirect.containsKey("error") && otherHits.get() == 0);
        redirector.stop(0); other.stop(0);

        // ---- 401 -> unauthorized, stops
        HttpServer unauth = server(ex -> { ex.sendResponseHeaders(401, -1); ex.close(); });
        L l4 = new L(); SocialClient c4 = new SocialClient(base(unauth), "old", l4); c4.start();
        check("401 -> unauthorized state", l4.state("unauthorized", 3000));
        c4.stop(); unauth.stop(0);

        // ---- token only in the Authorization header, never in the URL
        AtomicReference<String> uri = new AtomicReference<>(), auth = new AtomicReference<>();
        HttpServer spy = server(ex -> { uri.set(ex.getRequestURI().toString()); auth.set(ex.getRequestHeaders().getFirst("Authorization")); ex.sendResponseHeaders(401, -1); ex.close(); });
        L l5 = new L(); SocialClient c5 = new SocialClient(base(spy), "TOKEN-ABC-123", l5); c5.start(); l5.state("unauthorized", 3000); c5.stop();
        CompletableFuture<Map<String,String>> sent2 = new CompletableFuture<>();
        new SocialClient(base(spy), "TOKEN-ABC-123", new L()).send(new LinkedHashMap<>(Map.of("type", "chat")), sent2::complete); sent2.get(5, TimeUnit.SECONDS);
        check("token is not in the request URL", uri.get() != null && !uri.get().contains("TOKEN"));
        check("token travels in the Authorization header", "Bearer TOKEN-ABC-123".equals(auth.get()));
        spy.stop(0);

        // ---- non-JSON and error answers
        HttpServer html = server(ex -> { byte[] b = "<html>502 Bad Gateway</html>".getBytes(); ex.sendResponseHeaders(502, b.length); ex.getResponseBody().write(b); ex.close(); });
        Map<String,String> r = SocialClient.claim(base(html), "ABCD2345");
        check("HTML error page -> {error}, no exception", r.containsKey("error") && !r.containsKey("token"));
        CompletableFuture<Map<String,String>> f = new CompletableFuture<>(); new SocialClient(base(html), "t", new L()).send(new LinkedHashMap<>(), f::complete);
        check("send() against a failing server reports an error", f.get(5, TimeUnit.SECONDS).containsKey("error"));
        html.stop(0);
        HttpServer huge = server(ex -> { byte[] b = ("{\"token\":\"" + "x".repeat(500_000) + "\"}").getBytes(); ex.sendResponseHeaders(200, b.length); try { ex.getResponseBody().write(b); } catch (IOException e) { } ex.close(); });
        Map<String,String> big = SocialClient.claim(base(huge), "ABCD2345");
        check("oversized reply is cut and rejected, no token accepted", !big.containsKey("token"));
        huge.stop(0);

        // ---- server down
        int dead; try (ServerSocket s = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))) { dead = s.getLocalPort(); }
        L l6 = new L(); SocialClient c6 = new SocialClient("http://127.0.0.1:" + dead, "t", l6); c6.start();
        check("server down: client reports reconnecting", l6.state("reconnecting", 4000));
        long t0 = System.currentTimeMillis(); c6.stop();
        check("stop() returns immediately (" + (System.currentTimeMillis() - t0) + " ms)", System.currentTimeMillis() - t0 < 500);
        Map<String,String> down = SocialClient.claim("http://127.0.0.1:" + dead, "ABCD2345");
        check("claim with the server down -> error map", "no connection".equals(down.get("error")));
        System.out.println("\n" + pass + " passed, " + fail + " failed"); System.exit(fail == 0 ? 0 : 1);
    }
}

import com.ghostline.mod.*;
import java.util.*;
public class UiLayoutTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) {
        int[][] res = {{640,480},{800,600},{854,480},{1024,768},{1280,720},{1280,800},{1366,768},{1440,900},{1600,900},{1680,1050},{1920,1080},{1920,1200},{2560,1080},{2560,1440},{3440,1440},{3840,2160},{5120,2880}};
        int combos = 0, bad = 0, minBw = 9999, minBh = 9999; String worstBw = "", worstBh = "";
        List<String> failures = new ArrayList<>();
        for (int[] r : res) {
            int max = UiLayout.maxScale(r[0], r[1]);
            for (int s = 1; s <= max; s++) {
                int w = UiLayout.logical(r[0], s), h = UiLayout.logical(r[1], s);
                if (w < 320 || h < 240) { failures.add("logical size below Minecraft's 320x240 floor?? " + r[0] + "x" + r[1] + " @" + s); continue; }
                UiLayout.Win k = UiLayout.window(w, h, 0);
                combos++;
                boolean ok = k.wx() >= 0 && k.wy() >= 0 && k.wx() + k.ww() <= w && k.wy() + k.wh() <= h
                    && k.bx() + k.bw() <= k.wx() + k.ww() && k.by() + k.bh() <= k.wy() + k.wh()
                    && k.bw() >= UiLayout.MIN_BODY_W && k.bh() >= UiLayout.MIN_BODY_H && k.sbw() * 2 < k.ww();
                if (!ok) { bad++; failures.add(r[0] + "x" + r[1] + " @scale " + s + " -> logical " + w + "x" + h + " " + k); }
                if (k.bw() < minBw) { minBw = k.bw(); worstBw = r[0] + "x" + r[1] + "@" + s + " (" + w + "x" + h + ")"; }
                if (k.bh() < minBh) { minBh = k.bh(); worstBh = r[0] + "x" + r[1] + "@" + s + " (" + w + "x" + h + ")"; }
            }
        }
        check(combos + " resolution/GUI-scale combinations: window fits, body >= " + UiLayout.MIN_BODY_W + "x" + UiLayout.MIN_BODY_H + " (failures: " + failures + ")", bad == 0 && failures.isEmpty());
        System.out.println("   smallest body width " + minBw + " at " + worstBw + "; smallest body height " + minBh + " at " + worstBh);
        UiLayout.Win big = UiLayout.window(3840 / 1, 2160 / 1, 0);
        check("huge logical screen: window capped at " + UiLayout.MAX_W + "x" + UiLayout.MAX_H + " and centred", big.ww() == 560 && big.wh() == 330 && big.wx() == (3840 - 560) / 2);
        UiLayout.Win t = UiLayout.window(100, 100, 0);
        check("tiny screen does not produce negative sizes", t.ww() >= 100 && t.bw() >= 0 && t.bh() >= 0);
        check("open animation only shifts the window down", UiLayout.window(480, 270, 12).wy() == UiLayout.window(480, 270, 0).wy() + 12 && UiLayout.window(480, 270, 12).ww() == UiLayout.window(480, 270, 0).ww());
        UiLayout.Win w1 = UiLayout.window(480, 270, 0);
        check("common 1080p @ GUI scale 4 (480x270) keeps the established look: 468x258, sidebar 126", w1.ww() == 468 && w1.wh() == 258 && w1.sbw() == 126);

        // scale rules
        check("maxScale 1920x1080 = 4", UiLayout.maxScale(1920, 1080) == 4);
        check("maxScale 854x480 = 2 and 640x480 = 2", UiLayout.maxScale(854, 480) == 2 && UiLayout.maxScale(640, 480) == 2);
        check("maxScale 3840x2160 = 9", UiLayout.maxScale(3840, 2160) == 9);
        check("logical size is rounded up like Minecraft", UiLayout.logical(1366, 3) == 456 && UiLayout.logical(1920, 4) == 480);

        // HUD editor toolbar
        boolean fits = true; StringBuilder why = new StringBuilder();
        for (int[] r : res) for (int s = 1; s <= UiLayout.maxScale(r[0], r[1]); s++) {
            int w = UiLayout.logical(r[0], s);
            int need = UiLayout.toolbarRows(w) == 1 ? UiLayout.TOOLBAR_ONE_ROW : UiLayout.TOOLBAR_TWO_ROWS;
            if (w < need) { fits = false; why.append(r[0]).append("x").append(r[1]).append("@").append(s).append(" "); }
        }
        check("HUD editor toolbar fits every valid combination (rows chosen by width) " + why, fits);
        check("narrow widths use two rows, wide use one", UiLayout.toolbarRows(320) == 2 && UiLayout.toolbarRows(429) == 2 && UiLayout.toolbarRows(430) == 1 && UiLayout.toolbarRows(3000) == 1);

        // ellipsize
        java.util.function.ToIntFunction<String> six = s -> s.length() * 6;
        check("short text unchanged", "abc".equals(UiLayout.ellipsize("abc", 100, six)));
        String cut = UiLayout.ellipsize("a".repeat(100), 60, six);
        check("long text is cut to fit with an ellipsis (" + cut.length() * 6 + " px <= 60)", cut.endsWith("…") && six.applyAsInt(cut) <= 60 && cut.length() > 3);
        check("width smaller than the ellipsis -> just the ellipsis", UiLayout.ellipsize("abcdef", 3, six).equals("…"));
        check("null safe", UiLayout.ellipsize(null, 10, six).isEmpty());
        System.out.println("\n" + pass + " passed, " + fail + " failed"); System.exit(fail == 0 ? 0 : 1);
    }
}

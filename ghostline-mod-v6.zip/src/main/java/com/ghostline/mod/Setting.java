package com.ghostline.mod;

import java.util.Locale;

public class Setting {
    public final String name;
    public double value;
    public final double def, min, max, step;
    public final String[] options;   // enum choices, null otherwise
    public final boolean isText;     // free text
    public final boolean isKey;      // key bind (GLFW code, -1 = none)
    public String text = "";
    public boolean prev;             // polling state for key settings
    public boolean secret;           // never written to named configs or share codes
    public String fmt = "%.2f";
    public double mul = 1.0;
    private final String defText;

    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.value = def; this.def = def;
        this.min = min; this.max = max; this.step = step; this.options = null;
        this.isText = false; this.isKey = false; this.defText = "";
    }

    public Setting(String name, int def, String... options) {
        this.name = name; this.value = def; this.def = def;
        this.min = 0; this.max = options.length - 1; this.step = 1; this.options = options;
        this.isText = false; this.isKey = false; this.defText = "";
    }

    public Setting(String name, String defText) {
        this.name = name; this.value = 0; this.def = 0;
        this.min = 0; this.max = 0; this.step = 1; this.options = null;
        this.isText = true; this.isKey = false; this.defText = defText; this.text = defText;
    }

    private Setting(String name, boolean key) {
        this.name = name; this.value = -1; this.def = -1;
        this.min = -1; this.max = 1000; this.step = 1; this.options = null;
        this.isText = false; this.isKey = true; this.defText = "";
    }

    public static Setting bool(String name, boolean def) { return new Setting(name, def ? 1 : 0, "Off", "On"); }
    public static Setting key(String name) { return new Setting(name, true); }

    public Setting fmt(String f, double m) { this.fmt = f; this.mul = m; return this; }
    public Setting secret() { this.secret = true; return this; }

    public boolean isBool() {
        return options != null && options.length == 2 && options[0].equals("Off") && options[1].equals("On");
    }

    public int i() { return (int) Math.round(value); }
    public float f() { return (float) value; }

    public void reset() { value = def; text = defText; }

    public String display() {
        if (isKey) return Config.keyName(i());
        if (isText) return text;
        if (options != null) return Lang.opt(options[Math.max(0, Math.min(options.length - 1, i()))]);
        return String.format(Locale.ROOT, fmt, value * mul);
    }
}

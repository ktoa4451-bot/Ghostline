package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Main Ghostline window: sidebar pages, expandable module cards, theme, HUD, configs, cosmetics. */
public class GhostGui extends GhostScreen {
    public static int page = 0;
    private static final Object MENU = new Object();
    private static final int PAGES = 9; // 0-4 module pages, 5 Theme, 6 HUD, 7 Configs, 8 Cosmetics

    private interface Body { int run(boolean draw, int x, int y, int w); }

    private double scroll, scrollTarget;
    private int contentH;
    private final long openedAt = System.currentTimeMillis();
    private long pageAt = openedAt;
    private Object listening;                       // Module, Setting (key) or MENU while waiting for a key
    private EditBox cfgName, cfgCode, friendBox, searchBox, wpBox;
    private final Map<Setting, EditBox> textBoxes = new HashMap<>();
    private final Set<String> open = new HashSet<>();
    private String status = "";
    private boolean statusErr;
    private long statusAt;
    private String confirm;
    private long confirmAt;
    private List<String> cfgList;
    private String tip = "";
    private float al = 1f, pa = 1f;
    private int wx, wy, ww, wh, sbw, cx, bx, by, bw, bh;

    public GhostGui() {
        super("Ghostline");
        cfgList = ConfigStore.list();
    }

    // ------------------------------------------------------------------ setup

    @Override
    protected void init() { rebuild(); }

    private EditBox makeBox(int maxLen, String hint, String value) {
        EditBox b = new EditBox(this.font, 0, 0, 100, 14, Component.empty());
        b.setBordered(false);
        b.setMaxLength(maxLen);
        b.setHint(Component.literal(hint));
        b.setValue(value);
        b.visible = false;
        addWidget(b);
        return b;
    }

    private void rebuild() {
        String keepSearch = searchBox == null ? "" : searchBox.getValue();
        clearWidgets();
        textBoxes.clear();
        cfgName = cfgCode = friendBox = wpBox = null;
        searchBox = makeBox(24, Lang.t("ui.search"), keepSearch);
        if (page == 3) wpBox = makeBox(16, Lang.t("wp.name"), "");
        if (page == 7) {
            cfgName = makeBox(24, Lang.t("cfg.name"), "");
            cfgCode = makeBox(8000, Lang.t("cfg.code"), "");
        } else if (page == 2) {
            friendBox = makeBox(16, Lang.t("ui.friend_name"), "");
        }
        for (Module m : Config.ALL) {
            for (Setting s : m.settings) if (s.isText) textBoxes.put(s, makeBox(64, Lang.set(s), s.text));
        }
    }

    private void setPage(int p) {
        page = p;
        scroll = scrollTarget = 0;
        pageAt = System.currentTimeMillis();
        confirm = null;
        listening = null;
        if (p == 7) cfgList = ConfigStore.list();
        rebuild();
    }

    public boolean isTyping() {
        return getFocused() instanceof EditBox eb && eb.isFocused();
    }

    private void setStatus(String msg, boolean err) { status = msg; statusErr = err; statusAt = System.currentTimeMillis(); }

    private boolean confirmed(String id) {
        long now = System.currentTimeMillis();
        if (id.equals(confirm) && now - confirmAt < 4000) { confirm = null; return true; }
        confirm = id;
        confirmAt = now;
        return false;
    }

    private boolean pending(String id) { return id.equals(confirm) && System.currentTimeMillis() - confirmAt < 4000; }

    private List<EditBox> allBoxes() {
        List<EditBox> all = new ArrayList<>(textBoxes.values());
        if (cfgName != null) all.add(cfgName);
        if (cfgCode != null) all.add(cfgCode);
        if (friendBox != null) all.add(friendBox);
        if (wpBox != null) all.add(wpBox);
        if (searchBox != null) all.add(searchBox);
        return all;
    }

    private void focusBox(EditBox b) {
        for (EditBox o : allBoxes()) o.setFocused(o == b);
        setFocused(b);
    }

    @Override
    protected void onBackgroundClick() {
        for (EditBox o : allBoxes()) o.setFocused(false);
        setFocused(null);
    }

    @Override
    protected void scrollBy(double amount) {
        scrollTarget = Mth.clamp(scrollTarget + amount, 0, Math.max(0, contentH - bh));
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                int v = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
                if (listening == MENU) { if (v > 0) Config.menuBind = v; }
                else if (listening instanceof Module m) m.bind = v;
                else if (listening instanceof Setting s) s.value = v;
                Config.save();
            }
            listening = null;
            return true;
        }
        if (!isTyping() && key == Config.menuBind) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    // ------------------------------------------------------------------ layout helpers

    private void layout() {
        long now = System.currentTimeMillis();
        float openT = Ui.anim() ? Mth.clamp((now - openedAt) / 220f, 0f, 1f) : 1f;
        openT = 1f - (1f - openT) * (1f - openT);
        al = openT;
        pa = Ui.anim() ? Mth.clamp((now - pageAt) / 200f, 0f, 1f) : 1f;
        ww = Math.min(this.width - 12, 560);
        wh = Math.min(this.height - 12, 330);
        wx = (this.width - ww) / 2;
        wy = (this.height - wh) / 2 + (int) ((1f - openT) * 12);
        sbw = Mth.clamp((int) (ww * 0.27f), 82, 132);
        cx = wx + sbw;
        bx = cx + 10;
        bw = ww - sbw - 20;
        by = wy + 46;
        bh = wh - 46 - 8;
    }

    private int col(int rgb, float a) { return Ui.c(rgb, a * al * pa); }
    private int chrome(int rgb, float a) { return Ui.c(rgb, a * al); }

    private List<Module> modulesOf(int category) {
        List<Module> out = new ArrayList<>();
        for (Module m : Config.ALL) if (m.category == category) out.add(m);
        out.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        return out;
    }

    private int enabledCount(int category) {
        int n = 0;
        for (Module m : Config.ALL) if (m.category == category && m.toggleable && m.enabled) n++;
        return n;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        beginFrame(mouseX, mouseY);
        layout();
        Minecraft mc = Minecraft.getInstance();
        tip = "";

        g.fill(0, 0, this.width, this.height, Ui.c(0x000000, 0.58f * al));

        for (int i = 3; i >= 1; i--) Ui.rect(g, wx - i * 2, wy - i * 2, ww + i * 4, wh + i * 4, 9 + i, chrome(0x000000, 0.10f));
        Ui.rect(g, wx, wy, ww, wh, 9, chrome(Ui.bg(), Ui.panelOpacity()));
        Ui.rect(g, wx, wy, sbw, wh, 9, chrome(Ui.side(), 0.97f));
        g.fill(wx + sbw - 9, wy, wx + sbw, wy + wh, chrome(Ui.side(), 0.97f));
        g.fill(wx + sbw, wy + 8, wx + sbw + 1, wy + wh - 8, chrome(Ui.border(), 0.8f));
        Ui.ring(g, wx, wy, ww, wh, 9, chrome(Ui.border(), 0.95f));

        g.enableScissor(cx + 2, wy + 2, wx + ww - 2, wy + wh - 2);
        Ui.wallpaper(g, cx + 2, wy + 2, ww - sbw - 4, wh - 4, al);
        g.disableScissor();

        if (Ui.bgLogo()) {
            g.enableScissor(cx + 2, wy + 2, wx + ww - 2, wy + wh - 2);
            int size = Math.min(256, Math.min(wh + 10, ww - sbw + 40));
            Ui.logo(g, Ui.LOGO_BG, wx + ww - size + size / 8, wy + wh - size + size / 8, size);
            g.disableScissor();
        }

        drawSidebar(g, mc);
        drawHeader(g);
        placeSearch(g, mouseX, mouseY, delta);

        // body
        clipX1 = bx - 4; clipY1 = by; clipX2 = bx + bw + 4; clipY2 = by + bh;
        for (EditBox b : allBoxes()) if (b != searchBox) b.visible = false;
        g.enableScissor(clipX1, clipY1, clipX2, clipY2);
        if (Ui.anim()) scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f); else scroll = scrollTarget;
        int top = by - (int) Math.round(scroll);
        int end;
        String query = searchBox == null ? "" : searchBox.getValue().trim();
        if (!query.isEmpty()) {
            end = searchView(g, top, query);
        } else {
            switch (page) {
                case 5 -> end = themeView(g, top);
                case 6 -> end = hudView(g, top);
                case 7 -> end = configsView(g, top);
                case 8 -> end = cosmeticsView(g, top);
                default -> end = modulesView(g, page, top);
            }
        }
        for (EditBox b : allBoxes()) if (b.visible && b != searchBox) b.render(g, mouseX, mouseY, delta);
        g.disableScissor();
        contentH = end - top + 6;
        scrollTarget = Mth.clamp(scrollTarget, 0, Math.max(0, contentH - bh));

        if (contentH > bh) {
            int trackH = bh - 4;
            int barH = Math.max(14, (int) (trackH * (bh / (double) contentH)));
            int barY = by + 2 + (int) ((trackH - barH) * (scroll / Math.max(1, contentH - bh)));
            Ui.rect(g, wx + ww - 7, barY, 3, barH, 1, chrome(Ui.accent(), 0.6f));
        }

        if (!tip.isEmpty()) {
            int tw = Ui.tw(tip) + 14;
            int tx = Mth.clamp(mx + 10, wx + 4, wx + ww - tw - 4), ty = Mth.clamp(my + 12, wy + 4, wy + wh - 22);
            Ui.rect(g, tx, ty, tw, 18, 7, chrome(Ui.bg(), 0.97f));
            Ui.ring(g, tx, ty, tw, 18, 7, chrome(Ui.border(), 1f));
            Ui.text(g, tip, tx + 7, ty + 5, chrome(Ui.TEXT, 1f));
        }
    }

    private void drawSidebar(GuiGraphics g, Minecraft mc) {
        Ui.logo(g, Ui.LOGO, wx + 9, wy + 8, 20);
        Ui.text(g, "Ghostline", wx + 33, wy + 14, chrome(Ui.TEXT, 1f));

        int navY = wy + 38;
        int itemH = Mth.clamp((wh - 38 - 36) / 10, 14, 20);
        for (int i = 0; i < PAGES; i++) {
            if (i == 5) {
                g.fill(wx + 12, navY + 2, wx + sbw - 12, navY + 3, chrome(Ui.border(), 0.8f));
                navY += 6;
            }
            final int idx = i;
            boolean sel = page == i;
            boolean hov = over(wx + 6, navY, sbw - 12, itemH, false);
            float hv = anim("nav" + i, sel ? 1f : (hov ? 0.55f : 0f));
            if (hv > 0.02f) Ui.rect(g, wx + 6, navY, sbw - 12, itemH, 5, chrome(Ui.mix(Ui.side(), Ui.hover(), hv), 0.95f));
            if (sel) g.fill(wx + 6, navY + 3, wx + 8, navY + itemH - 3, chrome(Ui.accent(), 1f));
            Ui.text(g, Lang.t("page." + i), wx + 14, navY + (itemH - 8) / 2, chrome(Ui.mix(Ui.MUTED, Ui.TEXT, hv), 1f));
            int cnt = i < 5 ? enabledCount(i) : (i == 8 ? ((Config.TRAIL.enabled ? 1 : 0) + (Config.WINGS.enabled ? 1 : 0)) : 0);
            if (cnt > 0) Ui.textR(g, String.valueOf(cnt), wx + sbw - 12, navY + (itemH - 8) / 2, chrome(Ui.accent(), 1f));
            hit(wx + 6, navY, sbw - 12, itemH, false, () -> setPage(idx));
            navY += itemH;
        }

        String user;
        try { user = mc.getUser().getName(); } catch (Exception e) { user = "Ghostline"; }
        g.fill(wx + 12, wy + wh - 32, wx + sbw - 12, wy + wh - 31, chrome(Ui.border(), 0.8f));
        Ui.text(g, user, wx + 12, wy + wh - 26, chrome(Ui.TEXT, 1f));
        Ui.text(g, "v1.1", wx + 12, wy + wh - 16, chrome(Ui.MUTED, 1f));
    }

    private void drawHeader(GuiGraphics g) {
        g.pose().pushMatrix();
        g.pose().translate((float) (cx + 12), (float) (wy + 10));
        g.pose().scale(1.3f, 1.3f);
        Ui.text(g, Lang.t("page." + page), 0, 0, chrome(Ui.TEXT, 1f));
        g.pose().popMatrix();

        String sub;
        boolean err = false;
        if (System.currentTimeMillis() - statusAt < 4000 && !status.isEmpty()) { sub = status; err = statusErr; }
        else sub = subtitle();
        Ui.text(g, sub, cx + 12, wy + 28, chrome(err ? Ui.DANGER : Ui.MUTED, 1f));

        int cxx = wx + ww - 24, cyy = wy + 8;
        boolean hov = over(cxx, cyy, 16, 16, false);
        float hv = anim("close", hov ? 1f : 0f);
        Ui.rect(g, cxx, cyy, 16, 16, 5, chrome(Ui.mix(Ui.card(), 0x3A2A30, hv), 0.95f));
        Ui.textC(g, "x", cxx + 8, cyy + 4, chrome(Ui.mix(Ui.MUTED, Ui.TEXT, hv), 1f));
        hit(cxx, cyy, 16, 16, false, this::onClose);

        g.fill(cx + 1, wy + 42, wx + ww - 8, wy + 43, chrome(Ui.border(), 0.6f));
    }

    private String subtitle() {
        if (page >= 0 && page <= 4) {
            int on = 0, total = 0;
            for (Module m : modulesOf(page)) if (m.toggleable) { total++; if (m.enabled) on++; }
            if (total == 0) return "";
            return String.format(Lang.t("ui.count"), on, total);
        }
        return "";
    }

    // ------------------------------------------------------------------ module pages

    private void placeSearch(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int sw = Mth.clamp(ww / 4, 70, 120);
        int sx = wx + ww - 24 - 8 - sw, sy = wy + 8;
        Ui.rect(g, sx, sy, sw, 16, 5, chrome(0x0C0C12, 0.95f));
        Ui.ring(g, sx, sy, sw, 16, 5, chrome(searchBox.isFocused() ? Ui.accent() : Ui.border(), 0.95f));
        searchBox.setX(sx + 6);
        searchBox.setY(sy + 4);
        searchBox.setWidth(sw - 12);
        searchBox.visible = true;
        searchBox.render(g, mouseX, mouseY, delta);
        hit(sx, sy, sw, 16, false, () -> focusBox(searchBox));
    }

    private int searchView(GuiGraphics g, int y, String q) {
        String ql = q.toLowerCase(Locale.ROOT);
        List<Module> res = new ArrayList<>();
        for (Module m : Config.ALL) {
            if (m.name.toLowerCase(Locale.ROOT).contains(ql) || Lang.desc(m).toLowerCase(Locale.ROOT).contains(ql)) res.add(m);
        }
        res.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        if (res.isEmpty()) {
            Ui.textC(g, Lang.t("ui.no_results"), bx + bw / 2, y + 20, col(Ui.MUTED, 1f));
            return y + 40;
        }
        return columns(g, res, y);
    }

    private int modulesView(GuiGraphics g, int category, int y) {
        return columns(g, modulesOf(category), y);
    }

    private int columns(GuiGraphics g, List<Module> mods, int y) {
        int gap = 6, cw = (bw - gap) / 2;
        int half = (mods.size() + 1) / 2;
        int ly = y, ry = y;
        for (int i = 0; i < mods.size(); i++) {
            if (i < half) ly += card(g, mods.get(i), bx, ly, cw) + gap;
            else ry += card(g, mods.get(i), bx + cw + gap, ry, cw) + gap;
        }
        return Math.max(ly, ry);
    }

    private int card(GuiGraphics g, Module m, int x, int y, int w) {
        boolean exp = open.contains(m.name);
        int headH = 26;
        int bodyH = exp ? cardBody(g, m, x + 10, 0, w - 20, false) + 10 : 0;
        int total = headH + bodyH;
        if (y + total < by || y > by + bh) return total;

        boolean hov = over(x, y, w, headH, true);
        float hv = anim("c" + m.name, hov ? 1f : 0f);
        float on = anim("on" + m.name, (m.toggleable && m.enabled) ? 1f : 0f);
        boolean isPanic = m == Config.PANIC;
        boolean warn = isPanic && pending("panic");

        Ui.rect(g, x, y, w, total, 7, col(Ui.mix(Ui.card(), Ui.hover(), hv * 0.7f), 0.92f));
        Ui.ring(g, x, y, w, total, 7, col(Ui.mix(Ui.border(), warn ? Ui.DANGER : Ui.accent(), on * 0.6f + hv * 0.3f + (warn ? 1f : 0f)), 0.95f));
        Ui.text(g, warn ? Lang.t("ui.confirm") : Lang.mod(m), x + 9, y + 9, col(warn ? Ui.DANGER : Ui.TEXT, 1f));
        if (hov && !exp && Lang.has("desc." + m.name)) tip = Lang.desc(m);

        // header zones (right to left): toggle | chevron | bind chip
        int toggleX = x + w - 32, chevX = x + w - (m.toggleable ? 50 : 22);
        if (m.toggleable) Ui.toggle(g, x + w - 28, y + 7, on, al * pa);
        Ui.textC(g, exp ? "^" : "v", chevX + 9, y + 9, col(Ui.mix(Ui.MUTED, Ui.TEXT, hv), 1f));

        hit(x, y, w, headH, true, () -> {
            if (m.toggleable) { m.enabled = !m.enabled; Config.save(); }
            else if (isPanic) { if (confirmed("panic")) CheatMod.panic(Minecraft.getInstance()); }
            else toggleOpen(m);
        });
        hit(chevX - 2, y, 22, headH, true, () -> toggleOpen(m));
        if (m.toggleable) hit(toggleX, y, 32, headH, true, () -> { m.enabled = !m.enabled; Config.save(); });

        if (exp) {
            String bl = listening == m ? "..." : (m.bind > 0 ? Config.keyName(m.bind) : Lang.t("ui.bind"));
            int cw = Math.max(36, Ui.tw(bl) + 12);
            chip(g, "bind" + m.name, bl, chevX - 6 - cw, y + 4, cw, listening == m, () -> listening = m);
            g.fill(x + 10, y + headH - 1, x + w - 10, y + headH, col(Ui.border(), 0.7f));
            cardBody(g, m, x + 10, y + headH + 4, w - 20, true);
        }
        return total;
    }

    private void toggleOpen(Module m) {
        if (!open.remove(m.name)) open.add(m.name);
    }

    private int cardBody(GuiGraphics g, Module m, int x, int y, int w, boolean draw) {
        if (m.settings.isEmpty() && m != Config.FRIENDS) {
            List<String> lines = Ui.wrap(Lang.desc(m), w);
            if (draw) for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), x, y + i * 10, col(Ui.MUTED, 1f));
            return Math.max(1, lines.size()) * 10 + 2;
        }
        int h = settingRows(g, m, m.settings, x, y, w, draw);
        if (m == Config.FRIENDS) h += friendsBody(g, x, y + h, w, draw);
        if (m == Config.WAYPOINTS) h += waypointsBody(g, x, y + h, w, draw);
        return h;
    }

    // ------------------------------------------------------------------ setting rows

    private int settingRows(GuiGraphics g, Module m, List<Setting> list, int x, int y, int w, boolean draw) {
        int h = 0;
        for (Setting s : list) {
            String id = m.name + s.name;
            if (s.isText) h += rowText(g, id, s, x, y + h, w, draw);
            else if (s.isKey) h += rowKey(g, id, s, x, y + h, w, draw);
            else if (s.isBool()) h += rowBool(g, id, s, x, y + h, w, draw);
            else if (s.options != null) h += rowEnum(g, id, s, x, y + h, w, draw);
            else h += rowNum(g, id, s, x, y + h, w, draw);
        }
        return h;
    }

    private int rowBool(GuiGraphics g, String id, Setting s, int x, int y, int w, boolean draw) {
        if (draw) {
            Ui.text(g, Lang.set(s), x, y + 6, col(Ui.TEXT, 1f));
            float on = anim("s" + id, s.i() == 1 ? 1f : 0f);
            Ui.toggle(g, x + w - 22, y + 4, on, al * pa);
            hit(x, y, w, 20, true, () -> { s.value = s.i() == 1 ? 0 : 1; Config.save(); });
        }
        return 22;
    }

    private int rowKey(GuiGraphics g, String id, Setting s, int x, int y, int w, boolean draw) {
        if (draw) {
            Ui.text(g, Lang.set(s), x, y + 6, col(Ui.TEXT, 1f));
            String lab = listening == s ? "..." : Config.keyName(s.i());
            int cw = Math.max(40, Ui.tw(lab) + 14);
            chip(g, "k" + id, lab, x + w - cw, y + 1, cw, listening == s, () -> listening = s);
        }
        return 22;
    }

    private int rowNum(GuiGraphics g, String id, Setting s, int x, int y, int w, boolean draw) {
        if (draw) {
            Ui.text(g, Lang.set(s), x, y + 2, col(Ui.TEXT, 1f));
            Ui.textR(g, s.display(), x + w, y + 2, col(Ui.MUTED, 1f));
            double frac = (s.value - s.min) / (s.max - s.min);
            int ty = y + 16;
            int kx = x + (int) (w * frac);
            Ui.rect(g, x, ty, w, 3, 1, col(Ui.border(), 1f));
            Ui.rect(g, x, ty, Math.max(1, kx - x), 3, 1, col(Ui.accent(), 1f));
            Ui.rect(g, Mth.clamp(kx - 3, x, x + w - 7), ty - 3, 7, 9, 3, col(0xF2F2F8, 1f));
            final int sx = x, sw = w;
            hitDrag(x - 2, y + 8, w + 4, 18, true, mxv -> {
                double f = Mth.clamp((mxv - sx) / (double) sw, 0.0, 1.0);
                double v = s.min + f * (s.max - s.min);
                v = Math.round(v / s.step) * s.step;
                s.value = Mth.clamp(v, s.min, s.max);
            });
        }
        return 28;
    }

    private int rowText(GuiGraphics g, String id, Setting s, int x, int y, int w, boolean draw) {
        if (draw) {
            Ui.text(g, Lang.set(s), x, y + 2, col(Ui.TEXT, 1f));
            EditBox b = textBoxes.get(s);
            Ui.rect(g, x, y + 12, w, 20, 5, col(0x0C0C12, 0.95f));
            Ui.ring(g, x, y + 12, w, 20, 5, col(Ui.border(), 0.95f));
            if (b != null) {
                placeBox(b, x + 6, y + 17, w - 12);
                if (b.isFocused()) s.text = b.getValue();
                else if (!b.getValue().equals(s.text)) b.setValue(s.text);
                hit(x, y + 12, w, 20, true, () -> focusBox(b));
            }
        }
        return 36;
    }

    private int rowEnum(GuiGraphics g, String id, Setting s, int x, int y, int w, boolean draw) {
        int n = s.options.length;
        int[] ws = new int[n];
        int total = 0;
        for (int i = 0; i < n; i++) { ws[i] = Ui.tw(Lang.opt(s.options[i])) + 10; total += ws[i]; }
        int labelW = Ui.tw(Lang.set(s));
        boolean seg = n <= 3 && labelW + total + 14 <= w;
        boolean twoLine = !seg && labelW + 74 > w;
        if (draw) {
            Ui.text(g, Lang.set(s), x, y + 6, col(Ui.TEXT, 1f));
            if (seg) {
                int px = x + w - total;
                Ui.rect(g, px - 2, y + 1, total + 4, 18, 6, col(Ui.hover(), 0.9f));
                int cur = px;
                for (int i = 0; i < n; i++) {
                    final int idx = i;
                    boolean sel = s.i() == i;
                    float t = anim("seg" + id + i, sel ? 1f : 0f);
                    if (t > 0.02f) Ui.rect(g, cur, y + 2, ws[i], 16, 5, col(Ui.mix(Ui.hover(), Ui.accent(), 0.55f * t), 1f));
                    Ui.textC(g, Lang.opt(s.options[i]), cur + ws[i] / 2, y + 6, col(sel ? Ui.TEXT : Ui.MUTED, 1f));
                    hit(cur, y + 1, ws[i], 18, true, () -> { s.value = idx; Config.save(); });
                    cur += ws[i];
                }
            } else {
                int cw = twoLine ? w : Math.min(w - labelW - 10, 140);
                int cxp = x + w - cw;
                int cy = twoLine ? y + 14 : y + 1;
                chip(g, "e" + id, s.display(), cxp, cy, cw, false, () -> { s.value = (s.i() + 1) % s.options.length; Config.save(); });
            }
        }
        return twoLine ? 36 : 22;
    }

    private void placeBox(EditBox b, int x, int y, int w) {
        b.setX(x);
        b.setY(y);
        b.setWidth(w);
        b.visible = y >= by - 2 && y + 14 <= by + bh + 2;
    }

    private void chip(GuiGraphics g, String id, String label, int x, int y, int w, boolean active, Runnable r) {
        boolean hov = over(x, y, w, 18, true);
        float t = anim("chip" + id, active ? 1f : (hov ? 0.5f : 0f));
        Ui.rect(g, x, y, w, 18, 5, col(Ui.mix(Ui.hover(), Ui.accent(), t * 0.35f), 0.95f));
        Ui.ring(g, x, y, w, 18, 5, col(Ui.mix(Ui.border(), Ui.accent(), t), 0.95f));
        Ui.textC(g, label, x + w / 2, y + 5, col(Ui.TEXT, 1f));
        hit(x, y, w, 18, true, r);
    }

    private void smallButton(GuiGraphics g, String id, String label, int x, int y, int w, boolean warn, Runnable r) {
        int h = 20;
        boolean hov = over(x, y, w, h, true);
        float t = anim("sb" + id, hov ? 1f : 0f);
        int accent = warn ? Ui.DANGER : Ui.accent();
        Ui.rect(g, x, y, w, h, 5, col(Ui.mix(Ui.hover(), accent, t * 0.4f + (warn ? 0.3f : 0f)), 0.95f));
        Ui.ring(g, x, y, w, h, 5, col(Ui.mix(Ui.border(), accent, t * 0.9f + (warn ? 0.7f : 0f)), 0.95f));
        Ui.textC(g, label, x + w / 2, y + 6, col(Ui.TEXT, 1f));
        hit(x, y, w, h, true, r);
    }

    private void inputBg(GuiGraphics g, int x, int y, int w) {
        Ui.rect(g, x, y, w, 22, 6, col(0x0C0C12, 0.95f));
        Ui.ring(g, x, y, w, 22, 6, col(Ui.border(), 0.95f));
    }

    // ------------------------------------------------------------------ panels

    private int panel(GuiGraphics g, String title, Module toggle, int x, int y, int w, Body body) {
        int bodyH = body.run(false, x + 10, 0, w - 20);
        int total = 30 + bodyH + 8;
        if (y + total >= by && y <= by + bh) {
            Ui.rect(g, x, y, w, total, 8, col(Ui.card(), 0.88f));
            Ui.ring(g, x, y, w, total, 8, col(Ui.border(), 0.8f));
            Ui.text(g, title, x + 10, y + 10, col(Ui.TEXT, 1f));
            if (toggle != null) {
                float on = anim("pt" + title, toggle.enabled ? 1f : 0f);
                Ui.toggle(g, x + w - 32, y + 8, on, al * pa);
                hit(x + w - 36, y + 4, 36, 20, true, () -> { toggle.enabled = !toggle.enabled; Config.save(); });
            }
            g.fill(x + 10, y + 26, x + w - 10, y + 27, col(Ui.border(), 0.7f));
            body.run(true, x + 10, y + 34, w - 20);
        }
        return total + 6;
    }

    // ------------------------------------------------------------------ theme

    private int themeView(GuiGraphics g, int y) {
        y += panel(g, Lang.t("theme.title"), null, bx, y, bw, (d, x, yy, w) -> presetTiles(g, d, x, yy, w));
        y += panel(g, Lang.t("theme.interface"), null, bx, y, bw, (d, x, yy, w) -> {
            int h = settingRows(g, Config.THEME, List.of(Config.THEME.get(1), Config.THEME.get(2), Config.THEME.get(3), Config.THEME.get(7)), x, yy, w, d);
            h += langRow(g, d, x, yy + h, w);
            h += menuKeyRow(g, d, x, yy + h, w);
            return h;
        });
        y += panel(g, Lang.t("theme.custom"), null, bx, y, bw, (d, x, yy, w) -> {
            int h = settingRows(g, Config.THEME, Config.THEME.settings.subList(4, 7), x, yy, w, d);
            if (d) {
                Ui.Preset cp = Ui.presetAt(15);
                Ui.rect(g, x, yy + h, w, 10, 4, col(cp.accent, 1f));
            }
            return h + 14;
        });
        return y;
    }

    private int presetTiles(GuiGraphics g, boolean draw, int x, int y, int w) {
        int[][] groups = {{0, 0}, {1, 5}, {6, 14}, {15, 15}};
        int tw = 70, th = 30, gap = 6;
        int cols = Math.max(1, (w + gap) / (tw + gap));
        int h = 0;
        for (int gi = 0; gi < groups.length; gi++) {
            int a = groups[gi][0], b = groups[gi][1];
            if (draw) Ui.text(g, Lang.t("theme.g" + gi).toUpperCase(Locale.ROOT), x, y + h, col(Ui.MUTED, 1f));
            h += 13;
            int n = b - a + 1;
            int rows = (n + cols - 1) / cols;
            if (draw) {
                for (int k = 0; k < n; k++) {
                    int tx = x + (k % cols) * (tw + gap);
                    int ty = y + h + (k / cols) * (th + 18);
                    presetTile(g, a + k, tx, ty, tw, th);
                }
            }
            h += rows * (th + 18) + 2;
        }
        return h;
    }

    private void presetTile(GuiGraphics g, int idx, int x, int y, int tw, int th) {
        Ui.Preset p = Ui.presetAt(idx);
        boolean sel = Config.THEME.get(0).i() == idx;
        boolean hov = over(x, y, tw, th + 14, true);
        float t = anim("pt" + idx, sel ? 1f : (hov ? 0.5f : 0f));
        Ui.rect(g, x, y, tw, th, 6, col(p.bg, 1f));
        Ui.ring(g, x, y, tw, th, 6, col(Ui.mix(p.border, p.accent, t), 1f));
        Ui.rect(g, x + 7, y + 7, 22, 4, 2, col(p.accent, 1f));
        Ui.rect(g, x + 7, y + 15, 34, 3, 1, col(p.hover, 1f));
        Ui.rect(g, x + 7, y + 21, 22, 3, 1, col(p.hover, 1f));
        if (sel) Ui.rect(g, x + tw - 13, y + 7, 6, 6, 3, col(p.accent, 1f));
        String name = Lang.opt(Ui.PRESET_NAMES[idx]);
        Ui.textC(g, name, x + tw / 2, y + th + 4, col(sel ? Ui.TEXT : Ui.MUTED, 1f));
        hit(x, y, tw, th + 14, true, () -> { Config.THEME.get(0).value = idx; Config.save(); });
    }

    private int langRow(GuiGraphics g, boolean draw, int x, int y, int w) {
        if (draw) {
            Ui.text(g, Lang.t("ui.lang_label"), x, y + 6, col(Ui.TEXT, 1f));
            int cw = 66, gap = 4;
            int x2 = x + w - cw, x1 = x2 - cw - gap;
            langChip(g, "English", 0, x1, y + 1, cw);
            langChip(g, "Русский", 1, x2, y + 1, cw);
        }
        return 22;
    }

    private void langChip(GuiGraphics g, String label, int value, int x, int y, int w) {
        boolean sel = Config.lang == value;
        boolean hov = over(x, y, w, 18, true);
        float t = anim("lang" + value, sel ? 1f : (hov ? 0.4f : 0f));
        Ui.rect(g, x, y, w, 18, 5, col(Ui.mix(Ui.hover(), Ui.accent(), t * 0.55f), 0.95f));
        Ui.ring(g, x, y, w, 18, 5, col(Ui.mix(Ui.border(), Ui.accent(), t), 0.95f));
        Ui.textC(g, label, x + w / 2, y + 5, col(Ui.TEXT, 1f));
        hit(x, y, w, 18, true, () -> { Config.lang = value; Config.save(); rebuild(); });
    }

    private int menuKeyRow(GuiGraphics g, boolean draw, int x, int y, int w) {
        if (draw) {
            Ui.text(g, Lang.t("ui.menu_key"), x, y + 6, col(Ui.TEXT, 1f));
            String lab = listening == MENU ? "..." : Config.keyName(Config.menuBind);
            int cw = Math.max(60, Ui.tw(lab) + 14);
            chip(g, "menukey", lab, x + w - cw, y + 1, cw, listening == MENU, () -> listening = MENU);
        }
        return 22;
    }

    // ------------------------------------------------------------------ HUD

    private int hudView(GuiGraphics g, int y) {
        List<Setting> all = Config.HUD.settings;
        y += panel(g, Lang.t("hud.title"), Config.HUD, bx, y, bw, (d, x, yy, w) -> settingRows(g, Config.HUD, all.subList(0, 7), x, yy, w, d));
        y += panel(g, Lang.t("hud.layout"), null, bx, y, bw, (d, x, yy, w) -> settingRows(g, Config.HUD, all.subList(7, 11), x, yy, w, d));
        y += panel(g, Lang.t("hud.style"), null, bx, y, bw, (d, x, yy, w) -> settingRows(g, Config.HUD, all.subList(11, 15), x, yy, w, d));
        return y;
    }

    // ------------------------------------------------------------------ cosmetics

    private static final int[] TRAIL_COLORS = {0xE8E4FF, 0x5DE1E6, 0xFF6B8A, 0x7CFC8A, 0xA78BFA, 0xDDE6F0};

    private int cosmeticsView(GuiGraphics g, int y) {
        y += panel(g, Lang.t("cos.title"), Config.TRAIL, bx, y, bw, (d, x, yy, w) -> {
            int h = settingRows(g, Config.TRAIL, Config.TRAIL.settings.subList(1, 3), x, yy, w, d);
            if (d) smallButton(g, "cosoff", Lang.t("cos.remove"), x, yy + h + 2, w, false, () -> { Config.TRAIL.enabled = false; Config.save(); });
            return h + 26;
        });
        y += panel(g, Lang.t("cos.trail"), null, bx, y, bw, (d, x, yy, w) -> trailTiles(g, d, x, yy, w));
        y += panel(g, Lang.t("cos.wings"), Config.WINGS, bx, y, bw, (d, x, yy, w) -> settingRows(g, Config.WINGS, Config.WINGS.settings, x, yy, w, d));
        return y;
    }

    private int trailTiles(GuiGraphics g, boolean draw, int x, int y, int w) {
        int tw = 70, th = 40, gap = 6;
        int cols = Math.max(1, (w + gap) / (tw + gap));
        int n = TRAIL_COLORS.length;
        int rows = (n + cols - 1) / cols;
        if (draw) {
            Setting st = Config.TRAIL.get(0);
            for (int i = 0; i < n; i++) {
                final int idx = i;
                int tx = x + (i % cols) * (tw + gap);
                int ty = y + (i / cols) * (th + 18);
                boolean sel = st.i() == i;
                boolean hov = over(tx, ty, tw, th + 14, true);
                float t = anim("trail" + i, sel ? 1f : (hov ? 0.5f : 0f));
                Ui.rect(g, tx, ty, tw, th, 7, col(Ui.hover(), 0.95f));
                Ui.ring(g, tx, ty, tw, th, 7, col(Ui.mix(Ui.border(), Ui.accent(), t), 1f));
                int c = TRAIL_COLORS[i];
                Ui.rect(g, tx + tw / 2 - 9, ty + 9, 18, 18, 9, col(Ui.mix(c, 0x000000, 0.45f), 1f));
                Ui.rect(g, tx + tw / 2 - 5, ty + 13, 10, 10, 5, col(c, 1f));
                Ui.textC(g, Lang.opt(st.options[i]), tx + tw / 2, ty + th + 4, col(sel ? Ui.TEXT : Ui.MUTED, 1f));
                hit(tx, ty, tw, th + 14, true, () -> { st.value = idx; Config.TRAIL.enabled = true; Config.save(); });
            }
        }
        return rows * (th + 18);
    }

    // ------------------------------------------------------------------ friends (inside the Player > Friends card)

    private void addFriend(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (n.isEmpty()) return;
        Config.FRIENDS_SET.add(n);
        Config.save();
        if (friendBox != null) friendBox.setValue("");
    }

    private int friendsBody(GuiGraphics g, int x, int y, int w, boolean draw) {
        int h = 0;
        if (friendBox != null) {
            if (draw) {
                inputBg(g, x, y + h, w - 62);
                placeBox(friendBox, x + 6, y + h + 5, w - 74);
                hit(x, y + h, w - 62, 22, true, () -> focusBox(friendBox));
                smallButton(g, "frAdd", Lang.t("ui.add"), x + w - 56, y + h + 1, 56, false, () -> addFriend(friendBox.getValue()));
            }
            h += 26;
        }
        if (draw) {
            smallButton(g, "frLook", Lang.t("ui.add_looked"), x, y + h, w, false, () -> {
                HitResult hr = Minecraft.getInstance().hitResult;
                if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof Player pl) addFriend(pl.getName().getString());
            });
        }
        h += 24;
        if (Config.FRIENDS_SET.isEmpty()) {
            if (draw) Ui.textC(g, Lang.t("fr.empty"), x + w / 2, y + h + 2, col(Ui.MUTED, 1f));
            h += 16;
        } else {
            for (String name : new ArrayList<>(Config.FRIENDS_SET)) {
                if (draw) {
                    Ui.text(g, name, x + 2, y + h + 6, col(Ui.TEXT, 1f));
                    smallButton(g, "frDel" + name, Lang.t("fr.remove"), x + w - 62, y + h + 1, 62, false, () -> {
                        Config.FRIENDS_SET.remove(name);
                        Config.save();
                    });
                }
                h += 24;
            }
        }
        return h;
    }

    // ------------------------------------------------------------------ waypoints (inside the Visuals > Waypoints card)

    private void addWaypoint() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        String n = wpBox == null ? "" : wpBox.getValue().trim().replace("|", "").replace(";", "");
        if (n.isEmpty()) n = "WP " + (Config.WAYPOINTS_LIST.size() + 1);
        Config.WAYPOINTS_LIST.add(new Config.Waypoint(n, mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ()));
        Config.save();
        if (wpBox != null) wpBox.setValue("");
    }

    private int waypointsBody(GuiGraphics g, int x, int y, int w, boolean draw) {
        int h = 0;
        if (wpBox != null) {
            if (draw) {
                inputBg(g, x, y + h, w - 62);
                placeBox(wpBox, x + 6, y + h + 5, w - 74);
                hit(x, y + h, w - 62, 22, true, () -> focusBox(wpBox));
                smallButton(g, "wpAdd", Lang.t("ui.add"), x + w - 56, y + h + 1, 56, false, this::addWaypoint);
            }
            h += 26;
        }
        if (Config.WAYPOINTS_LIST.isEmpty()) {
            if (draw) Ui.textC(g, Lang.t("wp.empty"), x + w / 2, y + h + 2, col(Ui.MUTED, 1f));
            h += 16;
        } else {
            for (Config.Waypoint wp : new ArrayList<>(Config.WAYPOINTS_LIST)) {
                if (draw) {
                    Ui.text(g, wp.name, x + 2, y + h + 2, col(Ui.TEXT, 1f));
                    Ui.text(g, wp.x + " " + wp.y + " " + wp.z, x + 2, y + h + 13, col(Ui.MUTED, 1f));
                    smallButton(g, "wpDel" + wp.name + wp.x + wp.z, Lang.t("fr.remove"), x + w - 62, y + h + 3, 62, false, () -> {
                        Config.WAYPOINTS_LIST.remove(wp);
                        Config.save();
                    });
                }
                h += 28;
            }
        }
        return h;
    }

    // ------------------------------------------------------------------ configs

    private int configsView(GuiGraphics g, int y) {
        y = configsList(g, y);
        y += panel(g, Lang.t("hk.title"), null, bx, y + 4, bw, (d, x, yy, w) -> hotkeysBody(g, d, x, yy, w)) + 4;
        return y;
    }

    private int hotkeysBody(GuiGraphics g, boolean draw, int x, int y, int w) {
        int h = 0;
        for (Module m : Config.ALL) {
            if (m.bind <= 0) continue;
            if (draw) {
                Ui.text(g, Lang.mod(m), x + 2, y + h + 6, col(Ui.TEXT, 1f));
                String kn = Config.keyName(m.bind);
                int cw = Math.max(34, Ui.tw(kn) + 12);
                chip(g, "hk" + m.name, kn, x + w - cw - 28, y + h + 1, cw, false, () -> { });
                smallButton(g, "hkx" + m.name, "x", x + w - 22, y + h + 1, 22, false, () -> { m.bind = -1; Config.save(); });
            }
            h += 24;
        }
        if (h == 0) {
            if (draw) Ui.text(g, Lang.t("hk.empty"), x + 2, y + 4, col(Ui.MUTED, 1f));
            h = 16;
        }
        return h;
    }

    private int configsList(GuiGraphics g, int y) {
        int btnW = 86, inW = bw - btnW - 20;

        inputBg(g, bx, y, bw - btnW - 6);
        placeBox(cfgName, bx + 6, y + 5, inW);
        hit(bx, y, bw - btnW - 6, 22, true, () -> focusBox(cfgName));
        String saveLabel = pending("save") ? Lang.t("cfg.overwrite") : Lang.t("cfg.save");
        smallButton(g, "cfgsave", saveLabel, bx + bw - btnW, y + 1, btnW, pending("save"), this::doSave);
        y += 28;

        inputBg(g, bx, y, bw - btnW - 6);
        placeBox(cfgCode, bx + 6, y + 5, inW);
        hit(bx, y, bw - btnW - 6, 22, true, () -> focusBox(cfgCode));
        smallButton(g, "cfgfind", Lang.t("cfg.find"), bx + bw - btnW, y + 1, btnW, false, this::doImport);
        y += 28;

        smallButton(g, "cfgcopy", Lang.t("cfg.copy"), bx, y, bw, false, this::doCopy);
        y += 28;

        if (cfgList.isEmpty()) {
            Ui.textC(g, Lang.t("cfg.empty"), bx + bw / 2, y + 14, col(Ui.TEXT, 1f));
            Ui.textC(g, Lang.t("cfg.empty_hint"), bx + bw / 2, y + 28, col(Ui.MUTED, 1f));
            return y + 46;
        }
        for (String name : new ArrayList<>(cfgList)) {
            Ui.rect(g, bx, y, bw, 24, 6, col(Ui.card(), 0.88f));
            Ui.ring(g, bx, y, bw, 24, 6, col(Ui.border(), 0.7f));
            Ui.text(g, name, bx + 10, y + 8, col(Ui.TEXT, 1f));
            int dw = 64, lw = 56;
            boolean pend = pending("del:" + name);
            smallButton(g, "del" + name, pend ? Lang.t("cfg.sure") : Lang.t("cfg.delete"), bx + bw - dw - 4, y + 2, dw, pend, () -> doDelete(name));
            smallButton(g, "load" + name, Lang.t("cfg.load"), bx + bw - dw - lw - 8, y + 2, lw, false, () -> doLoad(name));
            y += 28;
        }
        return y;
    }

    private void doSave() {
        String n = ConfigStore.clean(cfgName == null ? "" : cfgName.getValue());
        if (n.isEmpty()) { setStatus(Lang.t("cfg.bad_name"), true); return; }
        if (ConfigStore.exists(n) && !confirmed("save")) return;
        confirm = null;
        try {
            ConfigStore.save(n);
            cfgList = ConfigStore.list();
            setStatus(String.format(Lang.t("cfg.saved"), n), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doLoad(String name) {
        try {
            ConfigStore.load(name);
            Config.save();
            rebuild();
            setStatus(String.format(Lang.t("cfg.loaded"), name), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doDelete(String name) {
        if (!confirmed("del:" + name)) return;
        try {
            ConfigStore.delete(name);
            cfgList = ConfigStore.list();
            setStatus(String.format(Lang.t("cfg.deleted"), name), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doCopy() {
        try {
            Minecraft.getInstance().keyboardHandler.setClipboard(ConfigStore.export());
            setStatus(Lang.t("cfg.copied"), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doImport() {
        String code = cfgCode == null ? "" : cfgCode.getValue().trim();
        if (code.isEmpty()) code = Minecraft.getInstance().keyboardHandler.getClipboard().trim();
        if (code.isEmpty()) { setStatus(Lang.t("cfg.bad_code"), true); return; }
        try {
            ConfigStore.importCode(code);
            Config.save();
            setStatus(Lang.t("cfg.imported"), false);
        } catch (Exception e) { setStatus(Lang.t("cfg.bad_code"), true); }
    }
}

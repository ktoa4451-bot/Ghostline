#!/usr/bin/env node
'use strict';
/**
 * Ghostline friends server. No dependencies (Node 18+).
 *
 *   node ghostline-server.js            # listens on 127.0.0.1:8787, data in ./data.json
 *   PORT=9000 HOST=0.0.0.0 DATA=/var/lib/gl/data.json node ghostline-server.js
 *
 * Passwords never reach the Minecraft client: you register / log in on the web page this server serves ("/"),
 * get a one-time pairing code, and type that code into the Ghostline menu. The client exchanges it for a session token.
 * The server keeps scrypt hashes of passwords and SHA-256 hashes of session tokens, and never logs request bodies,
 * passwords, tokens or pairing codes.
 *
 * It speaks plain HTTP. For anything except localhost put it behind an HTTPS reverse proxy (Caddy, nginx);
 * the Ghostline client refuses plain http:// to non-local addresses.
 */
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.PORT || '8787', 10);
const HOST = process.env.HOST || '127.0.0.1';
const DATA = process.env.DATA || path.join(__dirname, 'data.json');
const PAIR_TTL_MS = 5 * 60 * 1000;
const MAX_BODY = 4096;
const MAX_FRIENDS = 100;
const MAX_TEXT = 256;
const REG_PER_MIN = parseInt(process.env.REG_PER_MIN || '5', 10); // new accounts per minute per IP
const STATES = ['online', 'away', 'busy', 'invisible'];

// ---------------------------------------------------------------- storage
let db = { users: {}, sessions: {} }; // users[lowerName] = {name, salt, hash, friends[], incoming[], privacy{}, status{}}
try { db = JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) { /* first run */ }
db.users = db.users || {}; db.sessions = db.sessions || {};
let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try { fs.writeFileSync(DATA + '.tmp', JSON.stringify(db)); fs.renameSync(DATA + '.tmp', DATA); }
    catch (e) { console.error('save failed'); }
  }, 300);
}

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const now = () => Date.now();

// ---------------------------------------------------------------- state in memory
const streams = new Map();   // lowerName -> Set(res)
const pairing = new Map();   // codeHash -> {user, exp}
const buckets = new Map();   // rate limit key -> {n, reset}

function limit(key, max, windowMs) {
  const t = now();
  let b = buckets.get(key);
  if (!b || t > b.reset) { b = { n: 0, reset: t + windowMs }; buckets.set(key, b); }
  b.n++;
  return b.n <= max;
}
setInterval(() => { const t = now(); for (const [k, b] of buckets) if (t > b.reset) buckets.delete(k); for (const [k, p] of pairing) if (t > p.exp) pairing.delete(k); }, 60000).unref();

// ---------------------------------------------------------------- helpers
const NAME_RE = /^[A-Za-z0-9_]{3,16}$/;
function cleanText(s, max) {
  if (typeof s !== 'string') return '';
  return s.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max || MAX_TEXT);
}
function json(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(b);
}
function readBody(req, res, cb) {
  let size = 0; const chunks = [];
  req.on('data', (c) => {
    size += c.length;
    if (size > MAX_BODY) { json(res, 413, { error: 'body too large' }); req.destroy(); return; }
    chunks.push(c);
  });
  req.on('end', () => {
    if (res.writableEnded) return;
    try { const o = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); if (o === null || typeof o !== 'object' || Array.isArray(o)) throw 0; cb(o); }
    catch (e) { json(res, 400, { error: 'bad json' }); }
  });
}
function ip(req) { return req.socket.remoteAddress || '?'; }
function hashPass(pass, salt) { return crypto.scryptSync(pass, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex'); }
function safeEq(a, b) { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && crypto.timingSafeEqual(x, y); }

function auth(req) {
  const h = req.headers['authorization'] || '';
  if (!h.startsWith('Bearer ')) return null;
  const s = db.sessions[sha(h.slice(7).trim())];
  if (!s) return null;
  return db.users[s.user] ? s.user : null;
}

function isOnline(u) { const s = streams.get(u); return !!s && s.size > 0; }
function stateOf(u) { const st = (db.users[u] && db.users[u].status) || {}; return STATES.includes(st.state) ? st.state : 'online'; }
/** What `viewer` is allowed to see about `target`: offline unless target is connected, visible to friends and a friend of viewer. */
function visibleState(target, viewer) {
  const t = db.users[target];
  if (!t || !isOnline(target)) return 'offline';
  if (stateOf(target) === 'invisible') return 'offline';
  if ((t.privacy || {}).showOnline === 'nobody') return 'offline';
  if (!t.friends.includes(viewer)) return 'offline';
  return stateOf(target);
}
function emit(u, obj) {
  const set = streams.get(u);
  if (!set) return;
  const line = 'data: ' + JSON.stringify(obj) + '\n\n';
  for (const r of set) { try { r.write(line); } catch (e) { /* closed */ } }
}
function display(u) { return db.users[u].name; }
function friendsLine(u) {
  return db.users[u].friends.map((f) => display(f) + ':' + visibleState(f, u)).join(',');
}
function notifyFriends(u, obj) {
  for (const f of db.users[u].friends) if (db.users[f] && db.users[f].friends.includes(u)) emit(f, obj);
}
function announce(u) {
  const st = visibleStateForAll(u);
  notifyFriends(u, { type: 'friend.state', name: display(u), state: st, note: st === 'offline' ? '' : cleanText((db.users[u].status || {}).note, 40) });
}
function visibleStateForAll(u) { // as seen by a friend
  const t = db.users[u];
  if (!isOnline(u) || stateOf(u) === 'invisible' || (t.privacy || {}).showOnline === 'nobody') return 'offline';
  return stateOf(u);
}

// ---------------------------------------------------------------- web page (register / pairing code)
const PAGE = `<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Ghostline</title><style>body{font:16px system-ui;background:#0f1117;color:#e8e4ff;max-width:420px;margin:40px auto;padding:0 16px}
input,button{width:100%;box-sizing:border-box;padding:10px;margin:6px 0;border-radius:8px;border:1px solid #3a3f55;background:#181b26;color:#e8e4ff;font:inherit}
button{background:#6d5bd0;border:0;cursor:pointer}h1{font-size:22px}small{color:#9aa0ae}#out{margin-top:14px;font-size:20px;letter-spacing:2px;word-break:break-all}</style>
<h1>Ghostline friends</h1><small>The password stays on this page. Minecraft only gets a one-time pairing code.</small>
<input id=u placeholder="Minecraft nickname" maxlength=16 autocomplete=username>
<input id=p type=password placeholder="Password (8+ characters)" autocomplete=current-password>
<button onclick="go('register')">Create account</button><button onclick="go('pair')">Get pairing code</button><div id=out></div>
<script>async function go(a){const r=await fetch('/api/'+a,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user:u.value,pass:p.value})});
const j=await r.json();out.textContent=j.code?('Code: '+j.code+' (valid 5 min, one use)'):(j.ok?'Account created. Now press "Get pairing code".':('Error: '+(j.error||r.status)));}</script>`;

// ---------------------------------------------------------------- friend operations
function areFriends(a, b) { return db.users[a].friends.includes(b); }

function handleSend(u, body, res) {
  if (!limit('send:' + u, 30, 10000)) return json(res, 429, { error: 'slow down' });
  const me = db.users[u];
  const type = typeof body.type === 'string' ? body.type : '';
  const target = typeof body.name === 'string' || typeof body.to === 'string' ? String(body.name || body.to).toLowerCase() : '';

  switch (type) {
    case 'status': {
      const state = STATES.includes(body.state) ? body.state : 'online';
      me.status = { state, note: cleanText(body.note, 40) };
      save(); announce(u);
      return json(res, 200, { ok: true });
    }
    case 'privacy': {
      me.privacy = {
        showOnline: body.showOnline === 'nobody' ? 'nobody' : 'friends',
        friendRequests: body.friendRequests === 'nobody' ? 'nobody' : 'everyone',
      };
      save(); announce(u);
      return json(res, 200, { ok: true });
    }
    case 'friend.add': {
      if (!db.users[target] || target === u) return json(res, 404, { error: 'no such player' });
      if (!limit('fadd:' + u, 10, 60000)) return json(res, 429, { error: 'slow down' });
      if (areFriends(u, target)) return json(res, 409, { error: 'already friends' });
      const t = db.users[target];
      if ((t.privacy || {}).friendRequests === 'nobody') return json(res, 403, { error: 'this player does not accept requests' });
      if (me.incoming.includes(target)) { // they already asked us: accept
        return acceptFriend(u, target, res);
      }
      if (!t.incoming.includes(u)) { if (t.incoming.length >= 50) return json(res, 429, { error: 'too many requests' }); t.incoming.push(u); save(); }
      emit(target, { type: 'friend.request', name: display(u) });
      return json(res, 200, { ok: true });
    }
    case 'friend.accept': {
      if (!db.users[target] || !me.incoming.includes(target)) return json(res, 404, { error: 'no such request' });
      return acceptFriend(u, target, res);
    }
    case 'friend.decline': {
      me.incoming = me.incoming.filter((x) => x !== target); save();
      return json(res, 200, { ok: true });
    }
    case 'friend.remove': {
      if (!db.users[target]) return json(res, 404, { error: 'no such player' });
      me.friends = me.friends.filter((x) => x !== target);
      db.users[target].friends = db.users[target].friends.filter((x) => x !== u);
      save();
      emit(target, { type: 'friend.removed', name: display(u) });
      emit(u, { type: 'friend.removed', name: display(target) });
      return json(res, 200, { ok: true });
    }
    case 'chat': {
      const text = cleanText(body.text, MAX_TEXT);
      if (!text) return json(res, 400, { error: 'empty message' });
      if (target === '*' || target === '') { // to all friends
        let n = 0;
        for (const f of me.friends) if (areFriends(f, u) && isOnline(f)) { emit(f, { type: 'chat', from: display(u), text, scope: 'all' }); n++; }
        return json(res, 200, { ok: true, delivered: n });
      }
      if (!db.users[target] || !areFriends(u, target) || !areFriends(target, u)) return json(res, 403, { error: 'not friends' });
      if (!isOnline(target)) return json(res, 200, { ok: true, delivered: 0 });
      emit(target, { type: 'chat', from: display(u), text, scope: 'private' });
      return json(res, 200, { ok: true, delivered: 1 });
    }
    case 'help': {
      if (!limit('help:' + u, 3, 30000)) return json(res, 429, { error: 'help requests are limited' });
      const msg = { type: 'help', from: display(u), text: cleanText(body.text, 120) || 'Need help!' };
      // coordinates are forwarded only when the sender's client included them, and only to friends
      const num = (v) => (Number.isFinite(v) && Math.abs(v) < 3e7 ? Math.round(v) : null);
      if (body.coords === true && num(body.x) !== null && num(body.y) !== null && num(body.z) !== null) {
        msg.x = num(body.x); msg.y = num(body.y); msg.z = num(body.z); msg.dim = cleanText(body.dim, 40);
      }
      if (typeof body.server === 'string') msg.server = cleanText(body.server, 60);
      let n = 0;
      for (const f of me.friends) if (areFriends(f, u) && isOnline(f)) { emit(f, msg); n++; }
      return json(res, 200, { ok: true, delivered: n, coords: msg.x !== undefined });
    }
    default:
      return json(res, 400, { error: 'unknown type' });
  }
}
function acceptFriend(u, other, res) {
  const me = db.users[u], o = db.users[other];
  me.incoming = me.incoming.filter((x) => x !== other);
  o.incoming = o.incoming.filter((x) => x !== u);
  if (me.friends.length >= MAX_FRIENDS || o.friends.length >= MAX_FRIENDS) return json(res, 409, { error: 'friend list full' });
  if (!me.friends.includes(other)) me.friends.push(other);
  if (!o.friends.includes(u)) o.friends.push(u);
  save();
  emit(u, { type: 'friend.added', name: display(other), state: visibleState(other, u) });
  emit(other, { type: 'friend.added', name: display(u), state: visibleState(u, other) });
  return json(res, 200, { ok: true });
}

// ---------------------------------------------------------------- server
const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  try {
    if (req.method === 'GET' && url === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'", 'X-Frame-Options': 'DENY' });
      return res.end(PAGE);
    }
    if (req.method === 'GET' && url === '/api/events') {
      const u = auth(req);
      if (!u) return json(res, 401, { error: 'unauthorized' });
      if ((streams.get(u) || new Set()).size >= 3) return json(res, 429, { error: 'too many connections' });
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      if (!streams.has(u)) streams.set(u, new Set());
      streams.get(u).add(res);
      const me = db.users[u];
      res.write('data: ' + JSON.stringify({ type: 'hello', name: display(u), friends: friendsLine(u), incoming: me.incoming.map(display).join(','),
        showOnline: (me.privacy || {}).showOnline || 'friends', friendRequests: (me.privacy || {}).friendRequests || 'everyone' }) + '\n\n');
      announce(u);
      const hb = setInterval(() => { try { res.write(': hb\n\n'); } catch (e) { /* closed */ } }, 20000);
      req.on('close', () => { clearInterval(hb); const s = streams.get(u); if (s) { s.delete(res); if (!s.size) { streams.delete(u); announce(u); } } });
      return;
    }
    if (req.method !== 'POST') return json(res, 404, { error: 'not found' });

    if (url === '/api/register') return readBody(req, res, (b) => {
      if (!limit('reg:' + ip(req), REG_PER_MIN, 60000)) return json(res, 429, { error: 'slow down' });
      const name = typeof b.user === 'string' ? b.user : '', pass = typeof b.pass === 'string' ? b.pass : '';
      if (!NAME_RE.test(name)) return json(res, 400, { error: 'nickname: 3-16 letters, digits or _' });
      if (pass.length < 8 || pass.length > 128) return json(res, 400, { error: 'password must be 8-128 characters' });
      const k = name.toLowerCase();
      if (db.users[k]) return json(res, 409, { error: 'nickname already registered' });
      const salt = crypto.randomBytes(16).toString('hex');
      db.users[k] = { name, salt, hash: hashPass(pass, salt), friends: [], incoming: [], privacy: { showOnline: 'friends', friendRequests: 'everyone' }, status: { state: 'online', note: '' } };
      save();
      json(res, 200, { ok: true });
    });
    if (url === '/api/pair') return readBody(req, res, (b) => {
      const name = typeof b.user === 'string' ? b.user.toLowerCase() : '', pass = typeof b.pass === 'string' ? b.pass : '';
      if (!limit('pairip:' + ip(req), 20, 60000) || !limit('pair:' + name, 5, 60000)) return json(res, 429, { error: 'too many attempts, wait a minute' });
      const u = db.users[name];
      // same cost for unknown users, so response time does not reveal whether a nickname exists
      const h = hashPass(pass.slice(0, 128), u ? u.salt : 'x'.repeat(32));
      if (!u || !safeEq(h, u.hash)) return json(res, 401, { error: 'wrong nickname or password' });
      const code = Array.from(crypto.randomBytes(8)).map((x) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[x % 32]).join('');
      pairing.set(sha(code), { user: name, exp: now() + PAIR_TTL_MS });
      json(res, 200, { code });
    });
    if (url === '/api/claim') return readBody(req, res, (b) => {
      if (!limit('claim:' + ip(req), 10, 60000)) return json(res, 429, { error: 'slow down' });
      const code = typeof b.code === 'string' ? b.code.trim().toUpperCase() : '';
      const key = sha(code);
      const p = pairing.get(key);
      if (!p || now() > p.exp) return json(res, 401, { error: 'invalid or expired code' });
      pairing.delete(key); // one use only
      const token = crypto.randomBytes(32).toString('hex');
      db.sessions[sha(token)] = { user: p.user, created: now() };
      save();
      json(res, 200, { token, user: display(p.user) });
    });
    const u = auth(req);
    if (!u) return json(res, 401, { error: 'unauthorized' });
    if (url === '/api/send') return readBody(req, res, (b) => handleSend(u, b, res));
    if (url === '/api/logout') {
      delete db.sessions[sha((req.headers['authorization'] || '').slice(7).trim())]; save();
      return json(res, 200, { ok: true });
    }
    return json(res, 404, { error: 'not found' });
  } catch (e) {
    try { json(res, 500, { error: 'server error' }); } catch (_) { /* ignore */ }
  }
});
server.requestTimeout = 0; // SSE streams stay open
server.headersTimeout = 15000;
server.listen(PORT, HOST, () => console.log('Ghostline server on http://' + HOST + ':' + PORT));

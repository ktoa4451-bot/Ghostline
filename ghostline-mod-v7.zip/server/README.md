# Ghostline friends server

Needs Node 18+. No npm packages.

    node ghostline-server.js                         # http://127.0.0.1:8787
    PORT=9000 HOST=0.0.0.0 DATA=/var/lib/gl/data.json node ghostline-server.js

1. Open the address in a browser, create an account (your Minecraft nickname + a password of 8+ characters).
2. Press "Get pairing code". The code is valid for 5 minutes and works once.
3. In Minecraft: Ghostline menu -> Player -> FriendsHelp: enter the server address and the code, switch the module on.

The password stays on the web page. Minecraft only receives a session token, stored encrypted on your computer.

**HTTPS:** the server speaks plain HTTP. For anything except localhost run it behind an HTTPS reverse proxy
(Caddy, nginx). The Ghostline client refuses plain `http://` to non-local addresses.

Environment: `PORT`, `HOST`, `DATA` (data file), `REG_PER_MIN` (new accounts per minute per IP, default 5).

Chat commands in the game: `/gl friends`, `/gl add <name>`, `/gl accept <name>`, `/gl decline <name>`, `/gl remove <name>`,
`/gl msg <name> <text>`, `/gl say <text>`, `/gl status <online|away|busy|invisible> [note]`, `/gl logout`,
`/ghelp` (help request), `/ghelp coords` (help request with your coordinates).

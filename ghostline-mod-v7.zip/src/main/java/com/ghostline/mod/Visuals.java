package com.ghostline.mod;

import net.minecraft.client.Minecraft;

/** Client-side world visuals. Currently: weather override (clear / rain / thunder). */
public final class Visuals {
    private Visuals() { }

    private static boolean weatherOn;
    private static float oldRain, oldThunder;

    public static void tick(Minecraft mc) {
        if (mc.level == null) { weatherOn = false; return; }
        Module w = Config.WEATHER;
        if (w.enabled) {
            if (!weatherOn) {
                oldRain = mc.level.getRainLevel(1.0f);
                oldThunder = mc.level.getThunderLevel(1.0f);
                weatherOn = true;
            }
            int mode = w.get(0).i();
            mc.level.setRainLevel(mode == 0 ? 0f : 1f);
            mc.level.setThunderLevel(mode == 2 ? 1f : 0f);
        } else if (weatherOn) {
            mc.level.setRainLevel(oldRain);
            mc.level.setThunderLevel(oldThunder);
            weatherOn = false;
        }
    }
}

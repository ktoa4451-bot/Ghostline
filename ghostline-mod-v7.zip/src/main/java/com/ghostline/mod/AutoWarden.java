package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * AutoWarden: walks to a farm point with Baritone (driven through its chat commands), eats golden carrots,
 * respawns after death, and when another player comes close it teleports to the base, waits, and comes back.
 */
public final class AutoWarden {
    private AutoWarden() { }

    /** Current action, shown on the HUD. */
    public static String status = "";

    private enum S { START, GOING, AT_POINT, AWAY, RETURNING, DEAD }

    private static final Pattern NUM = Pattern.compile("-?\\d+");

    private static S state = S.START;
    private static boolean active, returnSent, lookApplied;
    private static int lastLook = -1;
    private static long stateAt, lastCheck, lastNotify, calmUntil;
    private static Vec3 lastPos = Vec3.ZERO;
    private static String threatName = "";
    private static boolean eating;
    private static int eatPrevSlot = -1;
    private static long eatStart;

    // ------------------------------------------------------------------ settings (indexes in Config.AUTOWARDEN)
    // 0 Farm point, 1 Set farm here, 2 Leave command, 3 Return command, 4 Player radius, 5 Wait time,
    // 6 Eat threshold, 7 Auto respawn, 8 Look along path, 9 Telegram token, 10 Telegram chat

    private static void chat(Minecraft mc, String msg) {
        LocalPlayer p = mc.player;
        if (p == null || p.connection == null || msg == null || msg.isBlank()) return;
        String m = msg.trim();
        if (m.startsWith("/")) p.connection.sendCommand(m.substring(1));
        else p.connection.sendChat(m);
    }

    private static int[] farmPoint() {
        Matcher m = NUM.matcher(Config.AUTOWARDEN.get(0).text);
        int[] v = new int[3];
        for (int i = 0; i < 3; i++) {
            if (!m.find()) return null;
            try { v[i] = Integer.parseInt(m.group()); } catch (NumberFormatException e) { return null; }
        }
        return v;
    }

    private static void telegram(String text) {
        String token = Config.AUTOWARDEN.get(9).text.trim();
        String chatId = Config.AUTOWARDEN.get(10).text.trim();
        if (token.isEmpty() || chatId.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (now - lastNotify < 3000) return;
        lastNotify = now;
        final String url = "https://api.telegram.org/bot" + token + "/sendMessage?chat_id="
            + URLEncoder.encode(chatId, StandardCharsets.UTF_8) + "&text="
            + URLEncoder.encode("Ghostline: " + text, StandardCharsets.UTF_8);
        Thread t = new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(5000);
                c.getResponseCode();
                c.disconnect();
            } catch (Exception ignored) { }
        }, "ghostline-telegram");
        t.setDaemon(true);
        t.start();
    }

    private static Player findThreat(Minecraft mc, LocalPlayer p, double radius) {
        for (Player o : mc.level.players()) {
            if (o == p || o.isSpectator() || Config.isFriend(o)) continue;
            if (p.distanceTo(o) <= radius) return o;
        }
        return null;
    }

    // ------------------------------------------------------------------ eating

    private static void stopEating(Minecraft mc) {
        if (!eating) return;
        mc.options.keyUse.setDown(false);
        LocalPlayer p = mc.player;
        if (p != null && eatPrevSlot >= 0) p.getInventory().setSelectedSlot(eatPrevSlot);
        eating = false;
        eatPrevSlot = -1;
    }

    private static void handleEating(Minecraft mc, LocalPlayer p, long now) {
        float thr = Config.AUTOWARDEN.get(6).f();
        int food = p.getFoodData().getFoodLevel();
        boolean need = food < 20 && (food < thr || p.getHealth() < thr);
        int carrot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(Items.GOLDEN_CARROT)) { carrot = i; break; }
        if (need && carrot >= 0 && mc.screen == null) {
            if (!eating) { eating = true; eatStart = now; eatPrevSlot = p.getInventory().getSelectedSlot(); }
            if (p.getInventory().getSelectedSlot() != carrot) p.getInventory().setSelectedSlot(carrot);
            mc.options.keyUse.setDown(true);
            status = Lang.t("aw.eating");
            if (now - eatStart > 8000) stopEating(mc); // give up on this attempt, retry on the next tick
        } else {
            stopEating(mc);
        }
    }

    // ------------------------------------------------------------------ main loop

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.AUTOWARDEN;
        long now = System.currentTimeMillis();

        if (!FabricLoader.getInstance().isModLoaded("baritone")) { status = Lang.t("aw.nobaritone"); return; }

        if (!active) {
            active = true;
            state = S.START;
            stateAt = now;
            lastLook = -1;
        }
        int look = m.get(8).i();
        if (look != lastLook) { // the camera follows the path when "Look along path" is on
            chat(mc, "#set freeLook " + (look == 1 ? "false" : "true"));
            lastLook = look;
        }

        // "Set farm point here" acts like a button
        if (m.get(1).i() == 1) {
            m.get(1).value = 0;
            m.get(0).text = p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ();
            Config.save();
            state = S.START;
        }

        // death + respawn
        if (p.isDeadOrDying()) {
            if (state != S.DEAD) {
                state = S.DEAD;
                stateAt = now;
                status = Lang.t("aw.dead");
                stopEating(mc);
                telegram(String.format(Lang.t("aw.tg.death"), p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ()));
            } else if (m.get(7).i() == 1 && now - stateAt > 1500) {
                p.respawn();
                mc.setScreen(null);
                stateAt = now;
            }
            return;
        }
        if (state == S.DEAD) { // we are alive again: go back to the farm
            state = S.RETURNING;
            returnSent = false;
            stateAt = now;
            status = Lang.t("aw.returning");
        }

        // another player came close: teleport to the base and wait
        if (state != S.AWAY && state != S.RETURNING && now > calmUntil) {
            Player threat = findThreat(mc, p, m.get(4).value);
            if (threat != null) {
                threatName = threat.getName().getString();
                stopEating(mc);
                chat(mc, "#cancel");
                chat(mc, m.get(2).text);
                state = S.AWAY;
                stateAt = now;
                telegram(String.format(Lang.t("aw.tg.player"), threatName));
            }
        }

        switch (state) {
            case AWAY -> {
                long waited = (now - stateAt) / 1000;
                long total = (long) m.get(5).value;
                status = waited < total
                    ? String.format(Lang.t("aw.away"), threatName) + " | " + String.format(Lang.t("aw.waiting"), total - waited)
                    : Lang.t("aw.returning");
                if (waited >= total) {
                    chat(mc, m.get(3).text);
                    state = S.RETURNING;
                    returnSent = true;
                    stateAt = now;
                }
            }
            case RETURNING -> {
                status = Lang.t("aw.returning");
                if (!returnSent && now - stateAt > 2500) {
                    chat(mc, m.get(3).text);
                    returnSent = true;
                    stateAt = now;
                } else if (returnSent && now - stateAt > 4000) {
                    calmUntil = now + 5000;
                    state = S.START;
                }
            }
            default -> {
                handleEating(mc, p, now);
                int[] pt = farmPoint();
                if (pt == null) { status = Lang.t("aw.badpoint"); return; }
                double dist = Math.sqrt(p.distanceToSqr(pt[0] + 0.5, pt[1], pt[2] + 0.5));
                if (state == S.START) {
                    chat(mc, "#goto " + pt[0] + " " + pt[1] + " " + pt[2]);
                    state = S.GOING;
                    lastCheck = now;
                    lastPos = p.position();
                } else if (state == S.GOING) {
                    if (!eating) status = Lang.t("aw.going");
                    if (dist <= 2.5) {
                        state = S.AT_POINT;
                    } else if (now - lastCheck > 4000) { // stuck? ask Baritone again
                        if (p.position().distanceTo(lastPos) < 0.3 && !eating) chat(mc, "#goto " + pt[0] + " " + pt[1] + " " + pt[2]);
                        lastPos = p.position();
                        lastCheck = now;
                    }
                } else if (state == S.AT_POINT) {
                    if (!eating) status = Lang.t("aw.atpoint");
                    if (dist > 4.0) state = S.START;
                }
            }
        }
    }

    /** Called when the module is switched off (or on Panic): stops Baritone and releases the use key. */
    public static void stop(Minecraft mc) {
        if (!active) return;
        active = false;
        stopEating(mc);
        if (mc.player != null && FabricLoader.getInstance().isModLoaded("baritone")) chat(mc, "#cancel");
        status = "";
        state = S.START;
    }
}

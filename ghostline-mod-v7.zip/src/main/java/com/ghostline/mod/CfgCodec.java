package com.ghostline.mod;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Ghostline CFG file format and its strict validator. Has no Minecraft dependencies.
 *
 * <pre>
 * #GHOSTLINE-CFG
 * format=1
 * mod=1.0.0
 * mc=1.21.11
 * created=2026-10-27T12:00:00Z
 * sha256=&lt;hex of the body&gt;
 * ---
 * Module.setting=value
 * </pre>
 *
 * The checksum detects damage and truncation. It is not a signature: anyone can edit a file and recompute it, which is
 * why every value is validated against the schema as well, and why sensitive keys are never imported.
 */
public final class CfgCodec {
    private CfgCodec() { }

    public static final String MAGIC = "#GHOSTLINE-CFG";
    public static final int FORMAT = 1;
    public static final int MAX_BYTES = 65536;
    public static final int MAX_LINES = 2000;
    public static final int MAX_TEXT = 256;

    public enum Kind { NUMBER, TEXT, FLAG, SENSITIVE }

    /** What a key may contain. NUMBER covers enums, booleans, sliders and key codes (min/max are inclusive). */
    public record Spec(Kind kind, double min, double max) {
        public static Spec number(double min, double max) { return new Spec(Kind.NUMBER, min, max); }
        public static Spec text() { return new Spec(Kind.TEXT, 0, 0); }
        public static Spec flag() { return new Spec(Kind.FLAG, 0, 0); }
        public static Spec sensitive() { return new Spec(Kind.SENSITIVE, 0, 0); }
    }

    public static final class Result {
        public final Map<String, String> values = new LinkedHashMap<>();
        public final List<String> errors = new ArrayList<>();
        public int unknown, skippedSensitive;
        public int format;
        public String mod = "", mc = "";
        public boolean ok() { return errors.isEmpty(); }
        public String firstError() { return errors.isEmpty() ? "" : errors.get(0); }
    }

    private static final Pattern KEY = Pattern.compile("[A-Za-z0-9 _.\\-]{1,80}");
    private static final Pattern NUM = Pattern.compile("-?\\d{1,15}(\\.\\d{1,15})?([eE][-+]?\\d{1,3})?");

    // ------------------------------------------------------------------ writing

    public static String sha256(String body) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(body.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    /** Serialises already-filtered values. Keys are sorted so equal configs give equal files. */
    public static String write(Map<String, String> values, String modVersion, String mcVersion) {
        StringBuilder body = new StringBuilder();
        new java.util.TreeMap<>(values).forEach((k, v) -> body.append(k).append('=').append(escape(v)).append('\n'));
        String b = body.toString();
        return MAGIC + "\nformat=" + FORMAT + "\nmod=" + modVersion + "\nmc=" + mcVersion + "\ncreated=" + Instant.now()
            + "\nsha256=" + sha256(b) + "\n---\n" + b;
    }

    /** Control characters are not allowed in values, so they are replaced by spaces; backslashes are doubled. */
    private static String escape(String v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c == '\\') sb.append("\\\\");
            else if (c < 0x20 || c == 0x7F) sb.append(' ');
            else sb.append(c);
        }
        return sb.toString();
    }

    private static String unescape(String v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c == '\\' && i + 1 < v.length()) {
                char n = v.charAt(++i);
                sb.append(n == 'n' ? '\n' : n == 'r' ? '\r' : n);
            } else sb.append(c);
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ reading

    private static boolean badChar(char c) { return c < 0x20 && c != '\t' || c == 0x7F; }

    /**
     * Strict parse. Nothing is applied here: the caller gets accepted values only when {@link Result#ok()}.
     * When {@code requireChecksum} is false (legacy share codes) a missing checksum is tolerated but a wrong one is not.
     */
    public static Result parse(byte[] data, Map<String, Spec> schema, boolean requireChecksum) {
        Result r = new Result();
        if (data == null || data.length == 0) { r.errors.add("empty file"); return r; }
        if (data.length > MAX_BYTES) { r.errors.add("file too large (max " + MAX_BYTES + " bytes)"); return r; }
        String text;
        try {
            text = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(data)).toString();
        } catch (CharacterCodingException e) { r.errors.add("not valid UTF-8 text"); return r; }
        if (text.startsWith("\uFEFF")) text = text.substring(1);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\n' || c == '\r') continue;
            if (badChar(c)) { r.errors.add("control characters found"); return r; }
        }
        String[] lines = text.split("\\R", -1);
        if (lines.length > MAX_LINES) { r.errors.add("too many lines"); return r; }
        if (!lines[0].trim().equals(MAGIC)) { r.errors.add("not a Ghostline CFG file"); return r; }

        // header
        Map<String, String> head = new LinkedHashMap<>();
        int i = 1;
        boolean sep = false;
        for (; i < lines.length; i++) {
            String l = lines[i];
            if (l.equals("---")) { sep = true; i++; break; }
            int eq = l.indexOf('=');
            if (eq <= 0 || eq > 20) { r.errors.add("bad header line " + (i + 1)); return r; }
            head.put(l.substring(0, eq), l.substring(eq + 1));
        }
        if (!sep) { r.errors.add("missing --- separator"); return r; }
        try { r.format = Integer.parseInt(head.getOrDefault("format", "")); }
        catch (NumberFormatException e) { r.errors.add("bad format number"); return r; }
        if (r.format < 1) { r.errors.add("bad format number"); return r; }
        if (r.format > FORMAT) { r.errors.add("file is from a newer Ghostline (format " + r.format + ")"); return r; }
        r.mod = head.getOrDefault("mod", "");
        r.mc = head.getOrDefault("mc", "");
        if (r.mod.length() > 32 || r.mc.length() > 32) { r.errors.add("bad header"); return r; }

        StringBuilder body = new StringBuilder();
        List<String> bodyLines = new ArrayList<>();
        for (; i < lines.length; i++) {
            if (lines[i].isEmpty()) continue;
            bodyLines.add(lines[i]);
            body.append(lines[i]).append('\n');
        }
        String sum = head.get("sha256");
        if (sum == null) {
            if (requireChecksum) { r.errors.add("checksum missing"); return r; }
        } else if (!sum.equalsIgnoreCase(sha256(body.toString()))) {
            r.errors.add("checksum mismatch: the file is damaged or was edited");
            return r;
        }

        Set<String> seen = new HashSet<>();
        for (String l : bodyLines) {
            int eq = l.indexOf('=');
            if (eq <= 0) { r.errors.add("bad line: " + clip(l)); return r; }
            String key = l.substring(0, eq);
            String val = unescape(l.substring(eq + 1));
            if (!KEY.matcher(key).matches()) { r.errors.add("bad key: " + clip(key)); return r; }
            if (!seen.add(key)) { r.errors.add("duplicate key: " + clip(key)); return r; }
            Spec s = schema.get(key);
            if (s == null) { r.unknown++; continue; }
            switch (s.kind()) {
                case SENSITIVE -> { r.skippedSensitive++; }
                case FLAG -> {
                    if (!val.equals("true") && !val.equals("false")) { r.errors.add("bad value for " + clip(key)); return r; }
                    r.values.put(key, val);
                }
                case TEXT -> {
                    if (val.length() > MAX_TEXT) { r.errors.add("text too long: " + clip(key)); return r; }
                    for (int k = 0; k < val.length(); k++) if (val.charAt(k) < 0x20 || val.charAt(k) == 0x7F) { r.errors.add("bad text: " + clip(key)); return r; }
                    r.values.put(key, val);
                }
                case NUMBER -> {
                    if (!NUM.matcher(val).matches()) { r.errors.add("not a number: " + clip(key)); return r; }
                    double d;
                    try { d = Double.parseDouble(val); } catch (NumberFormatException e) { r.errors.add("not a number: " + clip(key)); return r; }
                    if (Double.isNaN(d) || Double.isInfinite(d) || d < s.min() - 1e-9 || d > s.max() + 1e-9) {
                        r.errors.add("out of range: " + clip(key)); return r;
                    }
                    r.values.put(key, val);
                }
            }
        }
        if (r.values.isEmpty()) r.errors.add("no known settings in the file");
        return r;
    }

    private static String clip(String s) { return s.length() > 40 ? s.substring(0, 40) + "…" : s; }
}

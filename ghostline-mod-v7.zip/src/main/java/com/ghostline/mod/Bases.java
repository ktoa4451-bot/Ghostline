package com.ghostline.mod;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Saved bases for the Raid Assistant: main point, optional second point (e.g. a safe spot to return to) and a route.
 * Plain data and validation only (no Minecraft classes). Stored in config/ghostline-bases.txt, one base per line:
 * {@code base=name|dimension|x|y|z|hasSecond|sx|sy|sz|x,y,z;x,y,z}
 */
public final class Bases {
    private Bases() { }

    public static final int MAX_BASES = 50, MAX_ROUTE = 32, LIMIT = 30_000_000;

    public static final class Base {
        public String name;
        public String dim = "";
        public int x, y, z;
        public boolean hasSecond;
        public int sx, sy, sz;
        public final List<int[]> route = new ArrayList<>();
        public Base(String name, String dim, int x, int y, int z) { this.name = name; this.dim = dim; this.x = x; this.y = y; this.z = z; }
    }

    public static final List<Base> LIST = new ArrayList<>();
    public static String selected = "";

    public static String cleanName(String s) {
        String c = s == null ? "" : s.replaceAll("[|;=,\\p{Cntrl}]", "").trim();
        return c.length() > 24 ? c.substring(0, 24) : c;
    }

    private static String cleanDim(String s) { return s == null ? "" : s.replaceAll("[|;=\\p{Cntrl}]", "").trim(); }
    private static boolean ok(int v) { return Math.abs(v) <= LIMIT; }

    public static Base get(String name) {
        for (Base b : LIST) if (b.name.equalsIgnoreCase(name)) return b;
        return null;
    }

    public static Base selectedBase() { return get(selected); }

    /** Creates a base or moves the main point of an existing one. Returns null if the name or position is not acceptable. */
    public static Base save(String rawName, String dim, int x, int y, int z) {
        String n = cleanName(rawName);
        if (n.isEmpty() || !ok(x) || !ok(y) || !ok(z)) return null;
        Base b = get(n);
        if (b == null) {
            if (LIST.size() >= MAX_BASES) return null;
            b = new Base(n, cleanDim(dim), x, y, z);
            LIST.add(b);
        } else { b.x = x; b.y = y; b.z = z; b.dim = cleanDim(dim); }
        if (selected.isEmpty()) selected = b.name;
        return b;
    }

    public static boolean setSecond(String name, int x, int y, int z) {
        Base b = get(name);
        if (b == null || !ok(x) || !ok(y) || !ok(z)) return false;
        b.hasSecond = true; b.sx = x; b.sy = y; b.sz = z;
        return true;
    }

    public static boolean addRoutePoint(String name, int x, int y, int z) {
        Base b = get(name);
        if (b == null || b.route.size() >= MAX_ROUTE || !ok(x) || !ok(y) || !ok(z)) return false;
        b.route.add(new int[]{x, y, z});
        return true;
    }

    public static void remove(String name) {
        LIST.removeIf(b -> b.name.equalsIgnoreCase(name));
        if (get(selected) == null) selected = LIST.isEmpty() ? "" : LIST.get(0).name;
    }

    /** Points to visit on the way to the base: route points, then the base itself. */
    public static List<int[]> outbound(Base b) {
        List<int[]> r = new ArrayList<>(b.route);
        r.add(new int[]{b.x, b.y, b.z});
        return r;
    }

    /** Way back: route in reverse, ending at the second point (or the base if there is none). */
    public static List<int[]> inbound(Base b) {
        List<int[]> r = new ArrayList<>();
        for (int i = b.route.size() - 1; i >= 0; i--) r.add(b.route.get(i));
        r.add(b.hasSecond ? new int[]{b.sx, b.sy, b.sz} : new int[]{b.x, b.y, b.z});
        return r;
    }

    // ------------------------------------------------------------------ text format

    public static String serialize() {
        StringBuilder sb = new StringBuilder("selected=").append(selected).append('\n');
        for (Base b : LIST) {
            StringBuilder rt = new StringBuilder();
            for (int[] p : b.route) { if (rt.length() > 0) rt.append(';'); rt.append(p[0]).append(',').append(p[1]).append(',').append(p[2]); }
            sb.append("base=").append(b.name).append('|').append(b.dim).append('|').append(b.x).append('|').append(b.y).append('|').append(b.z)
              .append('|').append(b.hasSecond ? 1 : 0).append('|').append(b.sx).append('|').append(b.sy).append('|').append(b.sz).append('|').append(rt).append('\n');
        }
        return sb.toString();
    }

    /** Replaces the list with what the text contains. Bad lines are skipped, never thrown on. Returns the number of skipped lines. */
    public static int parse(String text) {
        LIST.clear();
        selected = "";
        int bad = 0;
        if (text == null || text.length() > 200_000) return 1;
        String sel = "";
        for (String line : text.split("\\R")) {
            if (line.isBlank()) continue;
            try {
                if (line.startsWith("selected=")) { sel = cleanName(line.substring(9)); continue; }
                if (!line.startsWith("base=") || LIST.size() >= MAX_BASES) { bad++; continue; }
                String[] f = line.substring(5).split("\\|", -1);
                if (f.length < 10) { bad++; continue; }
                String n = cleanName(f[0]);
                int x = Integer.parseInt(f[2].trim()), y = Integer.parseInt(f[3].trim()), z = Integer.parseInt(f[4].trim());
                if (n.isEmpty() || get(n) != null || !ok(x) || !ok(y) || !ok(z)) { bad++; continue; }
                Base b = new Base(n, cleanDim(f[1]), x, y, z);
                if (f[5].trim().equals("1")) {
                    int sx = Integer.parseInt(f[6].trim()), sy = Integer.parseInt(f[7].trim()), sz = Integer.parseInt(f[8].trim());
                    if (ok(sx) && ok(sy) && ok(sz)) { b.hasSecond = true; b.sx = sx; b.sy = sy; b.sz = sz; }
                }
                if (!f[9].isBlank()) {
                    for (String pt : f[9].split(";")) {
                        if (b.route.size() >= MAX_ROUTE) break;
                        String[] c = pt.split(",");
                        if (c.length != 3) continue;
                        int rx = Integer.parseInt(c[0].trim()), ry = Integer.parseInt(c[1].trim()), rz = Integer.parseInt(c[2].trim());
                        if (ok(rx) && ok(ry) && ok(rz)) b.route.add(new int[]{rx, ry, rz});
                    }
                }
                LIST.add(b);
            } catch (RuntimeException e) { bad++; }
        }
        selected = get(sel) != null ? sel : (LIST.isEmpty() ? "" : LIST.get(0).name);
        return bad;
    }

    public static void load(Path f) {
        try {
            if (!Files.exists(f) || Files.size(f) > 200_000) return;
            parse(Files.readString(f, StandardCharsets.UTF_8));
        } catch (IOException ignored) { }
    }

    public static void save(Path f) {
        try { Files.writeString(f, serialize(), StandardCharsets.UTF_8); } catch (IOException ignored) { }
    }
}

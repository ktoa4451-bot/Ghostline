package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Shared findings journal: de-duplication, in-game message, optional Telegram (user's own bot token) and a log file. */
public final class Notifier {
    private Notifier() { }

    public record Entry(long time, String text) { }

    private static final List<Entry> LOG = new ArrayList<>();
    private static final Map<String, long[]> SEEN = new HashMap<>(); // key -> {time, value}
    private static long lastTelegram;
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /** Server + dimension, so the same coordinates on another server/dimension are not treated as a repeat. */
    public static String ctx(Minecraft mc) {
        ServerData sd = mc.getCurrentServer();
        String server = sd == null ? "local" : sd.ip;
        String dim = "?";
        if (mc.level != null) {
            String s = mc.level.dimension().toString();
            int i = s.lastIndexOf("/ ");
            dim = i >= 0 ? s.substring(i + 2).replace("]", "").trim() : s;
        }
        return server + "|" + dim;
    }

    /**
     * Records a finding unless it was already reported. A repeat is allowed only after the cooldown and only when the
     * value (score / container count) grew noticeably.
     */
    public static synchronized boolean report(Minecraft mc, String key, int value, int cooldownMin, String text,
                                              boolean chat, boolean telegram, String token, String chatId, boolean file) {
        long now = System.currentTimeMillis();
        long[] s = SEEN.get(key);
        if (s != null) {
            boolean grew = value >= s[1] + Math.max(2, s[1] / 2);
            if (now - s[0] < cooldownMin * 60_000L || !grew) return false;
        }
        SEEN.put(key, new long[]{now, value});
        LOG.add(new Entry(now, text));
        while (LOG.size() > 200) LOG.remove(0);

        if (chat && mc.player != null) mc.player.displayClientMessage(Component.literal("[Ghostline] " + text), false);
        if (file) appendFile(mc, text);
        if (telegram) telegram(token, chatId, text + "  [" + ctx(mc) + "]");
        return true;
    }

    public static synchronized List<Entry> recent(int n) {
        int from = Math.max(0, LOG.size() - n);
        return new ArrayList<>(LOG.subList(from, LOG.size()));
    }

    public static synchronized int count() { return LOG.size(); }

    public static synchronized void clearSeen() { SEEN.clear(); }

    private static void appendFile(Minecraft mc, String text) {
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("ghostline-findings.log");
            String line = LocalDateTime.now().format(TS) + " [" + ctx(mc) + "] " + text + System.lineSeparator();
            Files.writeString(f, line, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) { }
    }

    /** Sends a message through the user's own Telegram bot. Runs off-thread, at most one message per 1.5 s. */
    public static void telegram(String token, String chatId, String text) {
        if (token == null || chatId == null) return;
        final String t = token.trim(), c = chatId.trim();
        if (t.isEmpty() || c.isEmpty()) return;
        long now = System.currentTimeMillis();
        synchronized (Notifier.class) {
            if (now - lastTelegram < 1500) return;
            lastTelegram = now;
        }
        final String url = "https://api.telegram.org/bot" + t + "/sendMessage?chat_id="
            + URLEncoder.encode(c, StandardCharsets.UTF_8) + "&text="
            + URLEncoder.encode("Ghostline: " + text, StandardCharsets.UTF_8);
        Thread th = new Thread(() -> {
            try {
                HttpURLConnection con = (HttpURLConnection) URI.create(url).toURL().openConnection();
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.getResponseCode();
                con.disconnect();
            } catch (Exception ignored) { }
        }, "ghostline-notify");
        th.setDaemon(true);
        th.start();
    }
}

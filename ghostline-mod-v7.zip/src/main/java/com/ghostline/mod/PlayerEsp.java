package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.awt.Color;
import java.util.List;

/**
 * Player ESP drawn in screen space (first person only): Box, Corners, 3D box, Filled, Tracers, Arrows, Health, Armor, Names.
 * It uses the projection from {@link Project}, so it is an overlay and not a world-render outline.
 */
public final class PlayerEsp {
    private PlayerEsp() { }

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static int color(LivingEntity e, int mode, float frac) {
        if (Config.isFriend(e)) return 0x55FF77;
        return switch (mode) {
            case 1 -> 0xFF5555;
            case 2 -> 0xFFFFFF;
            case 3 -> Ui.mix(0xFF4040, 0x40FF60, frac);
            case 4 -> Color.HSBtoRGB((System.currentTimeMillis() % 4000) / 4000f, 0.55f, 1f) & 0xFFFFFF;
            default -> Ui.accent();
        };
    }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (!Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;

        Module m = Config.ESP;
        int style = m.get(0).i();
        boolean tracers = m.get(1).i() == 1, arrows = m.get(2).i() == 1, names = m.get(3).i() == 1;
        boolean health = m.get(4).i() == 1, armor = m.get(5).i() == 1;
        double maxD = m.get(6).value;
        int colorMode = m.get(7).i();
        boolean mobs = m.get(8).i() == 1, players = m.get(9).i() == 1;

        List<LivingEntity> list = mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(maxD),
            e -> e != p && e.isAlive() && !e.isSpectator() && !(e instanceof ArmorStand) && ((e instanceof Player) ? players : mobs));

        int sw = g.guiWidth(), sh = g.guiHeight();
        for (LivingEntity e : list) {
            double d = p.distanceTo(e);
            if (d > maxD) continue;
            Vec3 off = new Vec3(Mth.lerp(pt, e.xo, e.getX()) - e.getX(), Mth.lerp(pt, e.yo, e.getY()) - e.getY(),
                Mth.lerp(pt, e.zo, e.getZ()) - e.getZ());
            AABB bb = e.getBoundingBox().move(off);
            float frac = Mth.clamp(e.getHealth() / Math.max(1f, e.getMaxHealth()), 0f, 1f);
            int rgb = color(e, colorMode, frac);
            int col = 0xFF000000 | rgb;

            float[] r = Project.rect(bb);
            if (r == null || !Project.onScreen(r)) {
                if (arrows) arrow(g, bb.getCenter(), rgb, (int) d, sw, sh);
                continue;
            }
            int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
            int w = Math.max(4, x2 - x1), h = Math.max(4, y2 - y1);

            if (tracers) {
                double[] feet = Project.point(bb.getCenter().x, bb.minY, bb.getCenter().z);
                if (feet != null) Ui.line(g, sw / 2, sh - 1, (int) feet[0], (int) feet[1], Ui.c(rgb, 0.8f));
            }

            switch (style) {
                case 1 -> Ui.box(g, x1, y1, x1 + w, y1 + h, 1, col);
                case 2 -> corners(g, x1, y1, x1 + w, y1 + h, col);
                case 3 -> box3d(g, bb, col);
                case 4 -> {
                    g.fill(x1, y1, x1 + w, y1 + h, Ui.c(rgb, 0.16f));
                    Ui.box(g, x1, y1, x1 + w, y1 + h, 1, col);
                    Ui.box(g, x1 - 1, y1 - 1, x1 + w + 1, y1 + h + 1, 1, Ui.c(0x000000, 0.6f));
                }
                default -> { }
            }

            if (health) {
                int bx = x1 - 4;
                g.fill(bx, y1, bx + 2, y1 + h, Ui.c(0x000000, 0.6f));
                int fh = (int) (h * frac);
                g.fill(bx, y1 + h - fh, bx + 2, y1 + h, 0xFF000000 | Ui.mix(0xFF4040, 0x40FF60, frac));
            }
            if (names) {
                String s = e.getName().getString() + "  " + (int) d + "m";
                if (health) s += "  " + (int) Math.ceil(e.getHealth()) + " HP";
                if (e.isInvisible()) s += "  [inv]";
                Ui.text(g, s, x1 + w / 2 - Ui.tw(s) / 2, y1 - 10, col);
            }
            if (armor) {
                int ix = x1 + w / 2 - 20;
                for (int i = 0; i < 4; i++) {
                    ItemStack st = e.getItemBySlot(ARMOR[i]);
                    if (st.isEmpty()) continue;
                    g.pose().pushMatrix();
                    g.pose().translate(ix + i * 10, y1 + h + 2);
                    g.pose().scale(0.6f, 0.6f);
                    g.renderItem(st, 0, 0);
                    g.pose().popMatrix();
                }
            }
        }
    }

    private static void corners(GuiGraphics g, int x1, int y1, int x2, int y2, int col) {
        int l = Math.max(3, Math.min(x2 - x1, y2 - y1) / 4);
        g.fill(x1, y1, x1 + l, y1 + 1, col); g.fill(x1, y1, x1 + 1, y1 + l, col);
        g.fill(x2 - l, y1, x2, y1 + 1, col); g.fill(x2 - 1, y1, x2, y1 + l, col);
        g.fill(x1, y2 - 1, x1 + l, y2, col); g.fill(x1, y2 - l, x1 + 1, y2, col);
        g.fill(x2 - l, y2 - 1, x2, y2, col); g.fill(x2 - 1, y2 - l, x2, y2, col);
    }

    private static void box3d(GuiGraphics g, AABB bb, int col) {
        double[][] c = Project.corners(bb);
        if (c == null) return;
        // corner index = ix*4 + iy*2 + iz
        int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) Ui.line(g, (int) c[e[0]][0], (int) c[e[0]][1], (int) c[e[1]][0], (int) c[e[1]][1], col);
    }

    /** Pointer on a circle around the crosshair towards an entity that is off screen. */
    private static void arrow(GuiGraphics g, Vec3 target, int rgb, int dist, int sw, int sh) {
        Vec3 eye = Project.eye();
        double dx = target.x - eye.x, dz = target.z - eye.z;
        double ty = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double rel = Math.toRadians(Mth.wrapDegrees(ty - Project.yaw));
        double rad = Math.min(sw, sh) * 0.36;
        double ux = Math.sin(rel), uy = -Math.cos(rel);
        int cx = (int) (sw / 2.0 + ux * rad), cy = (int) (sh / 2.0 + uy * rad);
        int col = Ui.c(rgb, 0.95f);
        int tipX = (int) (cx + ux * 7), tipY = (int) (cy + uy * 7);
        int ax = (int) (cx - uy * 5), ay = (int) (cy + ux * 5);
        int bx = (int) (cx + uy * 5), by = (int) (cy - ux * 5);
        Ui.line(g, tipX, tipY, ax, ay, col);
        Ui.line(g, tipX, tipY, bx, by, col);
        Ui.line(g, ax, ay, bx, by, col);
        String s = dist + "m";
        Ui.text(g, s, cx - Ui.tw(s) / 2, cy + (uy > 0 ? -12 : 9), col);
    }
}

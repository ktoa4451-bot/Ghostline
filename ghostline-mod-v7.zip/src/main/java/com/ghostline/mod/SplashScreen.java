package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class SplashScreen extends Screen {
    public static final Identifier LOGO = Ui.LOGO;
    private static final long FADE_IN = 700, HOLD = 1500, FADE_OUT = 700, TOTAL = FADE_IN + HOLD + FADE_OUT;
    private long start;

    public SplashScreen() { super(Component.literal("Ghostline")); }

    @Override
    protected void init() {
        if (start == 0) start = System.currentTimeMillis();
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void tick() {
        if (start != 0 && System.currentTimeMillis() - start > TOTAL) {
            this.minecraft.setScreen(Config.langChosen ? new GhostTitleScreen() : new LanguageScreen());
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, this.width, this.height, 0xFF05050A);
        int size = Math.min(256, (int) (Math.min(this.width, this.height) * 0.6));
        int x = this.width / 2 - size / 2;
        int y = this.height / 2 - size / 2 - 8;
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO, x, y, 0f, 0f, size, size, 256, 256, 256, 256);
        // wordmark: letters fade in one after another
        String word = "GHOSTLINE";
        int gap = 6, total = 0;
        for (int i = 0; i < word.length(); i++) total += Ui.tw(String.valueOf(word.charAt(i))) + gap;
        total -= gap;
        int lx = this.width / 2 - total / 2;
        long wt = start == 0 ? 0 : System.currentTimeMillis() - start;
        for (int i = 0; i < word.length(); i++) {
            String ch = String.valueOf(word.charAt(i));
            float la = Mth.clamp((wt - 250 - i * 90) / 260f, 0f, 1f);
            if (la > 0f) Ui.text(g, ch, lx, y + size + 6 + (int) ((1f - la) * 5), Ui.c(0xB9B2FF, la));
            lx += Ui.tw(ch) + gap;
        }

        long t = start == 0 ? 0 : System.currentTimeMillis() - start;
        double a;
        if (t < FADE_IN) a = t / (double) FADE_IN;
        else if (t < FADE_IN + HOLD) a = 1.0;
        else a = Math.max(0.0, 1.0 - (t - FADE_IN - HOLD) / (double) FADE_OUT);
        int cover = (int) ((1.0 - a) * 255.0) & 0xFF;
        if (cover > 0) g.fill(0, 0, this.width, this.height, cover << 24);
    }
}

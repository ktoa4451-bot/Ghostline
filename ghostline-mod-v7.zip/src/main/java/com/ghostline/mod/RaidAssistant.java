package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Raid Assistant. It assists, it does not play for you:
 *  - saved bases with a second point and a route, navigation hints on the HUD;
 *  - a list of valuables, loot accounting, tool / totem / inventory warnings;
 *  - containers: marks the ones you opened and points to the nearest unopened one (needs Base Finder for the list);
 *  - optional "Auto take valuables" in an open chest, and optional "Auto return" through Baritone when it is installed.
 * Safety: it never drops, throws or swaps items, keeps free slots in reserve, writes a journal, and the stop key or
 * Panic cancels everything at once.
 */
public final class RaidAssistant {
    private RaidAssistant() { }

    private static final List<String> LOG = new ArrayList<>();
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    private static boolean active, wasOpen, reserveWarned, stopPrev, returning, hintedFinder;
    private static BlockPos lastLook, openPos;
    private static Map<String, Integer> baseline = new TreeMap<>(), openSnap = new TreeMap<>();
    private static int takeTimer, navIdx;
    private static long returnCooldown, lastWarn;
    private static List<String> warnings = new ArrayList<>();
    private static String dropLine = "", valSig = "";
    private static List<String> valuables = new ArrayList<>();
    private static final List<String> HUD = new ArrayList<>();

    // ------------------------------------------------------------------ bases storage

    private static Path basesFile() { return FabricLoader.getInstance().getConfigDir().resolve("ghostline-bases.txt"); }
    public static void loadBases() { Bases.load(basesFile()); }
    public static void saveBases() { Bases.save(basesFile()); }
    public static void resetNav() { navIdx = 0; returning = false; }

    public static List<String> recentLog(int n) {
        synchronized (LOG) { return new ArrayList<>(LOG.subList(Math.max(0, LOG.size() - n), LOG.size())); }
    }

    private static void log(String s) {
        String line = LocalDateTime.now().format(TS) + "  " + s;
        synchronized (LOG) { LOG.add(line); while (LOG.size() > 100) LOG.remove(0); }
        if (Config.RAID.get(11).i() == 1) {
            try {
                Path f = FabricLoader.getInstance().getConfigDir().resolve("ghostline-raid.log");
                Files.writeString(f, line + System.lineSeparator(), StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (Exception ignored) { }
        }
    }

    private static void msg(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("§8[§dGhostline§8] §7" + s), false);
    }

    // ------------------------------------------------------------------ valuables and counting

    private static void refreshValuables(Module m) {
        String sig = m.get(0).text;
        if (sig.equals(valSig)) return;
        valSig = sig;
        valuables = new ArrayList<>();
        for (String t : sig.toLowerCase(Locale.ROOT).split("[,; ]+")) {
            String v = t.trim();
            if (v.startsWith("minecraft:")) v = v.substring(10);
            if (!v.isEmpty()) valuables.add(v);
        }
    }

    private static boolean isValuable(ItemStack s) {
        if (s.isEmpty()) return false;
        String path = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
        for (String v : valuables) if (path.contains(v)) return true;
        return false;
    }

    private static Map<String, Integer> countValuables(LocalPlayer p) {
        Map<String, Integer> out = new TreeMap<>();
        for (int i = 0; i < 37; i++) {
            ItemStack s = i < 36 ? p.getInventory().getItem(i) : p.getOffhandItem();
            if (isValuable(s)) out.merge(BuiltInRegistries.ITEM.getKey(s.getItem()).getPath(), s.getCount(), Integer::sum);
        }
        return out;
    }

    private static String diff(Map<String, Integer> before, Map<String, Integer> now, int max) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (Map.Entry<String, Integer> e : now.entrySet()) {
            int d = e.getValue() - before.getOrDefault(e.getKey(), 0);
            if (d <= 0) continue;
            if (n++ >= max) { sb.append(" …"); break; }
            sb.append(sb.length() > 0 ? ", " : "").append('+').append(d).append(' ').append(e.getKey());
        }
        return sb.toString();
    }

    private static int freeSlots(LocalPlayer p) {
        int n = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getItem(i).isEmpty()) n++;
        return n;
    }

    // ------------------------------------------------------------------ Baritone (optional, explicit actions only)

    public static boolean baritone() { return FabricLoader.getInstance().isModLoaded("baritone"); }

    private static void baritone(Minecraft mc, String cmd) {
        if (mc.player != null && mc.player.connection != null) mc.player.connection.sendChat(cmd);
    }

    public static void goBase(Minecraft mc) {
        Bases.Base b = Bases.selectedBase();
        if (b == null) { msg(Lang.t("raid.no_base")); return; }
        if (!baritone()) { msg(Lang.t("aw.nobaritone")); return; }
        returning = false;
        navIdx = 0;
        baritone(mc, "#goto " + b.x + " " + b.y + " " + b.z);
        log("Go to base " + b.name + " (" + b.x + " " + b.y + " " + b.z + ")");
    }

    public static void goReturn(Minecraft mc) { startReturn(mc, "manual"); }

    private static void startReturn(Minecraft mc, String why) {
        Bases.Base b = Bases.selectedBase();
        if (b == null) { msg(Lang.t("raid.no_base")); return; }
        List<int[]> back = Bases.inbound(b);
        int[] t = Config.RAID.get(8).i() == 1 ? new int[]{b.x, b.y, b.z} : back.get(back.size() - 1);
        returning = true;
        navIdx = 0;
        returnCooldown = System.currentTimeMillis() + 60_000;
        log("Return (" + why + ") to " + t[0] + " " + t[1] + " " + t[2]);
        if (baritone()) baritone(mc, "#goto " + t[0] + " " + t[1] + " " + t[2]);
        else msg(Lang.t("raid.return_hint"));
    }

    /** Stops everything this module can do and switches it off. */
    public static void emergencyStop(Minecraft mc, String why) {
        Module m = Config.RAID;
        m.get(2).value = 0;
        m.get(6).value = 0;
        returning = false;
        if (baritone()) baritone(mc, "#cancel");
        log("EMERGENCY STOP: " + why);
        msg("§c" + Lang.t("raid.stopped"));
        m.enabled = false;
        Config.save();
    }

    public static void stop() {
        if (!active) return;
        active = false;
        wasOpen = false;
        returning = false;
        HUD.clear();
        log("Raid Assistant off");
    }

    // ------------------------------------------------------------------ tick

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.RAID;
        refreshValuables(m);
        if (!active) {
            active = true;
            baseline = countValuables(p);
            reserveWarned = false;
            log("Raid Assistant on");
        }

        long win = GLFW.glfwGetCurrentContext();
        boolean sd = win != 0 && m.get(9).i() > 0 && GLFW.glfwGetKey(win, m.get(9).i()) == GLFW.GLFW_PRESS;
        if (sd && !stopPrev) { stopPrev = true; emergencyStop(mc, "stop key"); return; }
        stopPrev = sd;

        if (mc.screen == null && mc.hitResult instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) lastLook = bh.getBlockPos();

        containers(mc, p, m);
        if (p.tickCount % 10 == 0) drops(mc, p);
        if (p.tickCount % 20 == 0) slow(mc, p, m);
        if (p.tickCount % 10 == 0) buildHud(mc, p, m);
    }

    private static void containers(Minecraft mc, LocalPlayer p, Module m) {
        if (mc.gameMode != null && p.containerMenu != p.inventoryMenu && p.containerMenu instanceof ChestMenu cm) {
            if (!wasOpen) {
                wasOpen = true;
                openPos = lastLook;
                openSnap = countValuables(p);
                reserveWarned = false;
                takeTimer = 0;
                if (openPos != null) BaseFinder.markLooted(mc, openPos);
            }
            if (m.get(2).i() == 1 && ++takeTimer > m.get(3).i()) {
                takeTimer = 0;
                if (freeSlots(p) <= m.get(1).i()) {
                    if (!reserveWarned) {
                        reserveWarned = true;
                        msg(Lang.t("raid.reserve"));
                        log("Inventory reserve reached, auto take paused");
                    }
                    return;
                }
                int slots = cm.getRowCount() * 9;
                for (int i = 0; i < slots; i++) {
                    if (isValuable(cm.getSlot(i).getItem())) {
                        // shift-click only moves the stack from the chest into the inventory; nothing is dropped or swapped
                        mc.gameMode.handleInventoryMouseClick(cm.containerId, i, 0, ClickType.QUICK_MOVE, p);
                        break;
                    }
                }
            }
        } else if (wasOpen) {
            wasOpen = false;
            String gain = diff(openSnap, countValuables(p), 6);
            String where = openPos == null ? "?" : openPos.getX() + " " + openPos.getY() + " " + openPos.getZ();
            log("Container " + where + ": " + (gain.isEmpty() ? "nothing valuable taken" : gain));
        }
    }

    private static void drops(Minecraft mc, LocalPlayer p) {
        ItemEntity best = null;
        double bd = Double.MAX_VALUE;
        for (ItemEntity ie : mc.level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(24.0), e -> e.isAlive() && isValuable(e.getItem()))) {
            double d = p.distanceToSqr(ie);
            if (d < bd) { bd = d; best = ie; }
        }
        dropLine = best == null ? "" : best.getItem().getHoverName().getString() + " x" + best.getItem().getCount() + " " + (int) Math.sqrt(bd) + "m";
    }

    private static void slow(Minecraft mc, LocalPlayer p, Module m) {
        long now = System.currentTimeMillis();
        List<String> w = new ArrayList<>();
        int pct = m.get(4).i();
        for (int i = 0; i < 14; i++) {
            ItemStack s;
            if (i < 9) s = p.getInventory().getItem(i);
            else if (i == 9) s = p.getOffhandItem();
            else s = p.getItemBySlot(new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}[i - 10]);
            if (s.isEmpty() || !s.isDamageableItem() || s.getMaxDamage() <= 0) continue;
            int left = (s.getMaxDamage() - s.getDamageValue()) * 100 / s.getMaxDamage();
            if (left <= pct) w.add(s.getHoverName().getString() + " " + left + "%");
        }
        int totems = 0;
        for (int i = 0; i < 37; i++) {
            ItemStack s = i < 36 ? p.getInventory().getItem(i) : p.getOffhandItem();
            if (s.is(Items.TOTEM_OF_UNDYING)) totems += s.getCount();
        }
        if (totems < m.get(5).i()) w.add(String.format(Lang.t("raid.totems"), totems));
        int free = freeSlots(p);
        if (free <= m.get(1).i()) w.add(String.format(Lang.t("raid.slots"), free));
        warnings = w;
        if (!w.isEmpty() && now - lastWarn > 30_000) {
            lastWarn = now;
            p.displayClientMessage(Component.literal("§e" + String.join(" | ", w)), true);
            log("Warning: " + String.join(", ", w));
        }

        // optional automatic return: needs Baritone and is off by default
        if (m.get(6).i() == 1 && !returning && now > returnCooldown) {
            if (p.getHealth() <= m.get(7).i()) startReturn(mc, "low health");
            else if (free <= m.get(1).i()) startReturn(mc, "inventory full");
        }

        // route progress
        Bases.Base b = Bases.selectedBase();
        if (b != null && sameDim(mc, b)) {
            List<int[]> pts = returning ? Bases.inbound(b) : Bases.outbound(b);
            if (navIdx >= pts.size()) navIdx = pts.size() - 1;
            int[] t = pts.get(Math.max(0, navIdx));
            double d = Math.sqrt(p.distanceToSqr(t[0] + 0.5, t[1] + 0.5, t[2] + 0.5));
            if (d < 5) {
                if (navIdx < pts.size() - 1) navIdx++;
                else if (returning) { returning = false; log("Reached the return point"); }
            }
        }
    }

    private static boolean sameDim(Minecraft mc, Bases.Base b) {
        if (b.dim.isEmpty()) return true;
        String[] ctx = Notifier.ctx(mc).split("\\|", 2);
        return ctx.length > 1 && ctx[1].equals(b.dim);
    }

    // ------------------------------------------------------------------ HUD

    public static List<String> hudLines() { return Config.RAID.enabled ? new ArrayList<>(HUD) : List.of(); }

    private static String arrow(LocalPlayer p, double dx, double dz) {
        double target = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double rel = ((target - p.getYRot()) % 360 + 540) % 360 - 180; // -180..180, 0 = straight ahead
        int idx = (int) Math.round(rel / 45.0);
        return ARROWS[((idx % 8) + 8) % 8];
    }

    private static void buildHud(Minecraft mc, LocalPlayer p, Module m) {
        HUD.clear();
        Bases.Base b = Bases.selectedBase();
        if (b != null) {
            if (!sameDim(mc, b)) HUD.add(Lang.t("raid.base") + " " + b.name + " (" + Lang.t("raid.other_dim") + ")");
            else {
                List<int[]> pts = returning ? Bases.inbound(b) : Bases.outbound(b);
                int i = Math.max(0, Math.min(navIdx, pts.size() - 1));
                int[] t = pts.get(i);
                double dx = t[0] + 0.5 - p.getX(), dz = t[2] + 0.5 - p.getZ();
                HUD.add((returning ? Lang.t("raid.returning") : Lang.t("raid.base")) + " " + b.name + "  " + arrow(p, dx, dz) + " "
                    + (int) Math.sqrt(dx * dx + dz * dz) + "m  (" + (i + 1) + "/" + pts.size() + ")");
            }
        }
        String gain = diff(baseline, countValuables(p), 4);
        if (!gain.isEmpty()) HUD.add(Lang.t("raid.loot") + " " + gain);
        for (String w : warnings) HUD.add("! " + w);
        if (m.get(10).i() == 1) {
            if (!Config.BASEFINDER.enabled) {
                if (!hintedFinder) { hintedFinder = true; msg(Lang.t("raid.need_finder")); }
            } else {
                BaseFinder.Container c = BaseFinder.nearestUnlooted(mc, p);
                if (c != null) {
                    double d = Math.sqrt(p.distanceToSqr(c.pos().getX() + 0.5, c.pos().getY() + 0.5, c.pos().getZ() + 0.5));
                    HUD.add(Lang.t("raid.nearest") + " " + Lang.opt(BaseFinder.KIND_NAME[c.kind()]) + " "
                        + arrow(p, c.pos().getX() + 0.5 - p.getX(), c.pos().getZ() + 0.5 - p.getZ()) + " " + (int) d + "m");
                }
            }
        }
        if (!dropLine.isEmpty()) HUD.add(Lang.t("raid.drop") + " " + dropLine);
        for (String s : recentLog(2)) HUD.add(s.length() > 60 ? s.substring(0, 59) + "…" : s);
    }
}

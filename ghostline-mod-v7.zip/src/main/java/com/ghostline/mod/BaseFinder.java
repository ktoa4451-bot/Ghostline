package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.TrappedChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Base Finder. Works only with what the client has: loaded chunks and their block entities.
 *  - World Scanner: scores every loaded chunk by player-made looking blocks (heuristic, so natural structures such as
 *    villages or mineshafts can score too).
 *  - Chest ESP: marks loaded containers (chests, barrels, shulker boxes ...) on screen; groups of them are reported.
 * Nothing hidden or not yet sent by the server can be found.
 */
public final class BaseFinder {
    private BaseFinder() { }

    public static final String[] KIND_NAME = {"Chest", "Trapped chest", "Barrel", "Shulker box", "Ender chest", "Workstation"};
    private static final int[] KIND_COLOR = {0xE8A33D, 0xE0524D, 0xB07A4A, 0xB36AE2, 0x8B7CF6, 0x9AA0AE};
    private static final int[] KIND_SETTING = {10, 11, 12, 13, 14, 15};

    public record Container(BlockPos pos, int kind) { }

    private static volatile List<Container> containers = List.of();
    private static int tickCount;

    // world scan state
    private static final List<int[]> queue = new ArrayList<>();
    private static int qi, curCx, curCz, curY0, curH, cursor;
    private static boolean hasCur;
    private static long scoreSum, sx, sy, sz;
    private static int idleUntil;
    private static String sig = "";
    private static final Map<Block, Integer> WEIGHT = new IdentityHashMap<>();
    private static Set<String> extra = new HashSet<>();
    private static boolean wasActive;

    public static int containerCount() { return containers.size(); }

    // containers the player has already opened (set by the Raid Assistant), per server and dimension
    private static final Map<String, Set<Long>> looted = new HashMap<>();

    public static void markLooted(Minecraft mc, BlockPos pos) {
        looted.computeIfAbsent(Notifier.ctx(mc), k -> new HashSet<>()).add(pos.asLong());
    }

    private static boolean isLooted(Set<Long> s, BlockPos p) {
        if (s == null) return false;
        // the other half of a double chest counts too
        return s.contains(p.asLong()) || s.contains(p.north().asLong()) || s.contains(p.south().asLong())
            || s.contains(p.east().asLong()) || s.contains(p.west().asLong());
    }

    /** Closest storage container (not hoppers/furnaces) that was not opened yet, or null. */
    public static Container nearestUnlooted(Minecraft mc, LocalPlayer p) {
        Set<Long> s = looted.get(Notifier.ctx(mc));
        Container best = null;
        double bd = Double.MAX_VALUE;
        for (Container c : containers) {
            if (c.kind() == 5 || isLooted(s, c.pos())) continue;
            double d = p.distanceToSqr(c.pos().getX() + 0.5, c.pos().getY() + 0.5, c.pos().getZ() + 0.5);
            if (d < bd) { bd = d; best = c; }
        }
        return best;
    }

    /** Called when the module is off or on Panic. */
    public static void idle() {
        if (!wasActive) return;
        wasActive = false;
        containers = List.of();
        queue.clear();
        hasCur = false;
        qi = 0;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.BASEFINDER;
        wasActive = true;
        tickCount++;
        if (tickCount % 20 == 1) refreshContainers(mc, p, m);
        if (m.get(3).i() == 1) scanStep(mc, p, m);
    }

    // ------------------------------------------------------------------ containers (Chest ESP + clusters)

    private static int classify(BlockState st, Module m) {
        Block b = st.getBlock();
        int kind;
        if (b instanceof EnderChestBlock) kind = 4;
        else if (b instanceof ChestBlock) {
            if (st.getValue(ChestBlock.TYPE) == ChestType.RIGHT) return -1; // count a double chest once
            kind = b instanceof TrappedChestBlock ? 1 : 0;
        }
        else if (b instanceof BarrelBlock) kind = 2;
        else if (b instanceof ShulkerBoxBlock) kind = 3;
        else if (b instanceof HopperBlock || b instanceof AbstractFurnaceBlock || b instanceof DispenserBlock) kind = 5;
        else return -1;
        return m.get(KIND_SETTING[kind]).i() == 1 ? kind : -1;
    }

    private static void refreshContainers(Minecraft mc, LocalPlayer p, Module m) {
        int r = m.get(0).i();
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        List<Container> all = new ArrayList<>();
        Map<Long, List<Container>> byChunk = new HashMap<>();
        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                if (!mc.level.getChunkSource().hasChunk(cx, cz)) continue;
                LevelChunk ch = mc.level.getChunk(cx, cz);
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    int kind = classify(be.getBlockState(), m);
                    if (kind < 0) continue;
                    Container c = new Container(be.getBlockPos(), kind);
                    all.add(c);
                    byChunk.computeIfAbsent(((long) cx << 32) ^ (cz & 0xFFFFFFFFL), k -> new ArrayList<>()).add(c);
                }
            }
        }
        containers = all;

        int threshold = m.get(16).i();
        String ctx = Notifier.ctx(mc);
        for (Map.Entry<Long, List<Container>> e : byChunk.entrySet()) {
            List<Container> list = e.getValue();
            // workstations alone (a lone furnace) are not a reason to report, count real storage only
            int storage = 0;
            for (Container c : list) if (c.kind() != 5) storage++;
            if (storage < threshold) continue;
            long ax = 0, ay = 0, az = 0;
            for (Container c : list) { ax += c.pos().getX(); ay += c.pos().getY(); az += c.pos().getZ(); }
            int n = list.size();
            String text = String.format(Lang.t("bf.cont"), n, ax / n, ay / n, az / n);
            Notifier.report(mc, "cont:" + ctx + ":" + e.getKey(), n, m.get(21).i(), text,
                m.get(17).i() == 1, m.get(18).i() == 1, m.get(19).text, m.get(20).text, m.get(23).i() == 1);
        }
    }

    // ------------------------------------------------------------------ world scanner

    private static void refreshWeights(Module m) {
        String s = m.get(5).i() + "|" + m.get(6).i() + "|" + m.get(7).text;
        if (s.equals(sig)) return;
        sig = s;
        WEIGHT.clear();
        extra = new HashSet<>();
        for (String part : m.get(7).text.toLowerCase(Locale.ROOT).split("[,; ]+")) {
            String t = part.trim();
            if (t.startsWith("minecraft:")) t = t.substring(10);
            if (!t.isEmpty()) extra.add(t);
        }
    }

    private static int weightOf(Block b, boolean building, boolean functional) {
        String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
        for (String e : extra) if (p.contains(e)) return 4;
        if (functional) {
            if (p.equals("chest") || p.equals("trapped_chest") || p.equals("barrel") || p.endsWith("shulker_box")) return 5;
            if (p.endsWith("_bed")) return 4;
            switch (p) {
                case "furnace", "blast_furnace", "smoker", "crafting_table", "enchanting_table", "anvil", "chipped_anvil",
                     "damaged_anvil", "brewing_stand", "hopper", "dispenser", "dropper", "observer", "piston",
                     "sticky_piston", "redstone_lamp", "beacon", "lectern", "smithing_table", "cartography_table",
                     "fletching_table", "loom", "stonecutter", "grindstone", "jukebox", "note_block", "ender_chest" -> { return 3; }
                default -> { }
            }
        }
        if (building) {
            if (p.contains("concrete") && !p.contains("powder")) return 1;
            if (p.contains("glazed_terracotta")) return 2;
            if (p.contains("glass")) return 1;
            if (p.endsWith("_wool") || p.endsWith("_carpet")) return 1;
            if (p.contains("planks") || p.contains("bricks") || p.startsWith("polished_") || p.startsWith("smooth_")) return 1;
            if (p.endsWith("_door") || p.endsWith("trapdoor") || p.endsWith("_fence") || p.endsWith("_fence_gate")) return 1;
            if (p.endsWith("_stairs") || p.endsWith("_slab")) return 1;
            if (p.equals("torch") || p.equals("wall_torch") || p.equals("soul_torch") || p.equals("soul_wall_torch")) return 1;
            if (p.endsWith("lantern") || p.endsWith("_sign") || p.endsWith("banner") || p.equals("bookshelf")) return 2;
            if (p.equals("obsidian") || p.equals("crying_obsidian")) return 1;
            switch (p) {
                case "iron_block", "gold_block", "diamond_block", "emerald_block", "lapis_block", "netherite_block",
                     "copper_block", "quartz_block", "quartz_pillar", "chiseled_quartz_block" -> { return 3; }
                default -> { }
            }
        }
        return 0;
    }

    private static boolean nextChunk(Minecraft mc, LocalPlayer p, Module m) {
        if (qi >= queue.size()) {
            if (tickCount < idleUntil) return false;
            queue.clear();
            qi = 0;
            int r = m.get(0).i();
            int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
            for (int cx = pcx - r; cx <= pcx + r; cx++)
                for (int cz = pcz - r; cz <= pcz + r; cz++)
                    if (mc.level.getChunkSource().hasChunk(cx, cz)) queue.add(new int[]{cx, cz});
            queue.sort(Comparator.comparingInt(a -> (a[0] - pcx) * (a[0] - pcx) + (a[1] - pcz) * (a[1] - pcz)));
            idleUntil = tickCount + 100; // after a full pass rest for 5 seconds
            if (queue.isEmpty()) return false;
        }
        int[] c = queue.get(qi++);
        int vr = m.get(1).i();
        curCx = c[0]; curCz = c[1];
        curY0 = p.getBlockY() - vr;
        curH = vr * 2 + 1;
        cursor = 0;
        scoreSum = sx = sy = sz = 0;
        hasCur = true;
        return true;
    }

    private static void scanStep(Minecraft mc, LocalPlayer p, Module m) {
        refreshWeights(m);
        boolean building = m.get(5).i() == 1, functional = m.get(6).i() == 1;
        int budget = m.get(2).i(); // blocks checked per tick
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        while (budget > 0) {
            if (!hasCur && !nextChunk(mc, p, m)) return;
            int total = 256 * curH;
            int n = Math.min(budget, total - cursor);
            for (int i = 0; i < n; i++) {
                int idx = cursor + i;
                int y = curY0 + idx / 256;
                int r = idx & 255;
                int x = curCx * 16 + (r & 15), z = curCz * 16 + (r >> 4);
                BlockState st = mc.level.getBlockState(pos.set(x, y, z));
                if (st.isAir()) continue;
                Block b = st.getBlock();
                Integer w = WEIGHT.get(b);
                if (w == null) { w = weightOf(b, building, functional); WEIGHT.put(b, w); }
                if (w > 0) { scoreSum += w; sx += (long) w * x; sy += (long) w * y; sz += (long) w * z; }
            }
            cursor += n;
            budget -= n;
            if (cursor >= total) { finishChunk(mc, m); hasCur = false; }
        }
    }

    private static void finishChunk(Minecraft mc, Module m) {
        if (scoreSum < m.get(4).i()) return;
        long w = scoreSum;
        int x = (int) (sx / w), y = (int) (sy / w), z = (int) (sz / w);
        String text = String.format(Lang.t("bf.base"), x, y, z, (int) w);
        Notifier.report(mc, "base:" + Notifier.ctx(mc) + ":" + curCx + "," + curCz, (int) w, m.get(21).i(), text,
            m.get(17).i() == 1, m.get(18).i() == 1, m.get(19).text, m.get(20).text, m.get(23).i() == 1);
    }

    // ------------------------------------------------------------------ Chest ESP drawing (screen space)

    public static void renderEsp(GuiGraphics g, Minecraft mc, float pt) {
        Module m = Config.BASEFINDER;
        if (!m.enabled || m.get(8).i() != 1 || mc.player == null) return;
        List<Container> list = containers;
        if (list.isEmpty() || !Project.begin(mc, mc.player, pt, g.guiWidth(), g.guiHeight())) return;
        double max = m.get(9).value;
        boolean labels = m.get(24).i() == 1;
        Set<Long> lootedHere = looted.get(Notifier.ctx(mc));
        int drawn = 0;
        for (Container c : list) {
            if (drawn >= 80) break;
            double d = Math.sqrt(mc.player.distanceToSqr(c.pos().getX() + 0.5, c.pos().getY() + 0.5, c.pos().getZ() + 0.5));
            if (d > max) continue;
            float[] r = Project.rect(new AABB(c.pos()));
            if (r == null || !Project.onScreen(r)) continue;
            boolean done = isLooted(lootedHere, c.pos());
            int rgb = done ? 0x70747E : KIND_COLOR[c.kind()];
            int col = 0xFF000000 | rgb;
            int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2] + 1, y2 = (int) r[3] + 1;
            if (x2 - x1 < 5) { x1 -= 2; x2 += 2; }
            if (y2 - y1 < 5) { y1 -= 2; y2 += 2; }
            g.fill(x1, y1, x2, y2, ((done ? 0x10 : 0x28) << 24) | rgb);
            Ui.box(g, x1, y1, x2, y2, 1, col);
            if (labels && d < 48) {
                String s = Lang.opt(KIND_NAME[c.kind()]) + " " + (int) d + "m" + (done ? " ✓" : "");
                Ui.text(g, s, (x1 + x2) / 2 - Ui.tw(s) / 2, y1 - 10, col);
            }
            drawn++;
        }
    }

    public static List<String> hudLines(int n) {
        List<String> out = new ArrayList<>();
        for (Notifier.Entry e : Notifier.recent(n)) out.add(e.text());
        return out;
    }
}

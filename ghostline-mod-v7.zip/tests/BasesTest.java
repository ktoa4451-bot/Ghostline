import com.ghostline.mod.*;
import java.nio.file.*;
import java.util.*;
public class BasesTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) throws Exception {
        Bases.LIST.clear(); Bases.selected = "";
        check("save base", Bases.save("Home|Base;=", "minecraft:overworld", 100, 64, -200) != null && Bases.get("HomeBase") != null);
        check("first base auto-selected", Bases.selected.equals("HomeBase"));
        check("name sanitised (no separators)", !Bases.LIST.get(0).name.contains("|") && !Bases.LIST.get(0).name.contains(";"));
        check("empty name rejected", Bases.save("  ", "", 1, 2, 3) == null);
        check("absurd coordinates rejected", Bases.save("Far", "", 999_999_999, 0, 0) == null);
        check("second point", Bases.setSecond("homebase", 10, 70, 10) && Bases.get("HomeBase").hasSecond);
        check("route points", Bases.addRoutePoint("HomeBase", 1, 2, 3) && Bases.addRoutePoint("HomeBase", 4, 5, 6));
        for (int i = 0; i < 40; i++) Bases.addRoutePoint("HomeBase", i, 0, i);
        check("route capped at " + Bases.MAX_ROUTE, Bases.get("HomeBase").route.size() == Bases.MAX_ROUTE);
        Bases.Base b = Bases.get("HomeBase");
        List<int[]> out = Bases.outbound(b), in = Bases.inbound(b);
        check("outbound ends at the base", Arrays.equals(out.get(out.size() - 1), new int[]{100, 64, -200}) && Arrays.equals(out.get(0), new int[]{1, 2, 3}));
        check("inbound is reversed and ends at second point", Arrays.equals(in.get(in.size() - 1), new int[]{10, 70, 10}) && in.size() == b.route.size() + 1 && Arrays.equals(in.get(0), b.route.get(b.route.size() - 1)));
        Bases.save("Other", "minecraft:the_nether", 5, 5, 5);
        Bases.selected = "Other";
        String text = Bases.serialize();
        Path f = Files.createTempFile("bases", ".txt");
        Bases.save(f);
        Bases.LIST.clear(); Bases.selected = "";
        Bases.load(f);
        check("round trip keeps bases, selection, route and second point", Bases.LIST.size() == 2 && Bases.selected.equals("Other") && Bases.get("HomeBase").route.size() == Bases.MAX_ROUTE && Bases.get("HomeBase").hasSecond && Bases.get("HomeBase").sx == 10);
        check("serialize is stable", text.equals(Bases.serialize()));
        // hostile / damaged file
        int bad = Bases.parse("selected=Zed\nbase=OK|d|1|2|3|0|0|0|0|\nbase=Bad|d|x|2|3|0|0|0|0|\nbase=Far|d|99999999999|0|0|0|0|0|0|\nbase=Short|d|1\ngarbage line\nbase=OK|d|9|9|9|0|0|0|0|\nbase=Rt|d|1|1|1|1|2|3|4|1,2,3;bad;9,9;5,5,5\n");
        check("damaged lines skipped without exceptions (" + bad + " skipped)", bad == 5 && Bases.LIST.size() == 2);
        check("selection falls back to an existing base", Bases.selected.equals("OK"));
        check("route parsing keeps only valid points", Bases.get("Rt").route.size() == 2 && Bases.get("Rt").hasSecond);
        Bases.parse(null); check("null text ok", Bases.LIST.isEmpty());
        Bases.parse("x".repeat(300000)); check("oversized text refused", Bases.LIST.isEmpty());
        StringBuilder many = new StringBuilder(); for (int i = 0; i < 80; i++) many.append("base=B").append(i).append("|d|1|1|1|0|0|0|0|\n");
        Bases.parse(many.toString()); check("base count capped at " + Bases.MAX_BASES, Bases.LIST.size() == Bases.MAX_BASES);
        Random r = new Random(7); int ex = 0;
        for (int i = 0; i < 5000; i++) { StringBuilder s = new StringBuilder(); for (int k = 0; k < 120; k++) s.append((char) (r.nextInt(95) + 32)).append(r.nextInt(12) == 0 ? "\n|" : ""); try { Bases.parse(s.toString()); } catch (Throwable t) { ex++; } }
        check("fuzz 5000 random texts: no exceptions", ex == 0);
        Bases.remove("OK"); check("remove keeps a valid selection", Bases.get(Bases.selected) != null || Bases.LIST.isEmpty());
        System.out.println("\n" + pass + " passed, " + fail + " failed"); System.exit(fail == 0 ? 0 : 1);
    }
}

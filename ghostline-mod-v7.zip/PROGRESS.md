# Ghostline Mega Update - progress

## Part 1 (done in code, NOT built yet)
BaseFinder, TreeFarm, PlayerEsp, Project, Notifier, Visuals (weather), watermark styles (HUD settings 15-20).

## Part 2 (done in code, NOT built yet)
- Config Manager: CfgCodec (strict .cfg format, checksum, schema validation), ConfigIO (export/import, share codes "GL1."),
  SecretStore (AES-GCM for tokens in ghostline.properties), Setting.noSave(); named configs and old share codes are validated too.
- FriendsHelp: server/ghostline-server.js (Node, tested), SocialClient + MiniJson (tested), FriendsHelp (game side, /gl and /ghelp commands).
- RaidAssistant + Bases (tested logic), panel in the Misc > RaidAssistant card, BaseFinder marks opened containers.
- InvisHelper: own effect timer, reminders, item count, players flagged invisible by the server.

## Tests that really ran (plain Java 21 + Node, no Minecraft): tests/
CfgCodecSecretStoreTest 36/36, BasesTest 20/20, FriendsProtocolTest 45/45 (needs the server running, see header).

## Not verified: anything that touches Minecraft / Fabric APIs (Gradle build was never run in the sandbox).
Likeliest compile risks: hasChunk / getChunk, stopDestroyBlock, setRainLevel/setThunderLevel, getPlayerInfo,
Fabric ClientCommandManager + ClientSendMessageEvents.ALLOW_COMMAND, MobEffectInstance.isInfiniteDuration.

## Open for Part 3
Event Bus (none yet), time of day and particles (Visuals), world-render ESP (Box/Outline/3D in the world), AutoWarden -> Notifier,
animations, Tree Farm full trunk height, friends GUI page (only commands + module settings now), mod-wide Telegram settings reuse.

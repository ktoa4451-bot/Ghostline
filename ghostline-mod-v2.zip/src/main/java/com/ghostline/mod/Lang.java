package com.ghostline.mod;

import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

public class Lang {
    private static final Map<String, String[]> M = new HashMap<>();

    private static void p(String k, String en, String ru) { M.put(k, new String[]{en, ru}); }

    static {
        // modules
        p("mod.Fly", "Fly", "Полёт");
        p("mod.Speed", "Speed", "Скорость");
        p("mod.Fullbright", "Fullbright", "Ночное зрение");
        p("mod.AutoSprint", "AutoSprint", "Авто-бег");
        p("mod.TriggerBot", "TriggerBot", "Триггер-бот");
        p("mod.AimAssist", "AimAssist", "Аим-ассист");
        p("mod.ViewModel", "ViewModel", "Вью-модель");
        p("mod.AutoMace", "AutoMace", "Авто-булава");
        p("mod.AutoSwap 1", "AutoSwap 1", "Авто-свап 1");
        p("mod.AutoSwap 2", "AutoSwap 2", "Авто-свап 2");
        p("mod.AutoSwap 3", "AutoSwap 3", "Авто-свап 3");
        p("mod.AutoTotem", "AutoTotem", "Авто-тотем");
        p("mod.NoFriendDamage", "NoFriendDmg", "Друзья");
        p("mod.Ender Pearl", "Ender Pearl", "Эндер-жемчуг");
        p("mod.Wind Charge", "Wind Charge", "Заряд ветра");
        p("mod.Panic", "PANIC", "ПАНИКА");
        // settings
        p("set.Fly speed", "Fly speed", "Скорость полёта");
        p("set.Multiplier", "Multiplier", "Множитель");
        p("set.Targets", "Targets", "Цели");
        p("set.Min charge", "Min charge", "Мин. заряд удара");
        p("set.Smoothness", "Smoothness", "Плавность");
        p("set.FOV", "FOV", "Угол захвата");
        p("set.Range", "Range", "Дальность");
        p("set.Scale", "Scale", "Размер");
        p("set.Item", "Item", "Предмет");
        p("set.Name contains", "Name contains", "Имя содержит");
        p("set.Hand", "Hand", "Рука");
        p("set.Min fall", "Min fall", "Мин. падение");
        p("set.Switch back", "Switch back", "Вернуть слот");
        p("set.Delay", "Delay (ticks)", "Задержка (тики)");
        p("set.Min health", "Min health (0=always)", "Мин. здоровье (0=всегда)");
        // options
        p("opt.All", "All", "Все");
        p("opt.Mobs", "Mobs", "Мобы");
        p("opt.Players", "Players", "Игроки");
        p("opt.Sword", "Sword", "Меч");
        p("opt.Axe", "Axe", "Топор");
        p("opt.Mace", "Mace", "Булава");
        p("opt.Off", "Off", "Выкл");
        p("opt.On", "On", "Вкл");
        p("opt.Any", "Any (by name)", "Любой (по имени)");
        p("opt.Totem", "Totem", "Тотем");
        p("opt.Head", "Head (sphere)", "Голова (сфера)");
        p("opt.Shield", "Shield", "Щит");
        p("opt.Gapple", "Golden apple", "Золотое яблоко");
        p("opt.Pearl", "Ender pearl", "Эндер-жемчуг");
        p("opt.Firework", "Firework", "Фейерверк");
        p("opt.Crystal", "End crystal", "Кристалл");
        p("opt.Offhand", "Offhand", "Левая рука");
        p("opt.Mainhand", "Mainhand", "Основная рука");
        // tabs
        p("tab.0", "Fight", "Бой");
        p("tab.1", "Move", "Ход");
        p("tab.2", "View", "Вид");
        p("tab.3", "Swap", "Свап");
        p("tab.4", "Misc", "Ещё");
        // ui
        p("ui.on", "ON", "ВКЛ");
        p("ui.off", "OFF", "ВЫКЛ");
        p("ui.close", "Close", "Закрыть");
        p("ui.back", "Back", "Назад");
        p("ui.reset", "Reset", "Сброс");
        p("ui.menu_key", "Menu key", "Клавиша меню");
        p("ui.hint_bind", "Click a bind, then press a key. Backspace = unbind", "Нажми на бинд, затем на клавишу. Backspace = убрать");
        p("ui.friends", "Friends", "Друзья");
        p("ui.language", "Language: English", "Язык: Русский");
        p("ui.singleplayer", "Singleplayer", "Одиночная игра");
        p("ui.multiplayer", "Multiplayer", "Сетевая игра");
        p("ui.options", "Options", "Настройки игры");
        p("ui.quit", "Quit game", "Выйти");
        p("ui.ghost_menu", "Ghostline menu", "Меню Ghostline");
        p("ui.add", "Add", "Добавить");
        p("ui.add_looked", "Add player under crosshair", "Добавить игрока в прицеле");
        p("ui.friend_name", "Nickname", "Ник");
        p("ui.friends_title", "Friends", "Друзья");
        p("ui.none", "None", "Нет");
        p("ui.settings", "settings", "настройки");
        p("ui.choose_lang", "Choose language / Выберите язык", "Choose language / Выберите язык");
        // pages
        p("page.0", "Combat", "Бой");
        p("page.1", "Movement", "Движение");
        p("page.2", "Player", "Игрок");
        p("page.3", "Visuals", "Визуалы");
        p("page.4", "Misc", "Разное");
        p("page.5", "Theme", "Тема");
        p("page.6", "HUD", "HUD");
        p("page.7", "Configs", "Конфиги");
        p("page.8", "Friends", "Друзья");
        p("page.9", "Cosmetics", "Косметика");
        // gui
        p("ui.enabled", "Enabled", "Включено");
        p("ui.bind", "Bind", "Бинд");
        p("ui.press_key", "Press a key...", "Нажми клавишу...");
        p("ui.count", "%d of %d on", "%d из %d вкл");
        p("ui.confirm", "Press again to confirm", "Нажми ещё раз для подтверждения");
        p("ui.lang_label", "Language", "Язык");
        p("ui.open_friends", "Open friends list", "Открыть список друзей");
        p("ui.panic_hint", "Disables everything until the game is restarted", "Отключает всё до перезапуска игры");
        p("ui.run", "Run", "Запуск");
        // configs
        p("cfg.name", "Config name", "Имя конфига");
        p("cfg.code", "Config code", "Код конфига");
        p("cfg.save", "Save", "Сохранить");
        p("cfg.overwrite", "Overwrite?", "Перезаписать?");
        p("cfg.find", "Import", "Найти");
        p("cfg.copy", "Copy code of current config", "Скопировать код текущего конфига");
        p("cfg.load", "Load", "Загрузить");
        p("cfg.delete", "Delete", "Удалить");
        p("cfg.sure", "Sure?", "Точно?");
        p("cfg.empty", "No configs yet", "Конфигов пока нет");
        p("cfg.empty_hint", "Enter a name above and press Save", "Введите имя выше и нажмите «Сохранить»");
        p("cfg.saved", "Saved: %s", "Сохранено: %s");
        p("cfg.loaded", "Loaded: %s", "Загружено: %s");
        p("cfg.deleted", "Deleted: %s", "Удалено: %s");
        p("cfg.copied", "Code copied to clipboard", "Код скопирован в буфер обмена");
        p("cfg.imported", "Config imported from code", "Конфиг загружен по коду");
        p("cfg.bad_name", "Enter a valid name", "Введите корректное имя");
        p("cfg.bad_code", "Invalid or empty code", "Неверный или пустой код");
        p("cfg.error", "Error: %s", "Ошибка: %s");
        // friends
        p("fr.empty", "No friends yet", "Друзей пока нет");
        p("fr.remove", "Remove", "Убрать");
        // modules / settings / options
        p("mod.Trail", "Trail", "След");
        p("set.Accent", "Accent", "Акцент");
        p("set.Panel opacity", "Panel opacity", "Прозрачность панели");
        p("set.Background logo", "Background logo", "Фоновый логотип");
        p("set.Animations", "Animations", "Анимации");
        p("set.Module list", "Module list", "Список модулей");
        p("set.Watermark", "Watermark", "Ватермарка");
        p("set.Coordinates", "Coordinates", "Координаты");
        p("set.List position", "List position", "Позиция списка");
        p("set.Watermark position", "Watermark position", "Позиция ватермарки");
        p("set.Coords position", "Coords position", "Позиция координат");
        p("set.Sort", "Sort", "Сортировка");
        p("set.Color", "Color", "Цвет");
        p("set.Opacity", "Opacity", "Прозрачность");
        p("set.Style", "Style", "Стиль");
        p("set.Density", "Density", "Плотность");
        p("set.First person", "First person", "От первого лица");
        p("opt.Violet", "Violet", "Фиолетовый");
        p("opt.Graphite", "Graphite", "Графит");
        p("opt.Ice", "Ice", "Лёд");
        p("opt.Emerald", "Emerald", "Изумруд");
        p("opt.Crimson", "Crimson", "Багровый");
        p("opt.Top right", "Top right", "Сверху справа");
        p("opt.Top left", "Top left", "Сверху слева");
        p("opt.Bottom right", "Bottom right", "Снизу справа");
        p("opt.Bottom left", "Bottom left", "Снизу слева");
        p("opt.Length", "By length", "По длине");
        p("opt.A-Z", "A-Z", "По алфавиту");
        p("opt.Accent", "Accent", "Акцент");
        p("opt.White", "White", "Белый");
        p("opt.Rainbow", "Rainbow", "Радуга");
        p("opt.End rod", "End rod", "Эндер-свет");
        p("opt.Soul fire", "Soul fire", "Огонь душ");
        p("opt.Heart", "Hearts", "Сердца");
        p("opt.Note", "Notes", "Ноты");
        p("opt.Enchant", "Enchant", "Чары");
        p("opt.Cloud", "Clouds", "Облака");
    }

    public static String t(String k) { String[] v = M.get(k); return v == null ? k : v[Config.lang == 1 ? 1 : 0]; }
    public static String tOr(String k, String fb) { String[] v = M.get(k); return v == null ? fb : v[Config.lang == 1 ? 1 : 0]; }
    public static Component c(String k) { return Component.literal(t(k)); }
    public static String mod(Module m) { return tOr("mod." + m.name, m.name); }
    public static String set(Setting s) { return tOr("set." + s.name, s.name); }
    public static String opt(String o) { return tOr("opt." + o, o); }
}

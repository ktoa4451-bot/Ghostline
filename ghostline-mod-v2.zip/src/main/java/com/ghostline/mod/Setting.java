package com.ghostline.mod;

public class Setting {
    public final String name;
    public double value;
    public final double def, min, max, step;
    public final String[] options; // enum choices, null otherwise
    public final boolean isText;   // free-text setting
    public String text = "";
    private final String defText;

    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.value = def; this.def = def;
        this.min = min; this.max = max; this.step = step; this.options = null;
        this.isText = false; this.defText = "";
    }

    public Setting(String name, int def, String... options) {
        this.name = name; this.value = def; this.def = def;
        this.min = 0; this.max = options.length - 1; this.step = 1; this.options = options;
        this.isText = false; this.defText = "";
    }

    public Setting(String name, String defText) {
        this.name = name; this.value = 0; this.def = 0;
        this.min = 0; this.max = 0; this.step = 1; this.options = null;
        this.isText = true; this.defText = defText; this.text = defText;
    }

    public int i() { return (int) Math.round(value); }
    public float f() { return (float) value; }

    public void reset() { value = def; text = defText; }

    public String display() {
        if (isText) return text;
        return options != null ? Lang.opt(options[i()]) : String.format(java.util.Locale.ROOT, "%.2f", value);
    }
}

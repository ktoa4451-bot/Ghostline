package com.ghostline.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class CheatMod implements ClientModInitializer {
    private static final ParticleOptions[] TRAIL_TYPES = {
        ParticleTypes.END_ROD, ParticleTypes.SOUL_FIRE_FLAME, ParticleTypes.HEART,
        ParticleTypes.NOTE, ParticleTypes.ENCHANT, ParticleTypes.CLOUD};
    private static boolean wasFly, menuPrev, splashShown, attacked;
    private static int restoreSlot = -1, restoreTicks, totemTimer;

    @Override
    public void onInitializeClient() {
        Config.load();

        Config.PEARL.action = mc -> useItem(mc, Items.ENDER_PEARL, Config.PEARL);
        Config.WIND.action = mc -> useItem(mc, Items.WIND_CHARGE, Config.WIND);
        Config.PANIC.action = CheatMod::panic;
        Config.SWAP1.action = mc -> swap(mc, Config.SWAP1);
        Config.SWAP2.action = mc -> swap(mc, Config.SWAP2);
        Config.SWAP3.action = mc -> swap(mc, Config.SWAP3);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (Config.panic) return;

            // splash + custom main menu replace the vanilla title screen
            if (mc.screen instanceof TitleScreen) {
                if (!splashShown) { splashShown = true; mc.setScreen(new SplashScreen()); }
                else mc.setScreen(new GhostTitleScreen());
            }

            long win = GLFW.glfwGetCurrentContext();
            if (win != 0) {
                boolean md = Config.menuBind > 0 && GLFW.glfwGetKey(win, Config.menuBind) == GLFW.GLFW_PRESS;
                if (md && !menuPrev && mc.screen == null && mc.player != null) mc.setScreen(new GhostGui());
                menuPrev = md;
                for (Module m : Config.ALL) {
                    boolean down = m.bind > 0 && GLFW.glfwGetKey(win, m.bind) == GLFW.GLFW_PRESS;
                    if (down && !m.prevDown && mc.screen == null && mc.player != null) {
                        if (m.action != null) m.action.accept(mc);
                        else { m.enabled = !m.enabled; Config.save(); }
                    }
                    m.prevDown = down;
                    if (Config.panic) return;
                }
            }
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return;
            tick(mc, p);
        });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("ghostline", "hud"), Hud::render);
    }

    /** Turns everything off and locks the client until the game is restarted. */
    public static void panic(Minecraft mc) {
        for (Module m : Config.ALL) m.enabled = false;
        Config.panic = true;
        LocalPlayer p = mc.player;
        if (p != null) {
            p.getAbilities().setFlyingSpeed(0.05f);
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
            }
            MobEffectInstance e = p.getEffect(MobEffects.NIGHT_VISION);
            if (e != null && !e.isVisible()) p.removeEffect(MobEffects.NIGHT_VISION);
        }
        if (mc.screen != null && mc.screen.getClass().getName().startsWith("com.ghostline")) {
            if (mc.level != null) mc.setScreen(null);
            else mc.setScreen(new TitleScreen());
        }
    }

    static boolean validTarget(LivingEntity e, LocalPlayer p, int mode) {
        if (e == p || !e.isAlive() || e instanceof ArmorStand) return false;
        if (Config.NOFRIEND.enabled && Config.isFriend(e)) return false;
        boolean isPlayer = e instanceof Player;
        if (mode == 1 && isPlayer) return false;   // mobs only
        if (mode == 2 && !isPlayer) return false;  // players only
        return true;
    }

    private static LivingEntity crosshairTarget(Minecraft mc, LocalPlayer p, int mode) {
        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le && validTarget(le, p, mode)) return le;
        return null;
    }

    private static int findWeapon(LocalPlayer p, int kind) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getItem(i);
            boolean ok = kind == 0 ? s.is(ItemTags.SWORDS) : kind == 1 ? s.is(ItemTags.AXES) : s.is(Items.MACE);
            if (ok) return i;
        }
        return -1;
    }

    private static boolean matches(ItemStack s, int kind, String name) {
        if (s.isEmpty()) return false;
        boolean typeOk = switch (kind) {
            case 0 -> true;
            case 1 -> s.is(Items.TOTEM_OF_UNDYING);
            case 2 -> s.is(Items.PLAYER_HEAD);
            case 3 -> s.is(Items.SHIELD);
            case 4 -> s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE);
            case 5 -> s.is(Items.ENDER_PEARL);
            case 6 -> s.is(Items.FIREWORK_ROCKET);
            default -> s.is(Items.END_CRYSTAL);
        };
        if (!typeOk) return false;
        boolean hasName = name != null && !name.isBlank();
        if (kind == 0 && !hasName) return false; // "Any" needs a name filter
        if (!hasName) return true;
        return s.getHoverName().getString().toLowerCase(Locale.ROOT).contains(name.trim().toLowerCase(Locale.ROOT));
    }

    /** AutoSwap: moves the configured item into the offhand (or selects it in the hotbar). */
    private static void swap(Minecraft mc, Module m) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return;
        int kind = m.get(0).i();
        String name = m.get(1).text;
        boolean offhand = m.get(2).i() == 0;
        if (offhand) {
            if (matches(p.getOffhandItem(), kind, name)) return;
            for (int i = 0; i < 36; i++) {
                if (matches(p.getInventory().getItem(i), kind, name)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                    return;
                }
            }
        } else {
            for (int i = 0; i < 9; i++) {
                if (matches(p.getInventory().getItem(i), kind, name)) {
                    if (p.getInventory().getSelectedSlot() != i) p.getInventory().setSelectedSlot(i);
                    return;
                }
            }
        }
    }

    private static void useItem(Minecraft mc, Item item, Module m) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return;
        if (p.getOffhandItem().is(item)) { mc.gameMode.useItem(p, InteractionHand.OFF_HAND); return; }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getItem(i).is(item)) {
                int prev = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(i);
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                if (m.get(0).i() == 1 && prev != i) { restoreSlot = prev; restoreTicks = 2; }
                return;
            }
        }
    }

    private static void tick(Minecraft mc, LocalPlayer p) {
        attacked = false;

        if (restoreTicks > 0 && --restoreTicks == 0 && restoreSlot >= 0) {
            p.getInventory().setSelectedSlot(restoreSlot);
            restoreSlot = -1;
        }

        // Fly
        if (Config.FLY.enabled) {
            p.getAbilities().mayfly = true;
            p.getAbilities().flying = true;
            p.getAbilities().setFlyingSpeed(0.05f * Config.FLY.get(0).f());
            wasFly = true;
        } else if (wasFly) {
            p.getAbilities().setFlyingSpeed(0.05f);
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
            }
            wasFly = false;
        }

        // Speed
        if (Config.SPEED.enabled && (p.zza != 0 || p.xxa != 0)) {
            Vec3 v = p.getDeltaMovement();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            double k = Config.SPEED.get(0).value;
            if (h > 0.001 && h < 0.7) p.setDeltaMovement(v.x * k, v.y, v.z * k);
        }

        // Cosmetics: particle trail around the player
        if (Config.TRAIL.enabled && (Config.TRAIL.get(2).i() == 1 || !mc.options.getCameraType().isFirstPerson())) {
            ParticleOptions type = TRAIL_TYPES[Math.max(0, Math.min(TRAIL_TYPES.length - 1, Config.TRAIL.get(0).i()))];
            int n = Config.TRAIL.get(1).i();
            for (int i = 0; i < n; i++) {
                mc.level.addParticle(type,
                    p.getX() + (p.getRandom().nextDouble() - 0.5) * 0.8,
                    p.getY() + p.getRandom().nextDouble() * 1.8,
                    p.getZ() + (p.getRandom().nextDouble() - 0.5) * 0.8,
                    0.0, 0.02, 0.0);
            }
        }

        // Fullbright
        if (Config.BRIGHT.enabled) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        } else {
            MobEffectInstance e = p.getEffect(MobEffects.NIGHT_VISION);
            if (e != null && e.getDuration() <= 400 && !e.isVisible()) p.removeEffect(MobEffects.NIGHT_VISION);
        }

        // AutoSprint
        if (Config.SPRINT.enabled && p.zza > 0 && !p.isShiftKeyDown()) p.setSprinting(true);

        // AutoTotem
        if (Config.TOTEM.enabled && mc.gameMode != null) {
            int delay = Math.max(1, Config.TOTEM.get(0).i());
            float minHp = Config.TOTEM.get(1).f();
            boolean need = !p.getOffhandItem().is(Items.TOTEM_OF_UNDYING) && (minHp <= 0 || p.getHealth() <= minHp);
            if (need) {
                if (++totemTimer >= delay) {
                    totemTimer = 0;
                    for (int i = 0; i < 36; i++) {
                        if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                            int slot = i < 9 ? 36 + i : i;
                            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                            break;
                        }
                    }
                }
            } else totemTimer = 0;
        }

        boolean free = mc.screen == null && mc.gameMode != null;

        // AutoMace: mace hits players on its own (smash attack when falling)
        if (Config.AUTOMACE.enabled && free) {
            HitResult hit = mc.hitResult;
            if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof Player target && validTarget(target, p, 2)) {
                int slot = findWeapon(p, 2);
                if (slot >= 0) {
                    int prev = p.getInventory().getSelectedSlot();
                    if (prev != slot) p.getInventory().setSelectedSlot(slot);
                    if (p.fallDistance >= Config.AUTOMACE.get(0).f() && p.getAttackStrengthScale(0.0f) >= 0.9f) {
                        mc.gameMode.attack(p, target);
                        p.swing(InteractionHand.MAIN_HAND);
                        attacked = true;
                        if (Config.AUTOMACE.get(1).i() == 1 && prev != slot) { restoreSlot = prev; restoreTicks = 3; }
                    }
                }
            }
        }

        // AimAssist
        if (Config.AIM.enabled && mc.screen == null) {
            int mode = Config.AIM.get(0).i();
            float smooth = Config.AIM.get(1).f();
            float fov = Config.AIM.get(2).f();
            double range = Config.AIM.get(3).value;
            LivingEntity best = null;
            double bestDist = range * range;
            Vec3 eye = p.getEyePosition();
            for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class,
                    p.getBoundingBox().inflate(range), x -> validTarget(x, p, mode))) {
                if (!p.hasLineOfSight(e)) continue;
                Vec3 c = e.getBoundingBox().getCenter();
                float yaw = (float) (Math.atan2(c.z - eye.z, c.x - eye.x) * 180.0 / Math.PI) - 90f;
                if (Math.abs(Mth.wrapDegrees(yaw - p.getYRot())) > fov / 2f) continue;
                double d = p.distanceToSqr(e);
                if (d < bestDist) { bestDist = d; best = e; }
            }
            if (best != null) {
                Vec3 c = best.getBoundingBox().getCenter();
                double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
                float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
                float pitch = (float) (-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
                p.setYRot(p.getYRot() + Mth.wrapDegrees(yaw - p.getYRot()) * smooth);
                p.setXRot(Mth.clamp(p.getXRot() + (pitch - p.getXRot()) * smooth, -90f, 90f));
            }
        }

        // TriggerBot
        if (Config.TRIGGER.enabled && free && !attacked) {
            LivingEntity t = crosshairTarget(mc, p, Config.TRIGGER.get(0).i());
            if (t != null && p.getAttackStrengthScale(0.0f) >= Config.TRIGGER.get(1).f()) {
                mc.gameMode.attack(p, t);
                p.swing(InteractionHand.MAIN_HAND);
            }
        }
    }
}

package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.Random;

/** Small immediate-mode drawing helpers shared by all Ghostline screens and the HUD. */
public final class Ui {
    private Ui() { }

    public static final Identifier LOGO = Identifier.fromNamespaceAndPath("ghostline", "textures/gui/logo.png");
    public static final Identifier LOGO_BG = Identifier.fromNamespaceAndPath("ghostline", "textures/gui/logo_bg.png");

    // base palette (RGB, alpha is applied with c())
    public static final int BG = 0x0B0B11, SIDE = 0x0E0E15, CARD = 0x16161F, CARD_HOVER = 0x20202C,
        BORDER = 0x2B2B39, TEXT = 0xE9E9F2, MUTED = 0x8B8B9C, DANGER = 0xD9707C;

    public static final int[] ACCENTS = {0x7B6CD9, 0xB4B8C5, 0x7FB2D9, 0x5FB88A, 0xC25B6B};

    public static int accent() { return ACCENTS[Mth.clamp(Config.THEME.get(0).i(), 0, ACCENTS.length - 1)]; }
    public static float panelOpacity() { return Config.THEME.get(1).f(); }
    public static boolean bgLogo() { return Config.THEME.get(2).i() == 1; }
    public static boolean anim() { return Config.THEME.get(3).i() == 1; }

    public static int c(int rgb, float a) {
        int al = Mth.clamp((int) (a * 255f), 4, 255);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (r << 16) | (g << 8) | b;
    }

    public static Font font() { return Minecraft.getInstance().font; }
    public static int tw(String s) { return font().width(s); }

    public static void text(GuiGraphics g, String s, int x, int y, int color) { g.drawString(font(), s, x, y, color, false); }
    public static void textR(GuiGraphics g, String s, int xRight, int y, int color) { text(g, s, xRight - tw(s), y, color); }
    public static void textC(GuiGraphics g, String s, int cx, int y, int color) { text(g, s, cx - tw(s) / 2, y, color); }

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - d * d));
            g.fill(x + dx, y + i, x + w - dx, y + i + 1, color);
            g.fill(x + dx, y + h - 1 - i, x + w - dx, y + h - i, color);
        }
    }

    public static void ring(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        g.fill(x + r, y, x + w - r, y + 1, color);
        g.fill(x + r, y + h - 1, x + w - r, y + h, color);
        g.fill(x, y + r, x + 1, y + h - r, color);
        g.fill(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - d * d));
            g.fill(x + dx, y + i, x + dx + 1, y + i + 1, color);
            g.fill(x + w - dx - 1, y + i, x + w - dx, y + i + 1, color);
            g.fill(x + dx, y + h - 1 - i, x + dx + 1, y + h - i, color);
            g.fill(x + w - dx - 1, y + h - 1 - i, x + w - dx, y + h - i, color);
        }
    }

    /** Toggle switch, 22x11. t = 0..1 animation state. */
    public static void toggle(GuiGraphics g, int x, int y, float t, float alpha) {
        int bg = mix(0x2A2A37, accent(), t);
        rect(g, x, y, 22, 11, 5, c(bg, alpha));
        int kx = x + 1 + (int) (t * 11);
        rect(g, kx, y + 1, 9, 9, 4, c(0xF2F2F8, alpha));
    }

    public static void logo(GuiGraphics g, Identifier id, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, size, size, 256, 256, 256, 256);
    }

    public static void stars(GuiGraphics g, int w, int h, float alpha) {
        Random r = new Random(7);
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < 34; i++) {
            int x = r.nextInt(Math.max(1, w)), y = r.nextInt(Math.max(1, h));
            float tw = (float) (0.18 + 0.22 * Math.sin(t * (0.8 + (i % 5) * 0.3) + i));
            int s = (i % 7 == 0) ? 2 : 1;
            g.fill(x, y, x + s, y + s, c(0xC8C4F0, Math.max(0.04f, tw) * alpha));
        }
    }

    /** Dark gradient background with faint stars; alpha 0..255. */
    public static void backdrop(GuiGraphics g, int w, int h, int alpha) {
        int a = (alpha & 0xFF) << 24;
        g.fillGradient(0, 0, w, h, a | 0x07070C, a | 0x17112B);
        stars(g, w, h, alpha / 255f);
    }
}

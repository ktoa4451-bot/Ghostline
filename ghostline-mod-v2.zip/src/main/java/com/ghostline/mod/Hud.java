package com.ghostline.mod;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** In-game overlay: watermark, active module list, coordinates. */
public final class Hud {
    private Hud() { }

    private static final int[] used = new int[4];

    // corner ids: 0 top right, 1 top left, 2 bottom right, 3 bottom left
    private static int[] place(int corner, int w, int h, int sw, int sh) {
        boolean right = corner == 0 || corner == 2, bottom = corner >= 2;
        int off = used[corner];
        int x = right ? sw - 4 - w : 4;
        int y = bottom ? sh - 4 - off - h : 4 + off;
        used[corner] += h + 3;
        return new int[]{x, y};
    }

    public static void render(GuiGraphics g, DeltaTracker delta) {
        if (Config.panic) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        Module h = Config.HUD;
        float scale = h.get(8).f();
        float op = h.get(9).f();
        int sw = (int) (g.guiWidth() / scale), sh = (int) (g.guiHeight() / scale);

        used[0] = used[1] = used[2] = used[3] = 0;
        // keep clear of the status effect icons in the top right corner
        if (!mc.player.getActiveEffects().isEmpty()) used[0] = (int) (28 / scale);

        g.pose().pushMatrix();
        g.pose().scale(scale, scale);

        if (h.get(1).i() == 1) watermark(g, mc, h.get(4).i(), op, sw, sh);
        if (h.get(2).i() == 1) coords(g, mc, h.get(5).i(), op, sw, sh);
        if (h.get(0).i() == 1) moduleList(g, h.get(3).i(), h.get(6).i(), h.get(7).i(), op, sw, sh);

        g.pose().popMatrix();
    }

    private static void watermark(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        String name = "Ghostline";
        String user = mc.getUser().getName();
        int w = 12 + 4 + Ui.tw(name) + 8 + Ui.tw(user) + 10;
        int[] p = place(corner, w, 16, sw, sh);
        Ui.rect(g, p[0], p[1], w, 16, 5, Ui.c(0x0B0B11, 0.72f * op));
        Ui.ring(g, p[0], p[1], w, 16, 5, Ui.c(Ui.accent(), 0.55f * op));
        Ui.logo(g, Ui.LOGO, p[0] + 4, p[1] + 2, 12);
        Ui.text(g, name, p[0] + 20, p[1] + 4, Ui.c(Ui.TEXT, op));
        Ui.text(g, user, p[0] + 20 + Ui.tw(name) + 8, p[1] + 4, Ui.c(Ui.MUTED, op));
    }

    private static void coords(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        String s = "XYZ  " + mc.player.getBlockX() + "  " + mc.player.getBlockY() + "  " + mc.player.getBlockZ();
        int w = Ui.tw(s) + 10;
        int[] p = place(corner, w, 14, sw, sh);
        Ui.rect(g, p[0], p[1], w, 14, 4, Ui.c(0x0B0B11, 0.62f * op));
        Ui.text(g, s, p[0] + 5, p[1] + 3, Ui.c(Ui.TEXT, op));
    }

    private static void moduleList(GuiGraphics g, int corner, int sort, int colorMode, float op, int sw, int sh) {
        List<String> names = new ArrayList<>();
        for (Module m : Config.ALL) if (m.action == null && m.enabled) names.add(Lang.mod(m));
        if (names.isEmpty()) return;
        if (sort == 0) names.sort(Comparator.comparingInt((String s) -> -Ui.tw(s)));
        else names.sort(String.CASE_INSENSITIVE_ORDER);

        boolean right = corner == 0 || corner == 2;
        int line = 12;
        int maxW = 0;
        for (String s : names) maxW = Math.max(maxW, Ui.tw(s) + 10);
        int[] p = place(corner, maxW, names.size() * line, sw, sh);
        used[corner] += 0;
        long t = System.currentTimeMillis();
        for (int i = 0; i < names.size(); i++) {
            String s = names.get(i);
            int w = Ui.tw(s) + 10;
            int x = right ? p[0] + maxW - w : p[0];
            int y = p[1] + i * line;
            int col;
            if (colorMode == 1) col = 0xFFFFFF;
            else if (colorMode == 2) col = Color.HSBtoRGB(((t % 6000) / 6000f + i * 0.06f) % 1f, 0.42f, 1f) & 0xFFFFFF;
            else col = Ui.accent();
            g.fill(x, y, x + w, y + line, Ui.c(0x0B0B11, 0.60f * op));
            int barX = right ? x + w - 2 : x;
            g.fill(barX, y, barX + 2, y + line, Ui.c(col, op));
            Ui.text(g, s, x + (right ? 4 : 5), y + 2, Ui.c(col, op));
        }
    }
}

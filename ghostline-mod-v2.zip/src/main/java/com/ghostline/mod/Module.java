package com.ghostline.mod;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Module {
    public final String name;          // internal name, also used as config key
    public final int category;         // 0 combat, 1 move, 2 visual, 3 misc
    public boolean enabled;
    public int bind = -1, defBind = -1; // GLFW key code, -1 = not bound
    public boolean prevDown;
    public Consumer<Minecraft> action; // non-null => one-shot action instead of a toggle
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, int category) { this.name = name; this.category = category; }

    public Module key(int k) { bind = k; defBind = k; return this; }
    public Module add(Setting s) { settings.add(s); return this; }
    public Setting get(int i) { return settings.get(i); }
}

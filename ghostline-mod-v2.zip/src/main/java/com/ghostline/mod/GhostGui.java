package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** The main Ghostline window: sidebar with pages, module cards, settings, configs, friends. */
public class GhostGui extends GhostScreen {
    public static int page = 0;
    private static final Object MENU = new Object();

    private Module detail;
    private double scroll, scrollTarget;
    private int contentH;
    private final long openedAt = System.currentTimeMillis();
    private long pageAt = openedAt;
    private Object listening;                     // Module or MENU while waiting for a key
    private EditBox cfgName, cfgCode, friendBox;
    private final Map<Setting, EditBox> textBoxes = new HashMap<>();
    private String status = "";
    private boolean statusErr;
    private long statusAt;
    private String confirm;
    private long confirmAt;
    private List<String> cfgList = new ArrayList<>();
    private float al = 1f, pa = 1f;
    private int wx, wy, ww, wh, sbw, cx, bx, by, bw, bh;

    public GhostGui() {
        super("Ghostline");
        cfgList = ConfigStore.list();
    }

    // ------------------------------------------------------------------ setup

    @Override
    protected void init() { rebuild(); }

    private Module settingsModule() {
        if (detail != null) return detail;
        return switch (page) { case 5 -> Config.THEME; case 6 -> Config.HUD; case 9 -> Config.TRAIL; default -> null; };
    }

    private EditBox makeBox(int maxLen, String hint, String value) {
        EditBox b = new EditBox(this.font, 0, 0, 100, 14, Component.empty());
        b.setBordered(false);
        b.setMaxLength(maxLen);
        b.setHint(Component.literal(hint));
        b.setValue(value);
        addWidget(b);
        return b;
    }

    private void rebuild() {
        clearWidgets();
        textBoxes.clear();
        cfgName = cfgCode = friendBox = null;
        if (detail == null && page == 7) {
            cfgName = makeBox(24, Lang.t("cfg.name"), "");
            cfgCode = makeBox(8000, Lang.t("cfg.code"), "");
        } else if (detail == null && page == 8) {
            friendBox = makeBox(16, Lang.t("ui.friend_name"), "");
        }
        Module sm = settingsModule();
        if (sm != null) {
            for (Setting s : sm.settings) {
                if (s.isText) textBoxes.put(s, makeBox(32, Lang.set(s), s.text));
            }
        }
    }

    private void setPage(int p) {
        page = p;
        detail = null;
        scroll = scrollTarget = 0;
        pageAt = System.currentTimeMillis();
        confirm = null;
        listening = null;
        if (p == 7) cfgList = ConfigStore.list();
        rebuild();
    }

    private void openDetail(Module m) {
        detail = m;
        scroll = scrollTarget = 0;
        pageAt = System.currentTimeMillis();
        listening = null;
        rebuild();
    }

    private void closeDetail() {
        Config.save();
        detail = null;
        scroll = scrollTarget = 0;
        pageAt = System.currentTimeMillis();
        rebuild();
    }

    private void setStatus(String msg, boolean err) { status = msg; statusErr = err; statusAt = System.currentTimeMillis(); }

    private boolean confirmed(String id) {
        long now = System.currentTimeMillis();
        if (id.equals(confirm) && now - confirmAt < 4000) { confirm = null; return true; }
        confirm = id;
        confirmAt = now;
        return false;
    }

    private boolean pending(String id) {
        return id.equals(confirm) && System.currentTimeMillis() - confirmAt < 4000;
    }

    private void focusBox(EditBox b) {
        List<EditBox> all = new ArrayList<>(textBoxes.values());
        if (cfgName != null) all.add(cfgName);
        if (cfgCode != null) all.add(cfgCode);
        if (friendBox != null) all.add(friendBox);
        for (EditBox o : all) o.setFocused(o == b);
        setFocused(b);
    }

    @Override
    protected void onBackgroundClick() {
        List<EditBox> all = new ArrayList<>(textBoxes.values());
        if (cfgName != null) all.add(cfgName);
        if (cfgCode != null) all.add(cfgCode);
        if (friendBox != null) all.add(friendBox);
        for (EditBox o : all) o.setFocused(false);
        setFocused(null);
    }

    @Override
    protected void scrollBy(double amount) {
        scrollTarget = Mth.clamp(scrollTarget + amount, 0, Math.max(0, contentH - bh));
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                int v = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
                if (listening == MENU) { if (v > 0) Config.menuBind = v; }
                else ((Module) listening).bind = v;
                Config.save();
            }
            listening = null;
            return true;
        }
        if (!(getFocused() instanceof EditBox) && key == Config.menuBind) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    // ------------------------------------------------------------------ layout & drawing

    private void layout() {
        long now = System.currentTimeMillis();
        float open = Ui.anim() ? Mth.clamp((now - openedAt) / 220f, 0f, 1f) : 1f;
        open = 1f - (1f - open) * (1f - open);
        al = open;
        pa = Ui.anim() ? Mth.clamp((now - pageAt) / 200f, 0f, 1f) : 1f;
        ww = Math.min(this.width - 12, 560);
        wh = Math.min(this.height - 12, 330);
        wx = (this.width - ww) / 2;
        wy = (this.height - wh) / 2 + (int) ((1f - open) * 12);
        sbw = Mth.clamp((int) (ww * 0.27f), 82, 132);
        cx = wx + sbw;
        bx = cx + 10;
        bw = ww - sbw - 20;
        by = wy + 46;
        bh = wh - 46 - 8;
    }

    private int col(int rgb, float a) { return Ui.c(rgb, a * al * pa); }
    private int chrome(int rgb, float a) { return Ui.c(rgb, a * al); }

    private int enabledCount(int category) {
        int n = 0;
        for (Module m : Config.ALL) if (m.category == category && m.action == null && m.enabled) n++;
        return n;
    }

    private List<Module> modulesOf(int category) {
        List<Module> out = new ArrayList<>();
        for (Module m : Config.ALL) if (m.category == category) out.add(m);
        return out;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        beginFrame(mouseX, mouseY);
        layout();
        Minecraft mc = Minecraft.getInstance();

        g.fill(0, 0, this.width, this.height, Ui.c(0x000000, 0.58f * al));

        // window
        for (int i = 3; i >= 1; i--) Ui.rect(g, wx - i * 2, wy - i * 2, ww + i * 4, wh + i * 4, 9 + i, chrome(0x000000, 0.10f));
        Ui.rect(g, wx, wy, ww, wh, 9, chrome(Ui.BG, Ui.panelOpacity()));
        Ui.rect(g, wx, wy, sbw, wh, 9, chrome(Ui.SIDE, 0.97f));
        g.fill(wx + sbw - 9, wy, wx + sbw, wy + wh, chrome(Ui.SIDE, 0.97f));
        g.fill(wx + sbw, wy + 8, wx + sbw + 1, wy + wh - 8, chrome(Ui.BORDER, 0.8f));
        Ui.ring(g, wx, wy, ww, wh, 9, chrome(Ui.BORDER, 0.95f));

        if (Ui.bgLogo()) {
            g.enableScissor(cx + 2, wy + 2, wx + ww - 2, wy + wh - 2);
            int size = Math.min(256, Math.min(wh + 10, ww - sbw + 40));
            Ui.logo(g, Ui.LOGO_BG, wx + ww - size + size / 8, wy + wh - size + size / 8, size);
            g.disableScissor();
        }

        drawSidebar(g, mc);
        drawHeader(g);

        // body
        clipX1 = bx - 4; clipY1 = by; clipX2 = bx + bw + 4; clipY2 = by + bh;
        g.enableScissor(clipX1, clipY1, clipX2, clipY2);
        if (Ui.anim()) scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f); else scroll = scrollTarget;
        int top = by - (int) Math.round(scroll);
        int end;
        if (detail != null) end = detailView(g, detail, top);
        else {
            switch (page) {
                case 0, 1, 2, 3, 4 -> end = modulesView(g, page, top);
                case 5 -> end = themeView(g, top);
                case 6 -> end = settingsView(g, Config.HUD, false, false, top);
                case 7 -> end = configsView(g, top);
                case 8 -> end = friendsView(g, top);
                default -> end = detailViewTrail(g, top);
            }
        }
        renderBoxes(g, mouseX, mouseY, delta);
        g.disableScissor();
        contentH = end - top + 6;
        scrollTarget = Mth.clamp(scrollTarget, 0, Math.max(0, contentH - bh));

        // scrollbar
        if (contentH > bh) {
            int trackH = bh - 4;
            int barH = Math.max(14, (int) (trackH * (bh / (double) contentH)));
            int barY = by + 2 + (int) ((trackH - barH) * (scroll / Math.max(1, contentH - bh)));
            Ui.rect(g, wx + ww - 7, barY, 3, barH, 1, chrome(Ui.accent(), 0.6f));
        }
    }

    private void renderBoxes(GuiGraphics g, int mouseX, int mouseY, float delta) {
        for (EditBox b : textBoxesAll()) {
            if (b.visible) b.render(g, mouseX, mouseY, delta);
        }
    }

    private List<EditBox> textBoxesAll() {
        List<EditBox> all = new ArrayList<>(textBoxes.values());
        if (cfgName != null) all.add(cfgName);
        if (cfgCode != null) all.add(cfgCode);
        if (friendBox != null) all.add(friendBox);
        return all;
    }

    private void drawSidebar(GuiGraphics g, Minecraft mc) {
        Ui.logo(g, Ui.LOGO, wx + 9, wy + 8, 20);
        Ui.text(g, "Ghostline", wx + 33, wy + 14, chrome(Ui.TEXT, 1f));

        int navY = wy + 38;
        int itemH = Mth.clamp((wh - 38 - 36) / 11, 14, 20);
        for (int i = 0; i < 10; i++) {
            if (i == 5) {
                g.fill(wx + 12, navY + 2, wx + sbw - 12, navY + 3, chrome(Ui.BORDER, 0.8f));
                navY += 6;
            }
            final int idx = i;
            boolean sel = page == i;
            boolean hov = over(wx + 6, navY, sbw - 12, itemH, false);
            float hv = anim("nav" + i, sel ? 1f : (hov ? 0.55f : 0f));
            if (hv > 0.02f) Ui.rect(g, wx + 6, navY, sbw - 12, itemH, 5, chrome(Ui.mix(Ui.SIDE, 0x2A2A3A, hv), 0.95f));
            if (sel) g.fill(wx + 6, navY + 3, wx + 8, navY + itemH - 3, chrome(Ui.accent(), 1f));
            Ui.text(g, Lang.t("page." + i), wx + 14, navY + (itemH - 8) / 2, chrome(Ui.mix(Ui.MUTED, Ui.TEXT, hv), 1f));
            int cnt = i < 5 ? enabledCount(i) : (i == 9 && Config.TRAIL.enabled ? 1 : 0);
            if (cnt > 0) Ui.textR(g, String.valueOf(cnt), wx + sbw - 12, navY + (itemH - 8) / 2, chrome(Ui.accent(), 1f));
            hit(wx + 6, navY, sbw - 12, itemH, false, () -> setPage(idx));
            navY += itemH;
        }

        String user;
        try { user = mc.getUser().getName(); } catch (Exception e) { user = "Ghostline"; }
        g.fill(wx + 12, wy + wh - 32, wx + sbw - 12, wy + wh - 31, chrome(Ui.BORDER, 0.8f));
        Ui.text(g, user, wx + 12, wy + wh - 26, chrome(Ui.TEXT, 1f));
        Ui.text(g, "v1.0", wx + 12, wy + wh - 16, chrome(Ui.MUTED, 1f));
    }

    private void drawHeader(GuiGraphics g) {
        String title = detail != null ? Lang.mod(detail) : Lang.t("page." + page);
        g.pose().pushMatrix();
        g.pose().translate((float) (cx + 12), (float) (wy + 10));
        g.pose().scale(1.3f, 1.3f);
        Ui.text(g, title, 0, 0, chrome(Ui.TEXT, 1f));
        g.pose().popMatrix();

        String sub;
        boolean err = false;
        if (System.currentTimeMillis() - statusAt < 4000 && !status.isEmpty()) { sub = status; err = statusErr; }
        else sub = subtitle();
        Ui.text(g, sub, cx + 12, wy + 28, chrome(err ? Ui.DANGER : Ui.MUTED, 1f));

        // close
        int cxx = wx + ww - 24, cyy = wy + 8;
        boolean hov = over(cxx, cyy, 16, 16, false);
        float hv = anim("close", hov ? 1f : 0f);
        Ui.rect(g, cxx, cyy, 16, 16, 5, chrome(Ui.mix(Ui.CARD, 0x3A2A30, hv), 0.95f));
        Ui.textC(g, "x", cxx + 8, cyy + 4, chrome(Ui.mix(Ui.MUTED, Ui.TEXT, hv), 1f));
        hit(cxx, cyy, 16, 16, false, this::onClose);

        if (detail != null) {
            String back = "< " + Lang.t("ui.back");
            int bwid = Ui.tw(back) + 14;
            int bxx = cxx - bwid - 6;
            boolean h2 = over(bxx, cyy, bwid, 16, false);
            float hv2 = anim("back", h2 ? 1f : 0f);
            Ui.rect(g, bxx, cyy, bwid, 16, 5, chrome(Ui.mix(Ui.CARD, Ui.CARD_HOVER, hv2), 0.95f));
            Ui.ring(g, bxx, cyy, bwid, 16, 5, chrome(Ui.mix(Ui.BORDER, Ui.accent(), hv2), 0.95f));
            Ui.textC(g, back, bxx + bwid / 2, cyy + 4, chrome(Ui.TEXT, 1f));
            hit(bxx, cyy, bwid, 16, false, this::closeDetail);
        }
        g.fill(cx + 1, wy + 42, wx + ww - 8, wy + 43, chrome(Ui.BORDER, 0.6f));
    }

    private String subtitle() {
        if (detail != null) return Lang.t("ui.settings");
        if (page >= 0 && page <= 4) {
            List<Module> mods = modulesOf(page);
            int on = 0;
            int total = 0;
            for (Module m : mods) { if (m.action == null) { total++; if (m.enabled) on++; } }
            return String.format(Lang.t("ui.count"), on, total);
        }
        return "";
    }

    // ------------------------------------------------------------------ pages

    private int modulesView(GuiGraphics g, int category, int y) {
        List<Module> mods = modulesOf(category);
        int gap = 6, cw = (bw - gap) / 2, ch = 32;
        for (int i = 0; i < mods.size(); i++) {
            int x = bx + (i % 2) * (cw + gap);
            int yy = y + (i / 2) * (ch + gap);
            card(g, mods.get(i), x, yy, cw, ch);
        }
        return y + ((mods.size() + 1) / 2) * (ch + gap);
    }

    private void card(GuiGraphics g, Module m, int x, int y, int w, int h) {
        boolean act = m.action != null;
        boolean visible = y + h >= by && y <= by + bh;
        boolean hov = visible && over(x, y, w, h, true);
        float hv = anim("c" + m.name, hov ? 1f : 0f);
        float on = anim("on" + m.name, m.enabled ? 1f : 0f);
        boolean isPanic = m == Config.PANIC;
        boolean warn = isPanic && pending("panic");

        Ui.rect(g, x, y, w, h, 7, col(Ui.mix(Ui.CARD, Ui.CARD_HOVER, hv), 0.92f));
        Ui.ring(g, x, y, w, h, 7, col(Ui.mix(Ui.BORDER, warn ? Ui.DANGER : Ui.accent(), on * 0.75f + hv * 0.35f + (warn ? 1f : 0f)), 0.95f));
        Ui.text(g, warn ? Lang.t("ui.confirm") : Lang.mod(m), x + 9, y + 7, col(warn ? Ui.DANGER : Ui.TEXT, 1f));
        String sub = isPanic ? Lang.t("ui.run") : (m.bind > 0 ? "[" + Config.keyName(m.bind) + "]" : "");
        if (!sub.isEmpty()) Ui.text(g, sub, x + 9, y + 19, col(Ui.MUTED, 1f));

        int gearX = x + w - 52;
        Ui.textC(g, ">", gearX + 10, y + h / 2 - 4, col(Ui.mix(Ui.MUTED, Ui.TEXT, hv), 1f));
        if (!act) Ui.toggle(g, x + w - 30, y + h / 2 - 6, on, al * pa);

        // main zone first, specialised zones after (later hits win)
        hit(x, y, w, h, true, () -> {
            if (m.action == null) { m.enabled = !m.enabled; Config.save(); }
            else if (m == Config.PANIC) {
                if (confirmed("panic")) CheatMod.panic(Minecraft.getInstance());
            } else openDetail(m);
        });
        hit(gearX, y, 22, h, true, () -> openDetail(m));
        if (!act) hit(x + w - 32, y, 32, h, true, () -> { m.enabled = !m.enabled; Config.save(); });
    }

    private int detailView(GuiGraphics g, Module m, int y) {
        y = settingsView(g, m, true, true, y);
        if (m == Config.NOFRIEND) y = buttonRow(g, "openfr", Lang.t("ui.open_friends"), y, () -> setPage(8));
        if (m == Config.PANIC) {
            Ui.text(g, Lang.t("ui.panic_hint"), bx + 4, y + 4, col(Ui.MUTED, 1f));
            y += 16;
        }
        return y;
    }

    private int detailViewTrail(GuiGraphics g, int y) { return settingsView(g, Config.TRAIL, true, true, y); }

    private int themeView(GuiGraphics g, int y) {
        y = settingsView(g, Config.THEME, false, false, y);
        // language
        rowBg(g, y, Lang.t("ui.lang_label"));
        int cw = 70, gap = 4;
        int x2 = bx + bw - cw - 6, x1 = x2 - cw - gap;
        langChip(g, "English", 0, x1, y + 3, cw);
        langChip(g, "Русский", 1, x2, y + 3, cw);
        y += 26;
        // menu key
        y = bindRowMenu(g, y);
        return y;
    }

    private void langChip(GuiGraphics g, String label, int value, int x, int y, int w) {
        boolean sel = Config.lang == value;
        boolean hov = over(x, y, w, 18, true);
        float t = anim("lang" + value, sel ? 1f : (hov ? 0.4f : 0f));
        Ui.rect(g, x, y, w, 18, 5, col(Ui.mix(Ui.CARD_HOVER, Ui.accent(), t * 0.55f), 0.95f));
        Ui.ring(g, x, y, w, 18, 5, col(Ui.mix(Ui.BORDER, Ui.accent(), t), 0.95f));
        Ui.textC(g, label, x + w / 2, y + 5, col(Ui.TEXT, 1f));
        hit(x, y, w, 18, true, () -> { Config.lang = value; Config.save(); rebuild(); });
    }

    private int bindRowMenu(GuiGraphics g, int y) {
        rowBg(g, y, Lang.t("ui.menu_key"));
        String label = listening == MENU ? Lang.t("ui.press_key") : Config.keyName(Config.menuBind);
        chip(g, "menukey", label, bx + bw - 126, y + 3, 120, listening == MENU, () -> listening = MENU);
        return y + 26;
    }

    // ---- generic rows

    private void rowBg(GuiGraphics g, int y, String label) {
        Ui.rect(g, bx, y, bw, 24, 6, col(Ui.CARD, 0.85f));
        Ui.ring(g, bx, y, bw, 24, 6, col(Ui.BORDER, 0.7f));
        Ui.text(g, label, bx + 10, y + 8, col(Ui.TEXT, 1f));
    }

    private void chip(GuiGraphics g, String id, String label, int x, int y, int w, boolean active, Runnable r) {
        boolean hov = over(x, y, w, 18, true);
        float t = anim("chip" + id, active ? 1f : (hov ? 0.5f : 0f));
        Ui.rect(g, x, y, w, 18, 5, col(Ui.mix(Ui.CARD_HOVER, Ui.accent(), t * 0.35f), 0.95f));
        Ui.ring(g, x, y, w, 18, 5, col(Ui.mix(Ui.BORDER, Ui.accent(), t), 0.95f));
        Ui.textC(g, label, x + w / 2, y + 5, col(Ui.TEXT, 1f));
        hit(x, y, w, 18, true, r);
    }

    private int buttonRow(GuiGraphics g, String id, String label, int y, Runnable r) {
        boolean hov = over(bx, y, bw, 24, true);
        float t = anim("br" + id, hov ? 1f : 0f);
        Ui.rect(g, bx, y, bw, 24, 6, col(Ui.mix(Ui.CARD, Ui.CARD_HOVER, t), 0.92f));
        Ui.ring(g, bx, y, bw, 24, 6, col(Ui.mix(Ui.BORDER, Ui.accent(), t), 0.95f));
        Ui.textC(g, label, bx + bw / 2, y + 8, col(Ui.TEXT, 1f));
        hit(bx, y, bw, 24, true, r);
        return y + 30;
    }

    private int settingsView(GuiGraphics g, Module m, boolean showEnable, boolean showBind, int y) {
        if (showEnable && m.action == null) {
            rowBg(g, y, Lang.t("ui.enabled"));
            float on = anim("en" + m.name, m.enabled ? 1f : 0f);
            Ui.toggle(g, bx + bw - 30, y + 6, on, al * pa);
            hit(bx, y, bw, 24, true, () -> { m.enabled = !m.enabled; Config.save(); });
            y += 26;
        }
        if (showBind) {
            rowBg(g, y, Lang.t("ui.bind"));
            String label = listening == m ? Lang.t("ui.press_key") : Config.keyName(m.bind);
            chip(g, "bind" + m.name, label, bx + bw - 126, y + 3, 120, listening == m, () -> listening = m);
            y += 26;
        }
        for (Setting s : m.settings) y = settingRow(g, m, s, y);
        return y;
    }

    private boolean isBool(Setting s) {
        return s.options != null && s.options.length == 2 && s.options[0].equals("Off") && s.options[1].equals("On");
    }

    private int settingRow(GuiGraphics g, Module m, Setting s, int y) {
        rowBg(g, y, Lang.set(s));
        String id = m.name + s.name;
        if (s.isText) {
            EditBox b = textBoxes.get(s);
            int boxW = Math.min(170, bw / 2);
            int boxX = bx + bw - boxW - 12;
            Ui.rect(g, boxX - 5, y + 2, boxW + 10, 20, 5, col(0x101018, 0.95f));
            Ui.ring(g, boxX - 5, y + 2, boxW + 10, 20, 5, col(Ui.BORDER, 0.95f));
            if (b != null) {
                placeBox(b, boxX, y + 5, boxW);
                s.text = b.getValue();
                hit(boxX - 5, y + 2, boxW + 10, 20, true, () -> focusBox(b));
            }
        } else if (isBool(s)) {
            float on = anim("s" + id, s.i() == 1 ? 1f : 0f);
            Ui.toggle(g, bx + bw - 30, y + 6, on, al * pa);
            hit(bx, y, bw, 24, true, () -> { s.value = s.i() == 1 ? 0 : 1; Config.save(); });
        } else if (s.options != null) {
            chip(g, "s" + id, s.display(), bx + bw - 136, y + 3, 130, false, () -> {
                s.value = (s.i() + 1) % s.options.length; Config.save();
            });
        } else {
            int tw = Math.max(60, Math.min(130, bw / 2 - 30));
            int tx = bx + bw - tw - 52;
            int ty = y + 11;
            double frac = (s.value - s.min) / (s.max - s.min);
            int kx = tx + (int) (tw * frac);
            Ui.rect(g, tx, ty, tw, 3, 1, col(Ui.BORDER, 1f));
            Ui.rect(g, tx, ty, Math.max(1, kx - tx), 3, 1, col(Ui.accent(), 1f));
            Ui.rect(g, kx - 3, ty - 3, 7, 9, 3, col(0xF2F2F8, 1f));
            Ui.textR(g, s.display(), bx + bw - 8, y + 8, col(Ui.MUTED, 1f));
            hitDrag(tx - 5, y, tw + 10, 24, true, mxv -> {
                double f = Mth.clamp((mxv - tx) / (double) tw, 0.0, 1.0);
                double v = s.min + f * (s.max - s.min);
                v = Math.round(v / s.step) * s.step;
                s.value = Mth.clamp(v, s.min, s.max);
            });
        }
        return y + 26;
    }

    private void placeBox(EditBox b, int x, int y, int w) {
        b.setX(x);
        b.setY(y);
        b.setWidth(w);
        b.visible = y >= by - 2 && y + 14 <= by + bh + 2;
    }

    // ---- configs

    private int configsView(GuiGraphics g, int y) {
        int btnW = 86, inW = bw - btnW - 20;

        inputBg(g, bx, y, bw - btnW - 6);
        placeBox(cfgName, bx + 6, y + 5, inW);
        hit(bx, y, bw - btnW - 6, 22, true, () -> focusBox(cfgName));
        String saveLabel = pending("save") ? Lang.t("cfg.overwrite") : Lang.t("cfg.save");
        smallButton(g, "cfgsave", saveLabel, bx + bw - btnW, y, btnW, pending("save"), this::doSave);
        y += 28;

        inputBg(g, bx, y, bw - btnW - 6);
        placeBox(cfgCode, bx + 6, y + 5, inW);
        hit(bx, y, bw - btnW - 6, 22, true, () -> focusBox(cfgCode));
        smallButton(g, "cfgfind", Lang.t("cfg.find"), bx + bw - btnW, y, btnW, false, this::doImport);
        y += 28;

        y = buttonRow(g, "cfgcopy", Lang.t("cfg.copy"), y, this::doCopy);

        if (cfgList.isEmpty()) {
            Ui.textC(g, Lang.t("cfg.empty"), bx + bw / 2, y + 14, col(Ui.TEXT, 1f));
            Ui.textC(g, Lang.t("cfg.empty_hint"), bx + bw / 2, y + 28, col(Ui.MUTED, 1f));
            return y + 46;
        }
        for (String name : new ArrayList<>(cfgList)) {
            Ui.rect(g, bx, y, bw, 24, 6, col(Ui.CARD, 0.88f));
            Ui.ring(g, bx, y, bw, 24, 6, col(Ui.BORDER, 0.7f));
            Ui.text(g, name, bx + 10, y + 8, col(Ui.TEXT, 1f));
            int dw = 64, lw = 56;
            boolean pend = pending("del:" + name);
            smallButton(g, "del" + name, pend ? Lang.t("cfg.sure") : Lang.t("cfg.delete"), bx + bw - dw - 4, y + 3, dw, pend, () -> doDelete(name));
            smallButton(g, "load" + name, Lang.t("cfg.load"), bx + bw - dw - lw - 8, y + 3, lw, false, () -> doLoad(name));
            y += 28;
        }
        return y;
    }

    private void inputBg(GuiGraphics g, int x, int y, int w) {
        Ui.rect(g, x, y, w, 22, 6, col(0x101018, 0.95f));
        Ui.ring(g, x, y, w, 22, 6, col(Ui.BORDER, 0.95f));
    }

    private void smallButton(GuiGraphics g, String id, String label, int x, int y, int w, boolean warn, Runnable r) {
        int h = 20;
        boolean hov = over(x, y, w, h, true);
        float t = anim("sb" + id, hov ? 1f : 0f);
        int accent = warn ? Ui.DANGER : Ui.accent();
        Ui.rect(g, x, y, w, h, 5, col(Ui.mix(Ui.CARD_HOVER, accent, t * 0.4f + (warn ? 0.3f : 0f)), 0.95f));
        Ui.ring(g, x, y, w, h, 5, col(Ui.mix(Ui.BORDER, accent, t * 0.9f + (warn ? 0.7f : 0f)), 0.95f));
        Ui.textC(g, label, x + w / 2, y + 6, col(Ui.TEXT, 1f));
        hit(x, y, w, h, true, r);
    }

    private void doSave() {
        String n = ConfigStore.clean(cfgName == null ? "" : cfgName.getValue());
        if (n.isEmpty()) { setStatus(Lang.t("cfg.bad_name"), true); return; }
        if (ConfigStore.exists(n) && !confirmed("save")) return;
        confirm = null;
        try {
            ConfigStore.save(n);
            cfgList = ConfigStore.list();
            setStatus(String.format(Lang.t("cfg.saved"), n), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doLoad(String name) {
        try {
            ConfigStore.load(name);
            Config.save();
            setStatus(String.format(Lang.t("cfg.loaded"), name), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doDelete(String name) {
        if (!confirmed("del:" + name)) return;
        try {
            ConfigStore.delete(name);
            cfgList = ConfigStore.list();
            setStatus(String.format(Lang.t("cfg.deleted"), name), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doCopy() {
        try {
            Minecraft.getInstance().keyboardHandler.setClipboard(ConfigStore.export());
            setStatus(Lang.t("cfg.copied"), false);
        } catch (Exception e) { setStatus(String.format(Lang.t("cfg.error"), e.getMessage()), true); }
    }

    private void doImport() {
        String code = cfgCode == null ? "" : cfgCode.getValue().trim();
        if (code.isEmpty()) code = Minecraft.getInstance().keyboardHandler.getClipboard().trim();
        if (code.isEmpty()) { setStatus(Lang.t("cfg.bad_code"), true); return; }
        try {
            ConfigStore.importCode(code);
            Config.save();
            setStatus(Lang.t("cfg.imported"), false);
        } catch (Exception e) { setStatus(Lang.t("cfg.bad_code"), true); }
    }

    // ---- friends

    private void addFriend(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase(java.util.Locale.ROOT);
        if (n.isEmpty()) return;
        Config.FRIENDS.add(n);
        Config.save();
        if (friendBox != null) friendBox.setValue("");
    }

    private int friendsView(GuiGraphics g, int y) {
        int btnW = 86, inW = bw - btnW - 20;
        inputBg(g, bx, y, bw - btnW - 6);
        placeBox(friendBox, bx + 6, y + 5, inW);
        hit(bx, y, bw - btnW - 6, 22, true, () -> focusBox(friendBox));
        smallButton(g, "frAdd", Lang.t("ui.add"), bx + bw - btnW, y, btnW, false, () -> addFriend(friendBox.getValue()));
        y += 28;

        y = buttonRow(g, "frLook", Lang.t("ui.add_looked"), y, () -> {
            HitResult hr = Minecraft.getInstance().hitResult;
            if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof Player pl) addFriend(pl.getName().getString());
        });

        if (Config.FRIENDS.isEmpty()) {
            Ui.textC(g, Lang.t("fr.empty"), bx + bw / 2, y + 12, col(Ui.MUTED, 1f));
            return y + 30;
        }
        for (String name : new ArrayList<>(Config.FRIENDS)) {
            Ui.rect(g, bx, y, bw, 24, 6, col(Ui.CARD, 0.88f));
            Ui.ring(g, bx, y, bw, 24, 6, col(Ui.BORDER, 0.7f));
            Ui.text(g, name, bx + 10, y + 8, col(Ui.TEXT, 1f));
            smallButton(g, "frDel" + name, Lang.t("fr.remove"), bx + bw - 84, y + 3, 80, false, () -> {
                Config.FRIENDS.remove(name);
                Config.save();
            });
            y += 28;
        }
        return y;
    }
}

package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Drawing helpers and the theme palette shared by all Ghostline screens and the HUD. */
public final class Ui {
    private Ui() { }

    public static final Identifier LOGO = Identifier.fromNamespaceAndPath("ghostline", "textures/gui/logo.png");
    public static final Identifier LOGO_BG = Identifier.fromNamespaceAndPath("ghostline", "textures/gui/logo_bg.png");

    public static final int TEXT = 0xE9E9F2, MUTED = 0x8B8B9C, DANGER = 0xD9707C;

    // ------------------------------------------------------------------ themes

    public static final class Preset {
        public final int accent, bg, side, card, hover, border;
        Preset(int accent, int bg, int side, int card, int hover, int border) {
            this.accent = accent; this.bg = bg; this.side = side; this.card = card; this.hover = hover; this.border = border;
        }
    }

    public static final String[] PRESET_NAMES = {
        "Ghost", "Graphite", "Obsidian", "Midnight", "Tokyo Night", "Rose Pine",
        "Blue neon", "Crimson", "Emerald", "Sunset", "Violet", "Arctic", "Cyberpunk", "Ocean", "Ice", "Custom"};

    private static final Preset[] PRESETS = {
        new Preset(0x7B6CD9, 0x0B0B11, 0x0E0E15, 0x16161F, 0x20202C, 0x2B2B39), // Ghost
        new Preset(0xB4B8C5, 0x101114, 0x131418, 0x1B1D22, 0x252830, 0x30343C), // Graphite
        new Preset(0x9AA0AE, 0x050506, 0x08080A, 0x0F1013, 0x17181C, 0x22242A), // Obsidian
        new Preset(0x8F7BFF, 0x0A0814, 0x0D0B1A, 0x15122A, 0x1E1A38, 0x2A2548), // Midnight
        new Preset(0x7AA2F7, 0x0F111A, 0x12141F, 0x1A1D2B, 0x232738, 0x2F3450), // Tokyo Night
        new Preset(0xEBBCBA, 0x12101A, 0x15121D, 0x1F1B2A, 0x2A2536, 0x3A3347), // Rose Pine
        new Preset(0x3B82F6, 0x070B18, 0x0A1020, 0x101A33, 0x16254A, 0x1F3366), // Blue neon
        new Preset(0xEF4444, 0x140708, 0x190A0B, 0x241012, 0x321618, 0x4A1F22), // Crimson
        new Preset(0x22C55E, 0x06120B, 0x08170E, 0x0E2417, 0x143222, 0x1D4A31), // Emerald
        new Preset(0xF59E0B, 0x140C06, 0x190F08, 0x24160D, 0x331F12, 0x4D3018), // Sunset
        new Preset(0xA855F7, 0x0E0716, 0x120A1C, 0x1D1030, 0x2A1845, 0x3F2566), // Violet
        new Preset(0x5BB5D6, 0x070F14, 0x0A141B, 0x10202B, 0x172E3D, 0x224257), // Arctic
        new Preset(0xEC4899, 0x120614, 0x17081A, 0x230D28, 0x33143A, 0x4D1F57), // Cyberpunk
        new Preset(0x06B6D4, 0x050F18, 0x08141F, 0x0E2233, 0x153149, 0x1F4866), // Ocean
        new Preset(0x93C5FD, 0x0A1018, 0x0D141D, 0x151F2C, 0x1E2B3D, 0x2B3C52), // Ice
        null // Custom: built from the R/G/B sliders
    };

    public static Preset presetAt(int idx) {
        idx = Mth.clamp(idx, 0, PRESETS.length - 1);
        if (PRESETS[idx] != null) return PRESETS[idx];
        int a = (Config.THEME.get(4).i() << 16) | (Config.THEME.get(5).i() << 8) | Config.THEME.get(6).i();
        return new Preset(a, mix(0x07070A, a, 0.06f), mix(0x0A0A0E, a, 0.08f), mix(0x111116, a, 0.12f),
            mix(0x181820, a, 0.20f), mix(0x20202A, a, 0.30f));
    }

    public static Preset preset() { return presetAt(Config.THEME.get(0).i()); }
    public static int accent() { return preset().accent; }
    public static int bg() { return preset().bg; }
    public static int side() { return preset().side; }
    public static int card() { return preset().card; }
    public static int hover() { return preset().hover; }
    public static int border() { return preset().border; }

    public static float panelOpacity() { return Config.THEME.get(1).f(); }
    public static boolean bgLogo() { return Config.THEME.get(2).i() == 1; }
    public static boolean anim() { return Config.THEME.get(3).i() == 1; }

    // ------------------------------------------------------------------ colors

    public static int c(int rgb, float a) {
        int al = Mth.clamp((int) (a * 255f), 4, 255);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (r << 16) | (g << 8) | b;
    }

    // ------------------------------------------------------------------ text

    public static Font font() { return Minecraft.getInstance().font; }
    public static int tw(String s) { return font().width(s); }

    public static void text(GuiGraphics g, String s, int x, int y, int color) { g.drawString(font(), s, x, y, color, false); }
    public static void textR(GuiGraphics g, String s, int xRight, int y, int color) { text(g, s, xRight - tw(s), y, color); }
    public static void textC(GuiGraphics g, String s, int cx, int y, int color) { text(g, s, cx - tw(s) / 2, y, color); }

    public static List<String> wrap(String s, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (tw(test) > width && line.length() > 0) { out.add(line.toString()); line = new StringBuilder(word); }
            else { line = new StringBuilder(test); }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    // ------------------------------------------------------------------ shapes

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - d * d));
            g.fill(x + dx, y + i, x + w - dx, y + i + 1, color);
            g.fill(x + dx, y + h - 1 - i, x + w - dx, y + h - i, color);
        }
    }

    public static void ring(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        g.fill(x + r, y, x + w - r, y + 1, color);
        g.fill(x + r, y + h - 1, x + w - r, y + h, color);
        g.fill(x, y + r, x + 1, y + h - r, color);
        g.fill(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - d * d));
            g.fill(x + dx, y + i, x + dx + 1, y + i + 1, color);
            g.fill(x + w - dx - 1, y + i, x + w - dx, y + i + 1, color);
            g.fill(x + dx, y + h - 1 - i, x + dx + 1, y + h - i, color);
            g.fill(x + w - dx - 1, y + h - 1 - i, x + w - dx, y + h - i, color);
        }
    }

    /** Toggle switch, 22x11. t = 0..1 animation state. */
    public static void toggle(GuiGraphics g, int x, int y, float t, float alpha) {
        int bg = mix(0x2A2A37, accent(), t);
        rect(g, x, y, 22, 11, 5, c(bg, alpha));
        int kx = x + 1 + (int) (t * 11);
        rect(g, kx, y + 1, 9, 9, 4, c(0xF2F2F8, alpha));
    }

    public static void logo(GuiGraphics g, Identifier id, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, size, size, 256, 256, 256, 256);
    }

    public static void stars(GuiGraphics g, int w, int h, float alpha) {
        Random r = new Random(7);
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < 34; i++) {
            int x = r.nextInt(Math.max(1, w)), y = r.nextInt(Math.max(1, h));
            float tw = (float) (0.18 + 0.22 * Math.sin(t * (0.8 + (i % 5) * 0.3) + i));
            int s = (i % 7 == 0) ? 2 : 1;
            g.fill(x, y, x + s, y + s, c(0xC8C4F0, Math.max(0.04f, tw) * alpha));
        }
    }

    /** Dark gradient background tinted by the current theme; alpha 0..255. */
    public static void backdrop(GuiGraphics g, int w, int h, int alpha) {
        int a = (alpha & 0xFF) << 24;
        int top = mix(bg(), 0x000000, 0.35f);
        int bottom = mix(bg(), accent(), 0.13f);
        g.fillGradient(0, 0, w, h, a | top, a | bottom);
        stars(g, w, h, alpha / 255f);
    }
}

package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

public class Config {
    public static final int VERSION = 3;

    public static final String[] SWAP_ITEMS = {"Any", "Totem", "Enchanted totem", "Head", "Shield", "Gapple", "Pearl", "Firework", "Crystal"};
    private static final String[] POS = {"Top right", "Top left", "Bottom right", "Bottom left"};

    // categories: 0 Combat, 1 Movement, 2 Player, 3 Visuals, 4 Misc, 8 Cosmetics (pages 5-7 are Theme/HUD/Configs)

    // ---- Combat ----
    public static final Module AIM = new Module("AimAssist", 0)
        .add(new Setting("Speed", 0.4, 0.1, 1.0, 0.05).fmt("%.0f%%", 100))
        .add(new Setting("FOV", 70, 20, 180, 5).fmt("%.0f°", 1))
        .add(new Setting("Distance", 4.5, 1.0, 6.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Vertical", 1.0, 0.0, 1.0, 0.05).fmt("%.0f%%", 100))
        .add(Setting.bool("Weapon only", false))
        .add(new Setting("Priority", 0, "Angle", "Distance"))
        .add(Setting.bool("Only on click", false))
        .add(Setting.bool("Players", true))
        .add(Setting.bool("Mobs", true))
        .add(Setting.bool("Through walls", false))
        .add(Setting.bool("Invisible", true))
        .add(Setting.bool("Naked", true))
        .add(Setting.bool("In armor", true));
    public static final Module AUTOMACE = new Module("AutoMace", 0)
        .add(new Setting("Distance", 3.0, 1.0, 6.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Min fall height", 1.5, 0.0, 10.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Max fall height", 40, 5, 100, 5).fmt("%.0f m", 1))
        .add(Setting.bool("While falling", true))
        .add(Setting.bool("After charge", true))
        .add(Setting.bool("Swap to mace", true))
        .add(Setting.bool("Return slot", true))
        .add(Setting.bool("Players", true))
        .add(Setting.bool("Mobs", true));
    public static final Module AUTOSWAP = new Module("AutoSwap", 0)
        .add(new Setting("From", 3, SWAP_ITEMS))
        .add(new Setting("To", 1, SWAP_ITEMS))
        .add(new Setting("From name", ""))
        .add(new Setting("To name", ""))
        .add(new Setting("Hand", 0, "Offhand", "Mainhand"))
        .add(Setting.key("Swap key"))
        .add(Setting.bool("Wheel button", false));
    public static final Module TOTEM = new Module("AutoTotem", 0)
        .add(new Setting("Health threshold", 20, 1, 20, 1).fmt("%.0f HP", 1))
        .add(new Setting("Delay", 2, 0, 10, 1).fmt("%.0f t", 1))
        .add(Setting.bool("Not while eating", false));
    public static final Module PEARL = new Module("KeyPearl", 0).on()
        .add(Setting.bool("Switch back", true));
    public static final Module WIND = new Module("KeyWind", 0).on()
        .add(Setting.bool("Switch back", true))
        .add(Setting.bool("Look down", true));
    public static final Module NOFRIEND = new Module("NoFriendDamage", 0);
    public static final Module TRIGGER = new Module("TriggerBot", 0)
        .add(new Setting("Distance", 3.0, 1.0, 6.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Charge", 0.95, 0.5, 1.0, 0.01).fmt("%.0f%%", 100))
        .add(new Setting("Delay", 0, 0, 10, 1).fmt("%.0f t", 1))
        .add(Setting.bool("Crits only", false))
        .add(Setting.bool("Players", true))
        .add(Setting.bool("Mobs", true));

    // ---- Movement ----
    public static final Module SPRINT = new Module("AutoSprint", 1);
    public static final Module FLY = new Module("Fly", 1)
        .add(new Setting("Fly speed", 1.0, 0.5, 5.0, 0.1).fmt("%.1fx", 1));
    public static final Module GUIMOVE = new Module("GuiMove", 1)
        .add(Setting.bool("Jump", true))
        .add(Setting.bool("In Ghostline menu", true));
    public static final Module SPEED = new Module("Speed", 1)
        .add(new Setting("Multiplier", 1.15, 1.0, 2.0, 0.01).fmt("%.2fx", 1));

    // ---- Player ----
    public static final Module AUTOTOOL = new Module("AutoTool", 2)
        .add(Setting.bool("Switch back", true));
    public static final Module CHEST = new Module("ChestStealer", 2)
        .add(new Setting("Delay", 1, 0, 10, 1).fmt("%.0f t", 1))
        .add(Setting.bool("Auto close", true));
    public static final Module FRIENDS = new Module("Friends", 2).on()
        .add(new Setting("Click range", 8, 3, 20, 1).fmt("%.0f m", 1));

    // ---- Visuals ----
    public static final Module BRIGHT = new Module("Fullbright", 3);
    public static final Module VIEW = new Module("ViewModel", 3)
        .add(new Setting("X", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Y", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Z", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Scale", 1.0, 0.3, 2.0, 0.05));

    // ---- Misc ----
    public static final Module PANIC = new Module("Panic", 4).notToggle();

    // ---- Cosmetics ----
    public static final Module TRAIL = new Module("Trail", 8)
        .add(new Setting("Style", 0, "End rod", "Soul fire", "Heart", "Note", "Enchant", "Cloud"))
        .add(new Setting("Density", 2, 1, 5, 1).fmt("%.0f", 1))
        .add(Setting.bool("First person", false));

    public static final List<Module> ALL = List.of(
        AIM, AUTOMACE, AUTOSWAP, TOTEM, PEARL, WIND, NOFRIEND, TRIGGER,
        SPRINT, FLY, GUIMOVE, SPEED,
        AUTOTOOL, CHEST, FRIENDS,
        BRIGHT, VIEW,
        PANIC,
        TRAIL);

    // ---- Settings-only groups ----
    public static final Module THEME = new Module("Theme", 5)
        .add(new Setting("Preset", 0, Ui.PRESET_NAMES))
        .add(new Setting("Panel opacity", 0.92, 0.5, 1.0, 0.02).fmt("%.0f%%", 100))
        .add(Setting.bool("Background logo", true))
        .add(Setting.bool("Animations", true))
        .add(new Setting("Custom R", 123, 0, 255, 1).fmt("%.0f", 1))
        .add(new Setting("Custom G", 108, 0, 255, 1).fmt("%.0f", 1))
        .add(new Setting("Custom B", 217, 0, 255, 1).fmt("%.0f", 1));
    public static final Module HUD = new Module("HUD", 6).on()
        .add(Setting.bool("Module list", true))
        .add(Setting.bool("Watermark", true))
        .add(Setting.bool("Coordinates", false))
        .add(Setting.bool("Binds", false))
        .add(Setting.bool("Target", false))
        .add(Setting.bool("Armor", false))
        .add(Setting.bool("Potions", false))
        .add(new Setting("List position", 0, POS))
        .add(new Setting("Watermark position", 1, POS))
        .add(new Setting("Coords position", 3, POS))
        .add(new Setting("Extras position", 2, POS))
        .add(new Setting("Sort", 0, "Length", "A-Z"))
        .add(new Setting("Color", 0, "Accent", "White", "Rainbow"))
        .add(new Setting("Scale", 1.0, 0.7, 1.6, 0.05).fmt("%.2fx", 1))
        .add(new Setting("Opacity", 1.0, 0.3, 1.0, 0.05).fmt("%.0f%%", 100));
    public static final List<Module> EXTRA = List.of(THEME, HUD);

    public static int menuBind = org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT;
    public static int lang = 0;               // 0 = English, 1 = Russian
    public static boolean langChosen = false;
    public static boolean panic = false;      // never saved: lasts until game restart
    public static final Set<String> FRIENDS_SET = new LinkedHashSet<>();

    public static boolean isFriend(Entity e) {
        return e instanceof Player && FRIENDS_SET.contains(e.getName().getString().toLowerCase(Locale.ROOT));
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ghostline.properties");
    }

    private static void put(Properties p, Module m) {
        for (Setting s : m.settings) p.setProperty(m.name + "." + s.name, s.isText ? s.text : String.valueOf(s.value));
    }

    /** Current state as properties. global=true also stores menu key, language, friends and version. */
    public static Properties snapshot(boolean global) {
        Properties p = new Properties();
        if (global) {
            p.setProperty("cfg.version", String.valueOf(VERSION));
            p.setProperty("menu.bind", String.valueOf(menuBind));
            p.setProperty("lang", String.valueOf(lang));
            p.setProperty("lang.chosen", String.valueOf(langChosen));
            p.setProperty("friends", String.join(",", FRIENDS_SET));
        }
        for (Module m : ALL) {
            p.setProperty(m.name + ".on", String.valueOf(m.enabled));
            p.setProperty(m.name + ".bind", String.valueOf(m.bind));
            put(p, m);
        }
        for (Module m : EXTRA) {
            p.setProperty(m.name + ".on", String.valueOf(m.enabled));
            put(p, m);
        }
        return p;
    }

    private static void applySettings(Module m, Properties p) {
        for (Setting s : m.settings) {
            String v = p.getProperty(m.name + "." + s.name);
            if (v == null) continue;
            if (s.isText) s.text = v;
            else s.value = Math.max(s.min, Math.min(s.max, Double.parseDouble(v)));
        }
    }

    /** Applies properties; missing keys keep their current values. */
    public static void apply(Properties p, boolean global) {
        if (global) {
            if (p.containsKey("menu.bind")) menuBind = Integer.parseInt(p.getProperty("menu.bind"));
            if (p.containsKey("lang")) lang = Integer.parseInt(p.getProperty("lang"));
            if (p.containsKey("lang.chosen")) langChosen = Boolean.parseBoolean(p.getProperty("lang.chosen"));
            if (p.containsKey("friends")) {
                FRIENDS_SET.clear();
                for (String f : p.getProperty("friends", "").split(",")) if (!f.isBlank()) FRIENDS_SET.add(f.trim());
            }
        }
        for (Module m : ALL) {
            if (m.toggleable && p.containsKey(m.name + ".on")) m.enabled = Boolean.parseBoolean(p.getProperty(m.name + ".on"));
            if (p.containsKey(m.name + ".bind")) m.bind = Integer.parseInt(p.getProperty(m.name + ".bind"));
            applySettings(m, p);
        }
        for (Module m : EXTRA) {
            if (p.containsKey(m.name + ".on")) m.enabled = Boolean.parseBoolean(p.getProperty(m.name + ".on"));
            applySettings(m, p);
        }
        if (global) {
            // one-time reset of all binds left over from older versions
            int v = 0;
            try { v = Integer.parseInt(p.getProperty("cfg.version", "0")); } catch (NumberFormatException ignored) { }
            if (v < VERSION) clearBinds();
        }
    }

    public static void clearBinds() {
        for (Module m : ALL) {
            m.bind = -1;
            for (Setting s : m.settings) if (s.isKey) s.value = -1;
        }
    }

    public static void save() {
        if (panic) return;
        try (OutputStream o = Files.newOutputStream(file())) {
            snapshot(true).store(o, "Ghostline");
        } catch (Exception ignored) { }
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream i = Files.newInputStream(file())) { p.load(i); }
            apply(p, true);
            save();
        } catch (Exception ignored) { }
    }

    public static String keyName(int k) {
        if (k < 0) return Lang.t("ui.none");
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) return "RShift";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT) return "LShift";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCtrl";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_CONTROL) return "LCtrl";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_ALT) return "RAlt";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_ALT) return "LAlt";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_SPACE) return "Space";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_TAB) return "Tab";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER) return "Enter";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_INSERT) return "Insert";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_HOME) return "Home";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_END) return "End";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_PAGE_UP) return "PgUp";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_PAGE_DOWN) return "PgDn";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_UP) return "Up";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN) return "Down";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT) return "Left";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT) return "Right";
        if (k >= org.lwjgl.glfw.GLFW.GLFW_KEY_F1 && k <= org.lwjgl.glfw.GLFW.GLFW_KEY_F12) return "F" + (k - org.lwjgl.glfw.GLFW.GLFW_KEY_F1 + 1);
        String n = org.lwjgl.glfw.GLFW.glfwGetKeyName(k, 0);
        if (n != null) return n.toUpperCase();
        return "Key" + k;
    }
}

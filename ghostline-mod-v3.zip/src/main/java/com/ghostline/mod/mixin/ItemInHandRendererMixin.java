package com.ghostline.mod.mixin;

import com.ghostline.mod.Config;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), require = 0)
    private void ghostline$begin(AbstractClientPlayer player, float partialTick, float pitch, InteractionHand hand,
                                 float swingProgress, ItemStack stack, float equippedProgress, PoseStack poseStack,
                                 SubmitNodeCollector collector, int light, CallbackInfo ci) {
        if (Config.panic || !Config.VIEW.enabled) return;
        float side = hand == InteractionHand.MAIN_HAND ? 1f : -1f;
        poseStack.pushPose();
        poseStack.translate(Config.VIEW.get(0).f() * side, Config.VIEW.get(1).f(), Config.VIEW.get(2).f());
        float s = Config.VIEW.get(3).f();
        poseStack.scale(s, s, s);
    }

    @Inject(method = "renderArmWithItem", at = @At("RETURN"), require = 0)
    private void ghostline$end(AbstractClientPlayer player, float partialTick, float pitch, InteractionHand hand,
                               float swingProgress, ItemStack stack, float equippedProgress, PoseStack poseStack,
                               SubmitNodeCollector collector, int light, CallbackInfo ci) {
        if (Config.panic || !Config.VIEW.enabled) return;
        poseStack.popPose();
    }
}

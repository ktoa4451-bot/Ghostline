package com.ghostline.mod.mixin;

import com.ghostline.mod.Config;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public class MultiPlayerGameModeMixin {

    /** NoFriendDamage: never send an attack on a friend. */
    @Inject(method = "attack", at = @At("HEAD"), cancellable = true, require = 0)
    private void ghostline$noFriendDamage(Player player, Entity target, CallbackInfo ci) {
        if (!Config.panic && Config.NOFRIEND.enabled && Config.isFriend(target)) ci.cancel();
    }
}

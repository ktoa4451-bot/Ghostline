package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;

/** First-launch language choice. */
public class LanguageScreen extends GhostScreen {
    public LanguageScreen() { super("Language"); }

    private void choose(int lang) {
        Config.lang = lang;
        Config.langChosen = true;
        Config.save();
        this.minecraft.setScreen(new GhostTitleScreen());
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        beginFrame(mouseX, mouseY);
        Ui.backdrop(g, this.width, this.height, 255);
        int size = Math.min(96, this.height / 3);
        Ui.logo(g, Ui.LOGO, this.width / 2 - size / 2, this.height / 2 - size - 30, size);
        Ui.textC(g, Lang.t("ui.choose_lang"), this.width / 2, this.height / 2 - 24, Ui.c(Ui.TEXT, 1f));
        int w = 170, x = this.width / 2 - w / 2, y = this.height / 2 - 8;
        button(g, "l_en", x, y, w, 24, "English", () -> choose(0));
        button(g, "l_ru", x, y + 32, w, 24, "Русский", () -> choose(1));
    }
}

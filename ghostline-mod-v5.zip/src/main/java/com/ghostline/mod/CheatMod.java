package com.ghostline.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class CheatMod implements ClientModInitializer {
    private static final ParticleOptions[] TRAIL_TYPES = {
        ParticleTypes.END_ROD, ParticleTypes.SOUL_FIRE_FLAME, ParticleTypes.HEART,
        ParticleTypes.NOTE, ParticleTypes.ENCHANT, ParticleTypes.CLOUD};

    private static final ParticleOptions[] WING_TYPES = {
        ParticleTypes.END_ROD, ParticleTypes.FLAME, ParticleTypes.ENCHANT, ParticleTypes.SNOWFLAKE};

    private static boolean wasFly, menuPrev, splashShown, mmbPrev, attacked;
    private static int restoreSlot = -1, restoreTicks, totemTimer, trigTimer, stealTimer, toolPrev = -1;

    @Override
    public void onInitializeClient() {
        Config.load();

        Config.PEARL.action = mc -> useItem(mc, Items.ENDER_PEARL, Config.PEARL.get(0).i() == 1, false);
        Config.WIND.action = mc -> useItem(mc, Items.WIND_CHARGE, Config.WIND.get(0).i() == 1, Config.WIND.get(1).i() == 1);
        Config.PANIC.action = CheatMod::panic;

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (Config.panic) return;

            // splash + custom main menu replace the vanilla title screen
            if (mc.screen instanceof TitleScreen) {
                if (!splashShown) { splashShown = true; mc.setScreen(new SplashScreen()); }
                else mc.setScreen(new GhostTitleScreen());
            }

            long win = GLFW.glfwGetCurrentContext();
            if (win != 0) {
                boolean md = Config.menuBind > 0 && GLFW.glfwGetKey(win, Config.menuBind) == GLFW.GLFW_PRESS;
                if (md && !menuPrev && mc.screen == null && mc.player != null) mc.setScreen(new GhostGui());
                menuPrev = md;

                for (Module m : Config.ALL) {
                    boolean down = m.bind > 0 && GLFW.glfwGetKey(win, m.bind) == GLFW.GLFW_PRESS;
                    if (down && !m.prevDown && mc.screen == null && mc.player != null) {
                        if (m.action != null) { if (!m.toggleable || m.enabled) m.action.accept(mc); }
                        else { m.enabled = !m.enabled; Config.save(); }
                    }
                    m.prevDown = down;
                    if (Config.panic) return;
                }

                // AutoSwap key
                Setting swapKey = Config.AUTOSWAP.get(5);
                boolean sd = Config.AUTOSWAP.enabled && swapKey.i() > 0 && GLFW.glfwGetKey(win, swapKey.i()) == GLFW.GLFW_PRESS;
                if (sd && !swapKey.prev && mc.screen == null && mc.player != null) autoSwap(mc);
                swapKey.prev = sd;

                // middle mouse: friends + AutoSwap wheel button
                boolean mmb = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
                if (mmb && !mmbPrev && mc.screen == null && mc.player != null) {
                    if (Config.AUTOSWAP.enabled && Config.AUTOSWAP.get(6).i() == 1) autoSwap(mc);
                    if (Config.FRIENDS.enabled) friendClick(mc);
                }
                mmbPrev = mmb;
            }

            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return;
            tick(mc, p);
        });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("ghostline", "hud"), Hud::render);
    }

    /** Turns everything off and locks the client until the game is restarted. */
    public static void panic(Minecraft mc) {
        AutoWarden.stop(mc);
        for (Module m : Config.ALL) m.enabled = false;
        Config.HUD.enabled = false;
        Config.panic = true;
        LocalPlayer p = mc.player;
        if (p != null) {
            p.getAbilities().setFlyingSpeed(0.05f);
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
            }
            MobEffectInstance e = p.getEffect(MobEffects.NIGHT_VISION);
            if (e != null && !e.isVisible()) p.removeEffect(MobEffects.NIGHT_VISION);
        }
        if (mc.screen != null && mc.screen.getClass().getName().startsWith("com.ghostline")) {
            if (mc.level != null) mc.setScreen(null);
            else mc.setScreen(new TitleScreen());
        }
    }

    // ------------------------------------------------------------------ helpers

    static boolean basicTarget(LivingEntity e, LocalPlayer p, boolean players, boolean mobs) {
        if (e == p || !e.isAlive() || e instanceof ArmorStand) return false;
        if (Config.NOFRIEND.enabled && Config.isFriend(e)) return false;
        return (e instanceof Player) ? players : mobs;
    }

    private static boolean hasArmor(LivingEntity e) {
        return !e.getItemBySlot(EquipmentSlot.HEAD).isEmpty() || !e.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
            || !e.getItemBySlot(EquipmentSlot.LEGS).isEmpty() || !e.getItemBySlot(EquipmentSlot.FEET).isEmpty();
    }

    private static boolean isWeapon(ItemStack s) {
        return s.is(ItemTags.SWORDS) || s.is(ItemTags.AXES) || s.is(Items.MACE) || s.is(Items.TRIDENT);
    }

    private static int hotbarSlot(LocalPlayer p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private static LivingEntity nearest(Minecraft mc, LocalPlayer p, double dist, boolean players, boolean mobs, boolean los) {
        LivingEntity best = null;
        double bd = dist * dist;
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(dist),
                x -> basicTarget(x, p, players, mobs))) {
            if (los && !p.hasLineOfSight(e)) continue;
            double d = p.distanceToSqr(e);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private static void attack(Minecraft mc, LocalPlayer p, LivingEntity target) {
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
        attacked = true;
    }

    private static boolean matches(ItemStack s, int kind, String name) {
        if (s.isEmpty()) return false;
        boolean typeOk = switch (kind) {
            case 0 -> true;
            case 1 -> s.is(Items.TOTEM_OF_UNDYING) && !s.hasFoil();
            case 2 -> s.is(Items.TOTEM_OF_UNDYING) && s.hasFoil();
            case 3 -> s.is(Items.PLAYER_HEAD);
            case 4 -> s.is(Items.SHIELD);
            case 5 -> s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE);
            case 6 -> s.is(Items.ENDER_PEARL);
            case 7 -> s.is(Items.FIREWORK_ROCKET);
            default -> s.is(Items.END_CRYSTAL);
        };
        if (!typeOk) return false;
        boolean hasName = name != null && !name.isBlank();
        if (kind == 0 && !hasName) return false; // "Any" needs a name filter
        if (!hasName) return true;
        return s.getHoverName().getString().toLowerCase(Locale.ROOT).contains(name.trim().toLowerCase(Locale.ROOT));
    }

    /** AutoSwap: if you hold the "To" item, swap back to "From"; otherwise swap to "To". */
    private static void autoSwap(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return;
        Module m = Config.AUTOSWAP;
        int from = m.get(0).i(), to = m.get(1).i();
        String fromName = m.get(2).text, toName = m.get(3).text;
        boolean offhand = m.get(4).i() == 0;
        ItemStack held = offhand ? p.getOffhandItem() : p.getMainHandItem();
        boolean holdingTo = matches(held, to, toName);
        int wantKind = holdingTo ? from : to;
        String wantName = holdingTo ? fromName : toName;
        if (offhand) {
            for (int i = 0; i < 36; i++) {
                if (matches(p.getInventory().getItem(i), wantKind, wantName)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                    return;
                }
            }
        } else {
            for (int i = 0; i < 9; i++) {
                if (matches(p.getInventory().getItem(i), wantKind, wantName)) {
                    if (p.getInventory().getSelectedSlot() != i) p.getInventory().setSelectedSlot(i);
                    return;
                }
            }
        }
    }

    /** KeyPearl / KeyWind: use the item from the hotbar (or offhand); optionally throw it straight down. */
    private static void useItem(Minecraft mc, Item item, boolean switchBack, boolean lookDown) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return;
        InteractionHand hand;
        int prev = p.getInventory().getSelectedSlot();
        int slot = prev;
        if (p.getOffhandItem().is(item)) {
            hand = InteractionHand.OFF_HAND;
        } else {
            slot = hotbarSlot(p, item);
            if (slot < 0) return;
            hand = InteractionHand.MAIN_HAND;
            if (slot != prev) p.getInventory().setSelectedSlot(slot);
        }
        float yRot = p.getYRot(), xRot = p.getXRot();
        if (lookDown) p.setXRot(90f);
        mc.gameMode.useItem(p, hand);
        if (lookDown) { p.setXRot(xRot); p.setYRot(yRot); }
        if (switchBack && hand == InteractionHand.MAIN_HAND && slot != prev) { restoreSlot = prev; restoreTicks = 2; }
    }

    /** Friends: middle click on the player you are looking at. */
    private static void friendClick(Minecraft mc) {
        LocalPlayer p = mc.player;
        double range = Config.FRIENDS.get(0).value;
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getViewVector(1.0f);
        Player best = null;
        double bestProj = Double.MAX_VALUE;
        for (Player o : mc.level.players()) {
            if (o == p) continue;
            Vec3 d = o.getBoundingBox().getCenter().subtract(eye);
            double proj = d.dot(look);
            if (proj <= 0.2 || proj > range) continue;
            Vec3 perp = d.subtract(look.scale(proj));
            if (perp.length() < 0.9 && proj < bestProj) { bestProj = proj; best = o; }
        }
        if (best == null) return;
        String name = best.getName().getString();
        String key = name.toLowerCase(Locale.ROOT);
        String msg;
        if (Config.FRIENDS_SET.contains(key)) { Config.FRIENDS_SET.remove(key); msg = Lang.t("ui.friend_removed"); }
        else { Config.FRIENDS_SET.add(key); msg = Lang.t("ui.friend_added"); }
        Config.save();
        p.displayClientMessage(Component.literal(String.format(msg, name)), true);
    }

    // ------------------------------------------------------------------ per-tick logic

    private static void tick(Minecraft mc, LocalPlayer p) {
        attacked = false;

        if (restoreTicks > 0 && --restoreTicks == 0 && restoreSlot >= 0) {
            p.getInventory().setSelectedSlot(restoreSlot);
            restoreSlot = -1;
        }

        // AutoWarden (Baritone driven)
        if (Config.AUTOWARDEN.enabled) AutoWarden.tick(mc, p);
        else AutoWarden.stop(mc);

        // Fly
        if (Config.FLY.enabled) {
            p.getAbilities().mayfly = true;
            p.getAbilities().flying = true;
            p.getAbilities().setFlyingSpeed(0.05f * Config.FLY.get(0).f());
            wasFly = true;
        } else if (wasFly) {
            p.getAbilities().setFlyingSpeed(0.05f);
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
            }
            wasFly = false;
        }

        // Speed
        if (Config.SPEED.enabled && (p.zza != 0 || p.xxa != 0)) {
            Vec3 v = p.getDeltaMovement();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            double k = Config.SPEED.get(0).value;
            if (h > 0.001 && h < 0.7) p.setDeltaMovement(v.x * k, v.y, v.z * k);
        }

        // Cosmetics: particle trail
        if (Config.TRAIL.enabled && (Config.TRAIL.get(2).i() == 1 || !mc.options.getCameraType().isFirstPerson())) {
            ParticleOptions type = TRAIL_TYPES[Math.max(0, Math.min(TRAIL_TYPES.length - 1, Config.TRAIL.get(0).i()))];
            int n = Config.TRAIL.get(1).i();
            for (int i = 0; i < n; i++) {
                mc.level.addParticle(type,
                    p.getX() + (p.getRandom().nextDouble() - 0.5) * 0.8,
                    p.getY() + p.getRandom().nextDouble() * 1.8,
                    p.getZ() + (p.getRandom().nextDouble() - 0.5) * 0.8,
                    0.0, 0.02, 0.0);
            }
        }

        // Cosmetics: particle wings
        if (Config.WINGS.enabled && (Config.WINGS.get(3).i() == 1 || !mc.options.getCameraType().isFirstPerson())) wings(mc, p);

        // Fullbright
        if (Config.BRIGHT.enabled) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        } else {
            MobEffectInstance e = p.getEffect(MobEffects.NIGHT_VISION);
            if (e != null && e.getDuration() <= 400 && !e.isVisible()) p.removeEffect(MobEffects.NIGHT_VISION);
        }

        // AutoSprint
        if (Config.SPRINT.enabled && p.zza > 0 && !p.isShiftKeyDown()) p.setSprinting(true);

        // GuiMove: keep walking while an inventory (or the Ghostline menu) is open
        if (Config.GUIMOVE.enabled && mc.screen != null) {
            boolean ok = mc.screen instanceof AbstractContainerScreen<?>
                || (mc.screen instanceof GhostGui gg && Config.GUIMOVE.get(1).i() == 1 && !gg.isTyping());
            long win = GLFW.glfwGetCurrentContext();
            if (ok && win != 0) {
                mc.options.keyUp.setDown(GLFW.glfwGetKey(win, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS);
                mc.options.keyDown.setDown(GLFW.glfwGetKey(win, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS);
                mc.options.keyLeft.setDown(GLFW.glfwGetKey(win, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS);
                mc.options.keyRight.setDown(GLFW.glfwGetKey(win, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS);
                if (Config.GUIMOVE.get(0).i() == 1) mc.options.keyJump.setDown(GLFW.glfwGetKey(win, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS);
            }
        }

        // AutoTotem
        if (Config.TOTEM.enabled && mc.gameMode != null) {
            float thr = Config.TOTEM.get(0).f();
            int delay = Math.max(1, Config.TOTEM.get(1).i());
            boolean noEat = Config.TOTEM.get(2).i() == 1;
            boolean need = !p.getOffhandItem().is(Items.TOTEM_OF_UNDYING) && p.getHealth() <= thr && !(noEat && p.isUsingItem());
            if (need) {
                if (++totemTimer >= delay) {
                    totemTimer = 0;
                    for (int i = 0; i < 36; i++) {
                        if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                            int slot = i < 9 ? 36 + i : i;
                            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                            break;
                        }
                    }
                }
            } else totemTimer = 0;
        }

        // ChestStealer
        if (Config.CHEST.enabled && mc.gameMode != null && p.containerMenu != p.inventoryMenu && p.containerMenu instanceof ChestMenu cm) {
            if (++stealTimer > Config.CHEST.get(0).i()) {
                stealTimer = 0;
                int chestSlots = cm.getRowCount() * 9;
                boolean moved = false;
                for (int i = 0; i < chestSlots; i++) {
                    if (cm.getSlot(i).hasItem()) {
                        mc.gameMode.handleInventoryMouseClick(cm.containerId, i, 0, ClickType.QUICK_MOVE, p);
                        moved = true;
                        break;
                    }
                }
                if (!moved && Config.CHEST.get(1).i() == 1) p.closeContainer();
            }
        } else stealTimer = 0;

        boolean free = mc.screen == null && mc.gameMode != null;

        // AutoTool
        if (Config.AUTOTOOL.enabled && free) {
            boolean mining = mc.options.keyAttack.isDown();
            if (mining && mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
                BlockState st = mc.level.getBlockState(bhr.getBlockPos());
                int cur = p.getInventory().getSelectedSlot();
                int best = cur;
                float bs = p.getInventory().getItem(cur).getDestroySpeed(st);
                for (int i = 0; i < 9; i++) {
                    float sp = p.getInventory().getItem(i).getDestroySpeed(st);
                    if (sp > bs + 0.01f) { bs = sp; best = i; }
                }
                if (best != cur) {
                    if (toolPrev < 0) toolPrev = cur;
                    p.getInventory().setSelectedSlot(best);
                }
            } else if (!mining && toolPrev >= 0) {
                if (Config.AUTOTOOL.get(0).i() == 1) p.getInventory().setSelectedSlot(toolPrev);
                toolPrev = -1;
            }
        }

        // AutoMace: smash with the mace on anything close while you fall
        if (Config.AUTOMACE.enabled && free) {
            Module m = Config.AUTOMACE;
            double dist = m.get(0).value;
            float minFall = m.get(1).f(), maxFall = m.get(2).f();
            boolean whileFalling = m.get(3).i() == 1, afterCharge = m.get(4).i() == 1;
            boolean swap = m.get(5).i() == 1, back = m.get(6).i() == 1;
            LivingEntity target = nearest(mc, p, dist, m.get(7).i() == 1, m.get(8).i() == 1, true);
            int maceSlot = hotbarSlot(p, Items.MACE);
            if (target != null && maceSlot >= 0) {
                int prev = p.getInventory().getSelectedSlot();
                if (swap && prev != maceSlot) p.getInventory().setSelectedSlot(maceSlot);
                if (p.getMainHandItem().is(Items.MACE)) {
                    boolean fallOk = !whileFalling || (p.fallDistance >= minFall && p.fallDistance <= maxFall);
                    boolean chargeOk = !afterCharge || p.getAttackStrengthScale(0.0f) >= 0.9f;
                    if (fallOk && chargeOk) {
                        attack(mc, p, target);
                        if (back && prev != maceSlot) { restoreSlot = prev; restoreTicks = 3; }
                    }
                }
            }
        }

        // AimAssist
        if (Config.AIM.enabled && mc.screen == null) {
            Module m = Config.AIM;
            boolean weaponOk = m.get(4).i() == 0 || isWeapon(p.getMainHandItem());
            boolean clickOk = m.get(6).i() == 0 || mc.options.keyAttack.isDown();
            if (weaponOk && clickOk) aim(mc, p, m);
        }

        // TriggerBot
        if (Config.TRIGGER.enabled && free && !attacked) {
            Module m = Config.TRIGGER;
            double dist = m.get(0).value;
            float charge = m.get(1).f();
            int delay = m.get(2).i();
            boolean critsOnly = m.get(3).i() == 1;
            HitResult hit = mc.hitResult;
            if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le
                    && basicTarget(le, p, m.get(4).i() == 1, m.get(5).i() == 1) && p.distanceTo(le) <= dist) {
                boolean critOk = !critsOnly || (p.fallDistance > 0.0 && !p.onGround());
                if (critOk && p.getAttackStrengthScale(0.0f) >= charge) {
                    if (++trigTimer > delay) { trigTimer = 0; attack(mc, p, le); }
                }
            } else trigTimer = 0;
        }
    }

    /** Wings made of particles: two mirrored arcs behind the player that gently flap. */
    private static void wings(Minecraft mc, LocalPlayer p) {
        Module m = Config.WINGS;
        ParticleOptions type = WING_TYPES[Math.max(0, Math.min(WING_TYPES.length - 1, m.get(0).i()))];
        double size = m.get(1).value;
        int n = m.get(2).i();
        double yaw = Math.toRadians(p.yBodyRot);
        double leftX = Math.cos(yaw), leftZ = Math.sin(yaw);
        double backX = Math.sin(yaw), backZ = -Math.cos(yaw);
        double flap = 1.0 + 0.12 * Math.sin(System.currentTimeMillis() / 140.0);
        double lower = p.isShiftKeyDown() ? -0.2 : 0.0;
        for (int i = 0; i < n * 2; i++) {
            double t = p.getRandom().nextDouble();                    // root -> tip
            double s = 0.25 + p.getRandom().nextDouble() * 0.75;      // feather length
            double side = (i % 2 == 0 ? 1 : -1) * (0.18 + t * 1.1 * size * s) * flap;
            double up = 1.05 + Math.sin(t * Math.PI * 0.85) * 0.75 * size * s - (1 - s) * 0.35 + lower;
            double back = 0.22 + t * 0.18;
            mc.level.addParticle(type,
                p.getX() + leftX * side + backX * back,
                p.getY() + up,
                p.getZ() + leftZ * side + backZ * back,
                0.0, 0.0, 0.0);
        }
    }

    private static void aim(Minecraft mc, LocalPlayer p, Module m) {
        float smooth = 0.03f + m.get(0).f() * 0.35f;
        float fov = m.get(1).f();
        double range = m.get(2).value;
        float vertical = m.get(3).f();
        boolean byAngle = m.get(5).i() == 0;
        boolean players = m.get(7).i() == 1, mobs = m.get(8).i() == 1;
        boolean walls = m.get(9).i() == 1, invisible = m.get(10).i() == 1;
        boolean naked = m.get(11).i() == 1, armored = m.get(12).i() == 1;

        Vec3 eye = p.getEyePosition();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range),
                x -> basicTarget(x, p, players, mobs))) {
            if (!invisible && e.isInvisible()) continue;
            if (e instanceof Player) {
                boolean arm = hasArmor(e);
                if (arm && !armored) continue;
                if (!arm && !naked) continue;
            }
            double dsq = p.distanceToSqr(e);
            if (dsq > range * range) continue;
            if (!walls && !p.hasLineOfSight(e)) continue;
            Vec3 c = e.getBoundingBox().getCenter();
            float yaw = (float) (Math.atan2(c.z - eye.z, c.x - eye.x) * 180.0 / Math.PI) - 90f;
            float diff = Math.abs(Mth.wrapDegrees(yaw - p.getYRot()));
            if (diff > fov / 2f) continue;
            double score = byAngle ? diff : dsq;
            if (score < bestScore) { bestScore = score; best = e; }
        }
        if (best == null) return;
        Vec3 c = best.getBoundingBox().getCenter();
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitch = (float) (-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
        p.setYRot(p.getYRot() + Mth.wrapDegrees(yaw - p.getYRot()) * smooth);
        p.setXRot(Mth.clamp(p.getXRot() + (pitch - p.getXRot()) * smooth * vertical, -90f, 90f));
    }
}

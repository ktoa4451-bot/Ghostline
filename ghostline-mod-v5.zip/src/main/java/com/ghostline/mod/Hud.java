package com.ghostline.mod;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** In-game overlay: watermark, module list, coordinates, binds, target, armor, potions. */
public final class Hud {
    private Hud() { }

    private static final int[] used = new int[4];

    // corners: 0 top right, 1 top left, 2 bottom right, 3 bottom left
    private static int[] place(int corner, int w, int h, int sw, int sh) {
        boolean right = corner == 0 || corner == 2, bottom = corner >= 2;
        int off = used[corner];
        int x = right ? sw - 4 - w : 4;
        int y = bottom ? sh - 4 - off - h : 4 + off;
        used[corner] += h + 3;
        return new int[]{x, y};
    }

    public static void render(GuiGraphics g, DeltaTracker delta) {
        if (Config.panic || !Config.HUD.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        Module h = Config.HUD;
        float scale = h.get(13).f();
        float op = h.get(14).f();
        int sw = (int) (g.guiWidth() / scale), sh = (int) (g.guiHeight() / scale);

        used[0] = used[1] = used[2] = used[3] = 0;
        // keep clear of the status effect icons in the top right corner
        if (!mc.player.getActiveEffects().isEmpty()) used[0] = (int) (28 / scale);

        g.pose().pushMatrix();
        g.pose().scale(scale, scale);

        if (h.get(1).i() == 1) watermark(g, mc, h.get(8).i(), op, sw, sh);
        if (h.get(2).i() == 1) coords(g, mc, h.get(9).i(), op, sw, sh);
        if (h.get(0).i() == 1) moduleList(g, h.get(7).i(), h.get(11).i(), h.get(12).i(), op, sw, sh);
        if (Config.AUTOWARDEN.enabled && !AutoWarden.status.isEmpty()) status(g, h.get(8).i(), op, sw, sh);
        int extras = h.get(10).i();
        if (h.get(3).i() == 1) binds(g, extras, op, sw, sh);
        if (h.get(4).i() == 1) target(g, mc, extras, op, sw, sh);
        if (h.get(5).i() == 1) armor(g, mc, extras, op, sw, sh);
        if (h.get(6).i() == 1) potions(g, mc, extras, op, sw, sh);
        if (Config.WAYPOINTS.enabled) waypoints(g, mc, extras, op, sw, sh);

        g.pose().popMatrix();
    }

    private static void chip(GuiGraphics g, int x, int y, int w, int h, float op) {
        Ui.rect(g, x, y, w, h, 4, Ui.c(Ui.bg(), 0.72f * op));
    }

    private static void watermark(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        String name = "Ghostline";
        String user = mc.getUser().getName();
        int w = 12 + 4 + Ui.tw(name) + 8 + Ui.tw(user) + 10;
        int[] p = place(corner, w, 16, sw, sh);
        Ui.rect(g, p[0], p[1], w, 16, 5, Ui.c(Ui.bg(), 0.78f * op));
        Ui.ring(g, p[0], p[1], w, 16, 5, Ui.c(Ui.accent(), 0.55f * op));
        Ui.logo(g, Ui.LOGO, p[0] + 4, p[1] + 2, 12);
        Ui.text(g, name, p[0] + 20, p[1] + 4, Ui.c(Ui.TEXT, op));
        Ui.text(g, user, p[0] + 20 + Ui.tw(name) + 8, p[1] + 4, Ui.c(Ui.MUTED, op));
    }

    private static void status(GuiGraphics g, int corner, float op, int sw, int sh) {
        String s = Lang.t("aw.status") + ": " + AutoWarden.status;
        int w = Ui.tw(s) + 10;
        int[] p = place(corner, w, 14, sw, sh);
        chip(g, p[0], p[1], w, 14, op);
        Ui.text(g, s, p[0] + 5, p[1] + 3, Ui.c(Ui.accent(), op));
    }

    private static void coords(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        String s = "XYZ  " + mc.player.getBlockX() + "  " + mc.player.getBlockY() + "  " + mc.player.getBlockZ();
        int w = Ui.tw(s) + 10;
        int[] p = place(corner, w, 14, sw, sh);
        chip(g, p[0], p[1], w, 14, op);
        Ui.text(g, s, p[0] + 5, p[1] + 3, Ui.c(Ui.TEXT, op));
    }

    private static void moduleList(GuiGraphics g, int corner, int sort, int colorMode, float op, int sw, int sh) {
        List<String> names = new ArrayList<>();
        for (Module m : Config.ALL) if (m.action == null && m.toggleable && m.enabled) names.add(Lang.mod(m));
        if (names.isEmpty()) return;
        if (sort == 0) names.sort(Comparator.comparingInt((String s) -> -Ui.tw(s)));
        else names.sort(String.CASE_INSENSITIVE_ORDER);

        boolean right = corner == 0 || corner == 2;
        int line = 12;
        int maxW = 0;
        for (String s : names) maxW = Math.max(maxW, Ui.tw(s) + 10);
        int[] p = place(corner, maxW, names.size() * line, sw, sh);
        long t = System.currentTimeMillis();
        for (int i = 0; i < names.size(); i++) {
            String s = names.get(i);
            int w = Ui.tw(s) + 10;
            int x = right ? p[0] + maxW - w : p[0];
            int y = p[1] + i * line;
            int col;
            if (colorMode == 1) col = 0xFFFFFF;
            else if (colorMode == 2) col = Color.HSBtoRGB(((t % 6000) / 6000f + i * 0.06f) % 1f, 0.42f, 1f) & 0xFFFFFF;
            else col = Ui.accent();
            g.fill(x, y, x + w, y + line, Ui.c(Ui.bg(), 0.66f * op));
            int barX = right ? x + w - 2 : x;
            g.fill(barX, y, barX + 2, y + line, Ui.c(col, op));
            Ui.text(g, s, x + (right ? 4 : 5), y + 2, Ui.c(col, op));
        }
    }

    private static void binds(GuiGraphics g, int corner, float op, int sw, int sh) {
        List<String> lines = new ArrayList<>();
        for (Module m : Config.ALL) if (m.bind > 0) lines.add(Lang.mod(m) + "  [" + Config.keyName(m.bind) + "]");
        if (lines.isEmpty()) return;
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.TEXT, op));
    }

    private static void target(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        HitResult hit = mc.hitResult;
        if (!(hit instanceof EntityHitResult ehr) || !(ehr.getEntity() instanceof LivingEntity le)) return;
        String name = le.getName().getString();
        int w = Math.max(80, Ui.tw(name) + 12);
        int[] p = place(corner, w, 24, sw, sh);
        chip(g, p[0], p[1], w, 24, op);
        Ui.text(g, name, p[0] + 6, p[1] + 3, Ui.c(Ui.TEXT, op));
        float frac = Mth.clamp(le.getHealth() / Math.max(1f, le.getMaxHealth()), 0f, 1f);
        g.fill(p[0] + 6, p[1] + 15, p[0] + w - 6, p[1] + 19, Ui.c(Ui.border(), op));
        g.fill(p[0] + 6, p[1] + 15, p[0] + 6 + (int) ((w - 12) * frac), p[1] + 19, Ui.c(Ui.accent(), op));
    }

    private static void armor(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int w = 4 * 20 + 4;
        int[] p = place(corner, w, 28, sw, sh);
        chip(g, p[0], p[1], w, 28, op);
        for (int i = 0; i < 4; i++) {
            ItemStack st = mc.player.getItemBySlot(slots[i]);
            int ix = p[0] + 4 + i * 20, iy = p[1] + 2;
            if (st.isEmpty()) continue;
            g.renderItem(st, ix, iy);
            if (st.isDamageableItem()) {
                int left = st.getMaxDamage() - st.getDamageValue();
                String pct = (int) (100f * left / Math.max(1, st.getMaxDamage())) + "%";
                Ui.text(g, pct, ix + 8 - Ui.tw(pct) / 2, iy + 17, Ui.c(Ui.MUTED, op));
            }
        }
    }

    private static void waypoints(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        if (Config.WAYPOINTS_LIST.isEmpty()) return;
        final double px = mc.player.getX(), pz = mc.player.getZ();
        List<Config.Waypoint> sorted = new ArrayList<>(Config.WAYPOINTS_LIST);
        sorted.sort(Comparator.comparingDouble((Config.Waypoint wp) -> Math.hypot(wp.x + 0.5 - px, wp.z + 0.5 - pz)));
        String[] arrows = {"^", "^>", ">", "v>", "v", "<v", "<", "<^"};
        List<String> lines = new ArrayList<>();
        int max = Math.min(Config.WAYPOINTS.get(0).i(), sorted.size());
        for (int i = 0; i < max; i++) {
            Config.Waypoint wp = sorted.get(i);
            double dx = wp.x + 0.5 - px, dz = wp.z + 0.5 - pz;
            double target = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double rel = Mth.wrapDegrees(target - mc.player.getYRot()); // 0 = ahead, positive = to the right
            int idx = (int) Math.floorMod(Math.round(rel / 45.0), 8L);
            lines.add(arrows[idx] + " " + wp.name + "  " + (int) Math.hypot(dx, dz) + " m");
        }
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.accent(), op));
    }

    private static void potions(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        List<String> lines = new ArrayList<>();
        for (MobEffectInstance e : mc.player.getActiveEffects()) {
            int secs = Math.max(0, e.getDuration() / 20);
            String name = e.getEffect().value().getDisplayName().getString();
            lines.add(name + " " + (e.getAmplifier() + 1) + "  " + String.format(Locale.ROOT, "%d:%02d", secs / 60, secs % 60));
        }
        if (lines.isEmpty()) return;
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.TEXT, op));
    }
}

package com.ghostline.mod;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

/** In-game overlay: watermark, module list, coordinates, binds, target, armor, effects, module panels, notifications. */
public final class Hud {
    private Hud() { }

    private static final int[] used = new int[4];
    /** Last drawn rectangle {x, y, w, h} of each element, in HUD-scaled coordinates (the editor hit-tests with it). */
    static final Map<String, int[]> BOUNDS = new HashMap<>();
    private static String curId = "";
    private static boolean pushed;
    /** True while the HUD editor draws: every element is shown, with sample content where there is nothing real. */
    static boolean preview;

    // corners: 0 top right, 1 top left, 2 bottom right, 3 bottom left
    /**
     * Gives an element its place: stacked into its corner, or at the custom position from the HUD editor. The element's own
     * scale is applied here: when it differs from 1 the pose is scaled and (0,0) is returned, so the element just draws
     * at the returned origin. {@link #endElement} closes that transform.
     */
    static int[] place(GuiGraphics g, int corner, int w, int h, int sw, int sh) {
        HudLayout.Entry e = HudLayout.get(curId);
        float s = e.scale;
        int ws = Math.round(w * s), hs = Math.round(h * s);
        int x, y;
        if (e.custom) {
            int[] pos = HudLayout.position(e, ws, hs, sw, sh);
            x = pos[0]; y = pos[1];
        } else {
            boolean right = corner == 0 || corner == 2, bottom = corner >= 2;
            int off = used[corner];
            x = right ? sw - 4 - ws : 4;
            y = bottom ? sh - 4 - off - hs : 4 + off;
            used[corner] += hs + 3;
        }
        BOUNDS.put(curId, new int[]{x, y, ws, hs});
        if (s != 1f) {
            g.pose().pushMatrix();
            g.pose().translate((float) x, (float) y);
            g.pose().scale(s, s);
            pushed = true;
            return new int[]{0, 0};
        }
        return new int[]{x, y};
    }

    private static void endElement(GuiGraphics g) {
        if (pushed) { g.pose().popMatrix(); pushed = false; }
    }

    // ------------------------------------------------------------------ element state (shared with the HUD editor)

    /** HUD module setting that switches the element, or -1 when the element depends on its own module. */
    private static int settingOf(String id) {
        return switch (id) {
            case "modules" -> 0;
            case "watermark" -> 1;
            case "coords" -> 2;
            case "binds" -> 3;
            case "target" -> 4;
            case "armor" -> 5;
            case "effects" -> 6;
            default -> -1;
        };
    }

    /** Why a module-backed element would show nothing right now ("" when it is simply available). */
    static String gate(String id) {
        return switch (id) {
            case "status" -> Config.AUTOWARDEN.enabled ? "" : "AutoWarden";
            case "waypoints" -> Config.WAYPOINTS.enabled ? "" : "Waypoints";
            case "treefarm" -> Config.TREEFARM.enabled ? "" : "TreeFarm";
            case "friends" -> Config.FRIENDSHELP.enabled ? "" : "FriendsHelp";
            case "raid" -> Config.RAID.enabled ? "" : "RaidAssistant";
            case "invis" -> Config.INVIS.enabled ? "" : "InvisibilityHelper";
            case "findings" -> Config.BASEFINDER.enabled ? "" : "BaseFinder";
            case "notifications" -> Config.NOTIFY.enabled ? "" : "Notifications";
            default -> "";
        };
    }

    /** Is the element switched on (by its HUD setting, or by the editor for the rest)? */
    static boolean elementOn(String id) {
        int si = settingOf(id);
        if (si >= 0) return Config.HUD.get(si).i() == 1;
        if (id.equals("findings") && Config.BASEFINDER.get(22).i() != 1) return false;
        return HudLayout.get(id).enabled;
    }

    /** Switches an element from the editor: through the real HUD setting when there is one, else through the layout. */
    static void setElementOn(String id, boolean on) {
        int si = settingOf(id);
        if (si >= 0) Config.HUD.get(si).value = on ? 1 : 0;
        else if (id.equals("findings")) { HudLayout.get(id).enabled = on; if (on) Config.BASEFINDER.get(22).value = 1; }
        else HudLayout.get(id).enabled = on;
        Config.save();
    }

    /** Would the element really be drawn in the game right now? */
    private static boolean live(String id) {
        if (!elementOn(id)) return false;
        if (id.equals("status")) return Config.AUTOWARDEN.enabled && !AutoWarden.status.isEmpty();
        return gate(id).isEmpty();
    }

    static String label(String id) { return Lang.t("hud.el." + id); }

    // ------------------------------------------------------------------ small caches (lists that do not change every frame)

    private static final Map<String, Object[]> CACHE = new HashMap<>();

    @SuppressWarnings("unchecked")
    private static List<String> cached(String key, long ttlMs, Supplier<List<String>> make) {
        long now = System.currentTimeMillis();
        Object[] e = CACHE.get(key);
        if (e == null || now - (Long) e[0] > ttlMs) {
            e = new Object[]{now, make.get()};
            CACHE.put(key, e);
        }
        return (List<String>) e[1];
    }

    // ------------------------------------------------------------------ frame

    public static void render(GuiGraphics g, DeltaTracker delta) {
        if (Config.panic) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (mc.screen instanceof HudEditorScreen) return; // the editor draws the HUD itself

        // FPS counter (frames rendered per second)
        frames++;
        long nowMs = System.currentTimeMillis();
        if (nowMs - fpsAt >= 1000) { fps = frames; frames = 0; fpsAt = nowMs; }

        // screen-space overlays that work even when the HUD itself is switched off
        float pt = delta.getGameTimeDeltaPartialTick(false);
        long t0 = Perf.start();
        if (Config.ESP.enabled) PlayerEsp.render(g, mc, pt);
        BaseFinder.renderEsp(g, mc, pt);
        Perf.end("ESP", t0);

        if (!Config.HUD.enabled && !Config.NOTIFY.enabled) return;
        long t1 = Perf.start();
        drawHud(g, mc, false);
        Perf.end("Hud", t1);
    }

    /**
     * Draws all HUD elements. With preview=true (HUD editor) every element is drawn, switched-off ones faded and
     * empty ones with sample content, so each can be selected and moved.
     */
    static void drawHud(GuiGraphics g, Minecraft mc, boolean pv) {
        Module h = Config.HUD;
        preview = pv;
        float scale = h.get(13).f();
        float op0 = h.get(14).f();
        int sw = (int) (g.guiWidth() / scale), sh = (int) (g.guiHeight() / scale);
        boolean hudOn = h.enabled || pv;

        used[0] = used[1] = used[2] = used[3] = 0;
        // keep clear of the status effect icons in the top right corner
        if (!mc.player.getActiveEffects().isEmpty()) used[0] = (int) (28 / scale);
        if (pv) BOUNDS.clear();

        g.pose().pushMatrix();
        g.pose().scale(scale, scale);
        int extras = h.get(10).i();
        for (String id : HudLayout.IDS) {
            boolean notif = id.equals("notifications");
            if (!hudOn && !notif) continue;
            boolean on = live(id);
            if (!pv && !on) continue;
            float op = on ? op0 : op0 * 0.35f;
            curId = id;
            switch (id) {
                case "watermark" -> watermark(g, mc, h.get(8).i(), op, sw, sh);
                case "coords" -> coords(g, mc, h.get(9).i(), op, sw, sh);
                case "modules" -> moduleList(g, h.get(7).i(), h.get(11).i(), h.get(12).i(), op, sw, sh);
                case "status" -> status(g, h.get(8).i(), op, sw, sh);
                case "binds" -> binds(g, extras, op, sw, sh);
                case "target" -> target(g, mc, extras, op, sw, sh);
                case "armor" -> armor(g, mc, extras, op, sw, sh);
                case "effects" -> potions(g, mc, extras, op, sw, sh);
                case "waypoints" -> waypoints(g, mc, extras, op, sw, sh);
                case "treefarm" -> treeFarm(g, extras, op, sw, sh);
                case "friends" -> lines(g, cached("friends", 250, FriendsHelp::hudLines), SAMPLE_FRIENDS, extras, op, sw, sh);
                case "raid" -> lines(g, RaidAssistant.hudLines(), SAMPLE_RAID, extras, op, sw, sh);
                case "invis" -> lines(g, InvisHelper.hudLines(), SAMPLE_INVIS, extras, op, sw, sh);
                case "findings" -> findings(g, extras, op, sw, sh);
                case "notifications" -> Toasts.draw(g, Config.NOTIFY.get(2).i(), op, sw, sh, pv);
                default -> { }
            }
            endElement(g);
        }
        g.pose().popMatrix();
        preview = false;
    }

    private static final List<String> SAMPLE_FRIENDS = List.of("Friends online: Alex, Sam");
    private static final List<String> SAMPLE_RAID = List.of("Base: Home  ↗ 120m  (1/2)", "Loot: +3 diamond");
    private static final List<String> SAMPLE_INVIS = List.of("Invisible: 1:20 left", "Invisibility items: 2");

    private static void chip(GuiGraphics g, int x, int y, int w, int h, float op) {
        Ui.rect(g, x, y, w, h, 4, Ui.c(Ui.bg(), 0.72f * op));
    }

    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static int frames, fps;
    private static long fpsAt;
    private static String version;

    private static String version() {
        if (version == null) {
            version = FabricLoader.getInstance().getModContainer("ghostline")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("1.0");
        }
        return version;
    }

    private static int ping(Minecraft mc) {
        ClientPacketListener cn = mc.getConnection();
        if (cn == null || mc.player == null) return -1;
        PlayerInfo pi = cn.getPlayerInfo(mc.player.getUUID());
        return pi == null ? -1 : pi.getLatency();
    }

    /** Watermark in three styles: Ghostline (logo + frame), Compact (one slim line), Minimal (text only). */
    private static void watermark(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        Module h = Config.HUD;
        int style = h.get(15).i();
        List<String> info = new ArrayList<>();
        if (h.get(19).i() == 1) info.add(mc.getUser().getName());
        if (h.get(16).i() == 1) info.add(fps + " FPS");
        if (h.get(18).i() == 1) { int pg = ping(mc); if (pg >= 0) info.add(pg + " ms"); }
        if (h.get(20).i() == 1) info.add(LocalTime.now().format(CLOCK));
        String name = "Ghostline";
        String ver = h.get(17).i() == 1 ? "v" + version() : "";

        if (style == 1) { // Compact
            StringBuilder sb = new StringBuilder();
            for (String s : info) sb.append("  |  ").append(s);
            String tail = (ver.isEmpty() ? "" : " " + ver) + sb;
            int w = Ui.tw(name) + Ui.tw(tail) + 10;
            int[] p = place(g, corner, w, 14, sw, sh);
            chip(g, p[0], p[1], w, 14, op);
            Ui.text(g, name, p[0] + 5, p[1] + 3, Ui.c(Ui.accent(), op));
            Ui.text(g, tail, p[0] + 5 + Ui.tw(name), p[1] + 3, Ui.c(Ui.MUTED, op));
            return;
        }
        if (style == 2) { // Minimal
            StringBuilder sb = new StringBuilder(name);
            if (!ver.isEmpty()) sb.append(' ').append(ver);
            String tail = String.join("  ", info);
            int w = Ui.tw(sb.toString()) + (tail.isEmpty() ? 0 : 6 + Ui.tw(tail));
            int[] p = place(g, corner, w, 10, sw, sh);
            Ui.text(g, sb.toString(), p[0], p[1], Ui.c(Ui.accent(), op));
            if (!tail.isEmpty()) Ui.text(g, tail, p[0] + Ui.tw(sb.toString()) + 6, p[1], Ui.c(Ui.TEXT, op));
            return;
        }
        // Ghostline
        int w = 12 + 4 + Ui.tw(name) + 10;
        if (!ver.isEmpty()) w += 4 + Ui.tw(ver);
        for (String s : info) w += 8 + Ui.tw(s);
        int[] p = place(g, corner, w, 16, sw, sh);
        Ui.rect(g, p[0], p[1], w, 16, 5, Ui.c(Ui.bg(), 0.78f * op));
        Ui.ring(g, p[0], p[1], w, 16, 5, Ui.c(Ui.accent(), 0.55f * op));
        Ui.logo(g, Ui.LOGO, p[0] + 4, p[1] + 2, 12);
        int x = p[0] + 20;
        Ui.text(g, name, x, p[1] + 4, Ui.c(Ui.TEXT, op));
        x += Ui.tw(name);
        if (!ver.isEmpty()) { x += 4; Ui.text(g, ver, x, p[1] + 4, Ui.c(Ui.accent(), op)); x += Ui.tw(ver); }
        for (String s : info) { x += 8; Ui.text(g, s, x, p[1] + 4, Ui.c(Ui.MUTED, op)); x += Ui.tw(s); }
    }

    /** A chip with several text lines (used by the Part 2 modules). */
    private static void lines(GuiGraphics g, List<String> lines, List<String> sample, int corner, float op, int sw, int sh) {
        if (lines.isEmpty()) {
            if (!preview) return;
            lines = sample;
        }
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int hh = lines.size() * 11 + 4;
        int[] p = place(g, corner, w, hh, sw, sh);
        chip(g, p[0], p[1], w, hh, op);
        for (int i = 0; i < lines.size(); i++) {
            String s = lines.get(i);
            int col = s.startsWith("HELP") || s.startsWith("! ") ? 0xFFE05A5A : Ui.TEXT;
            Ui.text(g, s, p[0] + 5, p[1] + 3 + i * 11, Ui.c(col & 0xFFFFFF, op));
        }
    }

    private static void treeFarm(GuiGraphics g, int corner, float op, int sw, int sh) {
        List<String> lines = new ArrayList<>();
        lines.add("TreeFarm: " + TreeFarm.status);
        lines.add(String.format(Lang.t("tf.summary"), TreeFarm.total, TreeFarm.trees, TreeFarm.broken));
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(g, corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(i == 0 ? Ui.accent() : Ui.TEXT, op));
    }

    private static void findings(GuiGraphics g, int corner, float op, int sw, int sh) {
        List<String> lines = new ArrayList<>();
        for (String s : BaseFinder.hudLines(3)) lines.add(s.length() > 48 ? s.substring(0, 47) + "…" : s);
        if (lines.isEmpty()) lines.add(Lang.t("bf.none") + "  [" + BaseFinder.containerCount() + "]");
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(g, corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.TEXT, op));
    }

    private static void status(GuiGraphics g, int corner, float op, int sw, int sh) {
        String s = Lang.t("aw.status") + ": " + (AutoWarden.status.isEmpty() ? "..." : AutoWarden.status);
        int w = Ui.tw(s) + 10;
        int[] p = place(g, corner, w, 14, sw, sh);
        chip(g, p[0], p[1], w, 14, op);
        Ui.text(g, s, p[0] + 5, p[1] + 3, Ui.c(Ui.accent(), op));
    }

    private static void coords(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        String s = "XYZ  " + mc.player.getBlockX() + "  " + mc.player.getBlockY() + "  " + mc.player.getBlockZ();
        int w = Ui.tw(s) + 10;
        int[] p = place(g, corner, w, 14, sw, sh);
        chip(g, p[0], p[1], w, 14, op);
        Ui.text(g, s, p[0] + 5, p[1] + 3, Ui.c(Ui.TEXT, op));
    }

    private static void moduleList(GuiGraphics g, int corner, int sort, int colorMode, float op, int sw, int sh) {
        final int sortMode = sort;
        List<String> names = cached("modules" + sortMode + Config.lang, 300, () -> {
            List<String> l = new ArrayList<>();
            for (Module m : Config.ALL) if (m.action == null && m.toggleable && m.enabled) l.add(Lang.mod(m));
            if (sortMode == 0) l.sort(Comparator.comparingInt((String s) -> -Ui.tw(s)));
            else l.sort(String.CASE_INSENSITIVE_ORDER);
            return l;
        });
        if (names.isEmpty()) {
            if (!preview) return;
            names = List.of("Fly", "Speed", "ESP");
        }

        boolean right = corner == 0 || corner == 2;
        int line = 12;
        int maxW = 0;
        for (String s : names) maxW = Math.max(maxW, Ui.tw(s) + 10);
        int[] p = place(g, corner, maxW, names.size() * line, sw, sh);
        long t = System.currentTimeMillis();
        for (int i = 0; i < names.size(); i++) {
            String s = names.get(i);
            int w = Ui.tw(s) + 10;
            int x = right ? p[0] + maxW - w : p[0];
            int y = p[1] + i * line;
            int col;
            if (colorMode == 1) col = 0xFFFFFF;
            else if (colorMode == 2) col = Color.HSBtoRGB(((t % 6000) / 6000f + i * 0.06f) % 1f, 0.42f, 1f) & 0xFFFFFF;
            else col = Ui.accent();
            g.fill(x, y, x + w, y + line, Ui.c(Ui.bg(), 0.66f * op));
            int barX = right ? x + w - 2 : x;
            g.fill(barX, y, barX + 2, y + line, Ui.c(col, op));
            Ui.text(g, s, x + (right ? 4 : 5), y + 2, Ui.c(col, op));
        }
    }

    private static void binds(GuiGraphics g, int corner, float op, int sw, int sh) {
        List<String> lines = cached("binds" + Config.lang, 500, () -> {
            List<String> l = new ArrayList<>();
            for (Module m : Config.ALL) if (m.bind > 0) l.add(Lang.mod(m) + "  [" + Config.keyName(m.bind) + "]");
            return l;
        });
        if (lines.isEmpty()) {
            if (!preview) return;
            lines = List.of("Fly  [F]");
        }
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(g, corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.TEXT, op));
    }

    private static void target(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        String name;
        float frac;
        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) {
            name = le.getName().getString();
            frac = Mth.clamp(le.getHealth() / Math.max(1f, le.getMaxHealth()), 0f, 1f);
        } else if (preview) { name = "Target"; frac = 0.7f; }
        else return;
        int w = Math.max(80, Ui.tw(name) + 12);
        int[] p = place(g, corner, w, 24, sw, sh);
        chip(g, p[0], p[1], w, 24, op);
        Ui.text(g, name, p[0] + 6, p[1] + 3, Ui.c(Ui.TEXT, op));
        g.fill(p[0] + 6, p[1] + 15, p[0] + w - 6, p[1] + 19, Ui.c(Ui.border(), op));
        g.fill(p[0] + 6, p[1] + 15, p[0] + 6 + (int) ((w - 12) * frac), p[1] + 19, Ui.c(Ui.accent(), op));
    }

    private static void armor(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int w = 4 * 20 + 4;
        int[] p = place(g, corner, w, 28, sw, sh);
        chip(g, p[0], p[1], w, 28, op);
        for (int i = 0; i < 4; i++) {
            ItemStack st = mc.player.getItemBySlot(slots[i]);
            int ix = p[0] + 4 + i * 20, iy = p[1] + 2;
            if (st.isEmpty()) continue;
            g.renderItem(st, ix, iy);
            if (st.isDamageableItem()) {
                int left = st.getMaxDamage() - st.getDamageValue();
                String pct = (int) (100f * left / Math.max(1, st.getMaxDamage())) + "%";
                Ui.text(g, pct, ix + 8 - Ui.tw(pct) / 2, iy + 17, Ui.c(Ui.MUTED, op));
            }
        }
    }

    private static void waypoints(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        if (Config.WAYPOINTS_LIST.isEmpty()) {
            if (!preview) return;
            int sw0 = Ui.tw("^ Base  120 m") + 10;
            int[] q = place(g, corner, sw0, 15, sw, sh);
            chip(g, q[0], q[1], sw0, 15, op);
            Ui.text(g, "^ Base  120 m", q[0] + 5, q[1] + 3, Ui.c(Ui.accent(), op));
            return;
        }
        final double px = mc.player.getX(), pz = mc.player.getZ();
        List<Config.Waypoint> sorted = new ArrayList<>(Config.WAYPOINTS_LIST);
        sorted.sort(Comparator.comparingDouble((Config.Waypoint wp) -> Math.hypot(wp.x + 0.5 - px, wp.z + 0.5 - pz)));
        String[] arrows = {"^", "^>", ">", "v>", "v", "<v", "<", "<^"};
        List<String> lines = new ArrayList<>();
        int max = Math.min(Config.WAYPOINTS.get(0).i(), sorted.size());
        for (int i = 0; i < max; i++) {
            Config.Waypoint wp = sorted.get(i);
            double dx = wp.x + 0.5 - px, dz = wp.z + 0.5 - pz;
            double target = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double rel = Mth.wrapDegrees(target - mc.player.getYRot()); // 0 = ahead, positive = to the right
            int idx = (int) Math.floorMod(Math.round(rel / 45.0), 8L);
            lines.add(arrows[idx] + " " + wp.name + "  " + (int) Math.hypot(dx, dz) + " m");
        }
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(g, corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.accent(), op));
    }

    private static void potions(GuiGraphics g, Minecraft mc, int corner, float op, int sw, int sh) {
        List<String> lines = cached("effects", 200, () -> {
            List<String> l = new ArrayList<>();
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                int secs = Math.max(0, e.getDuration() / 20);
                String name = e.getEffect().value().getDisplayName().getString();
                l.add(name + " " + (e.getAmplifier() + 1) + "  " + String.format(Locale.ROOT, "%d:%02d", secs / 60, secs % 60));
            }
            return l;
        });
        if (lines.isEmpty()) {
            if (!preview) return;
            lines = List.of("Speed 2  0:30");
        }
        int w = 0;
        for (String s : lines) w = Math.max(w, Ui.tw(s) + 10);
        int[] p = place(g, corner, w, lines.size() * 11 + 4, sw, sh);
        chip(g, p[0], p[1], w, lines.size() * 11 + 4, op);
        for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), p[0] + 5, p[1] + 3 + i * 11, Ui.c(Ui.TEXT, op));
    }
}

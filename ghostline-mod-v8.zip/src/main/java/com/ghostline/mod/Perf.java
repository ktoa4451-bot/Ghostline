package com.ghostline.mod;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Optional timing of Ghostline's own work per tick/frame. Off by default (zero cost beyond a boolean check). */
public final class Perf {
    private Perf() { }

    public static volatile boolean enabled;
    private static final Map<String, long[]> T = new LinkedHashMap<>(); // name -> {total ns, count, max ns}

    public static long start() { return enabled ? System.nanoTime() : 0L; }

    public static void end(String name, long t0) {
        if (t0 == 0L) return;
        long d = System.nanoTime() - t0;
        synchronized (T) {
            long[] a = T.computeIfAbsent(name, k -> new long[3]);
            a[0] += d; a[1]++; if (d > a[2]) a[2] = d;
        }
    }

    public static void reset() { synchronized (T) { T.clear(); } }

    /** Lines sorted by average cost, e.g. "BaseFinder  avg 0.21 ms  max 3.40 ms  (1200 calls)". */
    public static List<String> report() {
        List<Map.Entry<String, long[]>> list;
        synchronized (T) { list = new ArrayList<>(T.entrySet()); }
        list.sort((a, b) -> Double.compare(b.getValue()[0] / (double) Math.max(1, b.getValue()[1]), a.getValue()[0] / (double) Math.max(1, a.getValue()[1])));
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, long[]> e : list) {
            long[] a = e.getValue();
            out.add(String.format(Locale.ROOT, "%s  avg %.3f ms  max %.2f ms  (%d)", e.getKey(), a[0] / (double) Math.max(1, a[1]) / 1e6, a[2] / 1e6, a[1]));
        }
        return out;
    }
}

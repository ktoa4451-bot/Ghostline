package com.ghostline.mod;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * FriendsHelp: friends list, statuses, private/friend chat and help requests through a Ghostline server (see /server).
 * Passwords never reach the client: the user gets a one-time pairing code on the server's web page and enters it in the
 * menu. The session token is stored encrypted ({@link SecretStore}) and is never shown or logged.
 * Coordinates are sent only when the user explicitly asks for it ("/ghelp coords" or by pressing the help key again).
 */
public final class FriendsHelp {
    private FriendsHelp() { }

    private static final String[] STATES = {"online", "away", "busy", "invisible"};

    private static SocialClient client;
    private static String base = "";
    private static volatile String netState = "off";
    private static final ConcurrentLinkedQueue<Map<String, String>> events = new ConcurrentLinkedQueue<>();
    private static boolean claiming, hintShown;
    private static String selfName = "";
    private static long coordsArmedUntil;
    private static boolean keyPrev;
    private static String sentSig = "";
    private static long lastTickSig;

    /** name -> state (online, away, busy, offline), kept in the order the server sent it. */
    private static final Map<String, String> friends = new LinkedHashMap<>();
    private static final List<String> incoming = new ArrayList<>();

    private record Alert(String from, String text, boolean hasCoords, int x, int y, int z, String dim, long at) { }
    private static Alert lastHelp;

    // ------------------------------------------------------------------ small helpers

    private static Module mod() { return Config.FRIENDSHELP; }

    private static String clean(String s) { return s == null ? "" : s.replace("§", "").replaceAll("[\\p{Cntrl}]", " "); }

    private static void msg(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("§8[§dGhostline§8] §7" + s), false);
    }

    private static void bar(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(s), true);
    }

    private static void later(String s) { // from network threads
        Map<String, String> e = new LinkedHashMap<>();
        e.put("type", "_msg");
        e.put("text", s);
        events.add(e);
    }

    public static boolean connected() { return client != null && "online".equals(netState); }

    // ------------------------------------------------------------------ session storage (encrypted)

    private static Path sessionFile() { return FabricLoader.getInstance().getConfigDir().resolve("ghostline-session.dat"); }

    private static void saveSession(String url, String user, String token) {
        try {
            SecretStore.init(FabricLoader.getInstance().getConfigDir());
            String enc = SecretStore.encrypt(url + "\n" + user + "\n" + token);
            if (!enc.isEmpty()) Files.writeString(sessionFile(), enc, StandardCharsets.UTF_8);
        } catch (Exception ignored) { }
    }

    /** {user, token} for this server, or null. */
    private static String[] loadSession(String url) {
        try {
            if (!Files.exists(sessionFile())) return null;
            SecretStore.init(FabricLoader.getInstance().getConfigDir());
            String[] p = SecretStore.decrypt(Files.readString(sessionFile(), StandardCharsets.UTF_8).trim()).split("\n");
            if (p.length != 3 || !p[0].equals(url) || p[2].isEmpty()) return null;
            return new String[]{p[1], p[2]};
        } catch (Exception e) { return null; }
    }

    private static void dropSession() { try { Files.deleteIfExists(sessionFile()); } catch (Exception ignored) { } }

    // ------------------------------------------------------------------ lifecycle

    /** Runs every tick while the module is on. */
    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = mod();
        if (client == null) connect(m);
        drain(mc, p);
        long now = System.currentTimeMillis();

        if (connected() && now - lastTickSig > 1000) { // push status / privacy changes
            lastTickSig = now;
            String sig = m.get(2).i() + "|" + m.get(3).text + "|" + m.get(4).i() + "|" + m.get(5).i();
            if (!sig.equals(sentSig)) { sentSig = sig; pushSettings(m); }
        }

        long win = GLFW.glfwGetCurrentContext();
        boolean down = win != 0 && m.get(8).i() > 0 && GLFW.glfwGetKey(win, m.get(8).i()) == GLFW.GLFW_PRESS;
        if (down && !keyPrev && mc.screen == null) requestHelp(mc, now < coordsArmedUntil);
        keyPrev = down;
    }

    private static void connect(Module m) {
        String url;
        try { url = SocialClient.checkUrl(m.get(0).text); }
        catch (IllegalArgumentException e) {
            if (!hintShown) { hintShown = true; msg("FriendsHelp: " + e.getMessage()); }
            return;
        }
        base = url;
        String[] ses = loadSession(url);
        if (ses != null) { selfName = ses[0]; start(ses[1]); return; }
        String code = m.get(1).text.trim();
        if (code.isEmpty()) {
            if (!hintShown) { hintShown = true; msg(Lang.t("fh.need_code")); }
            return;
        }
        if (claiming) return;
        claiming = true;
        m.get(1).text = ""; // the code is single-use; do not keep it
        final String b = url;
        Thread t = new Thread(() -> {
            Map<String, String> r = SocialClient.claim(b, code);
            Map<String, String> e = new LinkedHashMap<>();
            if (r.containsKey("token")) { e.put("type", "_claim"); e.put("token", r.get("token")); e.put("user", r.getOrDefault("user", "")); }
            else { e.put("type", "_msg"); e.put("text", Lang.t("fh.claim_failed") + ": " + clean(r.getOrDefault("error", "?"))); e.put("claimFail", "1"); }
            events.add(e);
        }, "ghostline-claim");
        t.setDaemon(true);
        t.start();
    }

    private static void start(String token) {
        client = new SocialClient(base, token, new SocialClient.Listener() {
            @Override public void onEvent(Map<String, String> e) { events.add(e); }
            @Override public void onState(String s) {
                String old = netState;
                netState = s;
                if (s.equals("unauthorized")) { Map<String, String> e = new LinkedHashMap<>(); e.put("type", "_unauthorized"); events.add(e); }
                else if (s.equals("reconnecting") && old.equals("online")) later(Lang.t("fh.lost"));
            }
        });
        client.start();
    }

    /** Disconnects (the saved session stays, so turning the module on again reconnects). */
    public static void stop() {
        if (client == null && !claiming && netState.equals("off") && friends.isEmpty() && incoming.isEmpty() && events.isEmpty()) return; // idle: cheap exit
        if (client != null) { client.stop(); client = null; }
        netState = "off";
        claiming = false;
        hintShown = false;
        sentSig = "";
        friends.clear();
        incoming.clear();
        events.clear();
    }

    private static void logout() {
        if (client != null) client.logout();
        dropSession();
        stop();
        msg(Lang.t("fh.logged_out"));
    }

    private static void pushSettings(Module m) {
        if (client == null) return;
        Map<String, Object> st = new LinkedHashMap<>();
        st.put("type", "status");
        st.put("state", STATES[Math.max(0, Math.min(3, m.get(2).i()))]);
        st.put("note", m.get(3).text);
        client.send(st, null);
        Map<String, Object> pv = new LinkedHashMap<>();
        pv.put("type", "privacy");
        pv.put("showOnline", m.get(4).i() == 1 ? "nobody" : "friends");
        pv.put("friendRequests", m.get(5).i() == 1 ? "nobody" : "everyone");
        client.send(pv, null);
    }

    // ------------------------------------------------------------------ incoming events (main thread)

    private static void parseFriends(String line) {
        friends.clear();
        if (line == null || line.isBlank()) return;
        for (String part : line.split(",")) {
            int i = part.lastIndexOf(':');
            if (i > 0) friends.put(part.substring(0, i), part.substring(i + 1));
        }
    }

    private static void drain(Minecraft mc, LocalPlayer p) {
        Module m = mod();
        Map<String, String> e;
        int guard = 0;
        while (guard++ < 50 && (e = events.poll()) != null) {
            String type = e.getOrDefault("type", "");
            switch (type) {
                case "_msg" -> {
                    String tx = clean(e.get("text"));
                    msg(tx);
                    boolean bad = e.containsKey("claimFail") || tx.startsWith(Lang.t("fh.failed"));
                    Toasts.friends(bad ? ToastQueue.Type.ERROR : ToastQueue.Type.INFO, "FriendsHelp", tx);
                    if (e.containsKey("claimFail")) claiming = false;
                }
                case "_claim" -> {
                    saveSession(base, e.get("user"), e.get("token"));
                    selfName = clean(e.get("user"));
                    claiming = false;
                    msg(Lang.t("fh.paired"));
                    Toasts.friends(ToastQueue.Type.SUCCESS, "FriendsHelp", Lang.t("fh.paired"));
                    start(e.get("token"));
                }
                case "_unauthorized" -> {
                    dropSession();
                    stop();
                    msg(Lang.t("fh.expired"));
                    Toasts.friends(ToastQueue.Type.ERROR, "FriendsHelp", Lang.t("fh.expired"));
                }
                case "hello" -> {
                    selfName = clean(e.get("name"));
                    parseFriends(e.get("friends"));
                    incoming.clear();
                    String in = e.getOrDefault("incoming", "");
                    if (!in.isBlank()) for (String n : in.split(",")) incoming.add(clean(n));
                    sentSig = "";
                    msg(String.format(Lang.t("fh.connected"), selfName, friends.size(), incoming.size()));
                    Toasts.friends(ToastQueue.Type.SUCCESS, "FriendsHelp", String.format(Lang.t("fh.connected"), selfName, friends.size(), incoming.size()));
                }
                case "friend.state" -> {
                    String n = clean(e.get("name")), s = e.getOrDefault("state", "offline");
                    String old = friends.put(n, s);
                    boolean wasOn = old != null && !old.equals("offline"), isOn = !s.equals("offline");
                    if (m.get(6).i() == 1 && wasOn != isOn) Toasts.friends(isOn ? ToastQueue.Type.SUCCESS : ToastQueue.Type.INFO, n, Lang.t(isOn ? "fh.online" : "fh.offline"));
                }
                case "friend.request" -> {
                    String n = clean(e.get("name"));
                    if (!incoming.contains(n)) incoming.add(n);
                    msg(String.format(Lang.t("fh.request"), n, n));
                    Toasts.friends(ToastQueue.Type.INFO, n, String.format(Lang.t("fh.request"), n, n));
                }
                case "friend.added" -> {
                    String n = clean(e.get("name"));
                    friends.put(n, e.getOrDefault("state", "offline"));
                    incoming.remove(n);
                    msg(String.format(Lang.t("fh.added"), n));
                    Toasts.friends(ToastQueue.Type.SUCCESS, n, String.format(Lang.t("fh.added"), n));
                }
                case "friend.removed" -> {
                    String n = clean(e.get("name"));
                    friends.remove(n);
                    msg(String.format(Lang.t("fh.removed"), n));
                }
                case "chat" -> {
                    if (m.get(7).i() == 1) {
                        boolean priv = "private".equals(e.get("scope"));
                        String line = "§d" + clean(e.get("from")) + (priv ? " §8→ §7you" : " §8→ §7friends") + "§8: §f" + clean(e.get("text"));
                        if (p != null) p.displayClientMessage(Component.literal("§8[§dGL§8] " + line), false);
                    }
                }
                case "help" -> onHelp(p, e);
                default -> { }
            }
        }
    }

    private static void onHelp(LocalPlayer p, Map<String, String> e) {
        String from = clean(e.get("from")), text = clean(e.get("text"));
        boolean has = e.containsKey("x");
        int x = 0, y = 0, z = 0;
        String dim = clean(e.getOrDefault("dim", ""));
        try {
            if (has) { x = Integer.parseInt(e.get("x")); y = Integer.parseInt(e.get("y")); z = Integer.parseInt(e.get("z")); }
        } catch (NumberFormatException ex) { has = false; }
        lastHelp = new Alert(from, text, has, x, y, z, dim, System.currentTimeMillis());
        String where = has ? String.format("  §e%d %d %d §7(%s)", x, y, z, dim.isEmpty() ? "?" : dim) : "  §8(" + Lang.t("fh.no_coords") + ")";
        if (p != null) p.displayClientMessage(Component.literal("§c§l[HELP] §r§c" + from + "§7: §f" + text + where), false);
        Toasts.help(Lang.t("fh.help_from") + " " + from, text + (has ? "  " + x + " " + y + " " + z : ""));
    }

    // ------------------------------------------------------------------ actions

    /**
     * Sends a help request to friends. Coordinates go along only when withCoords is true AND the "Share coordinates"
     * setting allows it. After a request without them the user can confirm within 15 s to share them.
     */
    public static void requestHelp(Minecraft mc, boolean withCoords) {
        if (!mod().enabled) { msg(Lang.t("fh.off")); return; }
        if (!connected()) { msg(Lang.t("fh.not_connected")); return; }
        LocalPlayer p = mc.player;
        if (p == null) return;
        boolean allowed = mod().get(9).i() == 1;
        if (withCoords && !allowed) { msg(Lang.t("fh.coords_off")); withCoords = false; }
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("type", "help");
        b.put("text", mod().get(10).text.isBlank() ? "Need help!" : mod().get(10).text);
        b.put("coords", withCoords);
        if (withCoords) {
            String[] ctx = Notifier.ctx(mc).split("\\|", 2);
            b.put("x", p.getBlockX());
            b.put("y", p.getBlockY());
            b.put("z", p.getBlockZ());
            b.put("dim", ctx.length > 1 ? ctx[1] : "");
            b.put("server", ctx[0]);
        }
        final boolean sentCoords = withCoords;
        client.send(b, r -> {
            if (r.containsKey("ok")) {
                int n = 0;
                try { n = Integer.parseInt(r.getOrDefault("delivered", "0")); } catch (NumberFormatException ignored) { }
                later(String.format(Lang.t(sentCoords ? "fh.help_sent_coords" : "fh.help_sent"), n));
            } else later(Lang.t("fh.failed") + ": " + clean(r.getOrDefault("error", "?")));
        });
        if (!sentCoords && allowed) {
            coordsArmedUntil = System.currentTimeMillis() + 15_000;
            msg(Lang.t("fh.coords_ask"));
        } else if (sentCoords) coordsArmedUntil = 0;
    }

    private static void friendOp(String type, String name) {
        if (!mod().enabled) { msg(Lang.t("fh.off")); return; }
        if (!connected()) { msg(Lang.t("fh.not_connected")); return; }
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("type", type);
        b.put("name", name.length() > 16 ? name.substring(0, 16) : name);
        client.send(b, r -> later(r.containsKey("ok") ? Lang.t("fh.done") : Lang.t("fh.failed") + ": " + clean(r.getOrDefault("error", "?"))));
    }

    private static void chat(String to, String text) {
        if (!connected()) { msg(Lang.t("fh.not_connected")); return; }
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("type", "chat");
        b.put("to", to);
        b.put("text", text);
        client.send(b, r -> {
            if (!r.containsKey("ok")) later(Lang.t("fh.failed") + ": " + clean(r.getOrDefault("error", "?")));
        });
    }

    private static void setStatus(String state, String note) {
        for (int i = 0; i < STATES.length; i++) {
            if (STATES[i].equals(state)) {
                mod().get(2).value = i;
                if (note != null) mod().get(3).text = note.length() > 40 ? note.substring(0, 40) : note;
                Config.save();
                msg(Lang.t("fh.done"));
                return;
            }
        }
        msg("online | away | busy | invisible");
    }

    private static void listFriends() {
        if (!connected()) { msg(Lang.t("fh.not_connected")); return; }
        if (friends.isEmpty()) msg(Lang.t("fh.no_friends"));
        for (Map.Entry<String, String> f : friends.entrySet()) {
            String s = f.getValue();
            String col = s.equals("online") ? "§a" : s.equals("offline") ? "§8" : "§e";
            msg(col + f.getKey() + " §8- §7" + s);
        }
        if (!incoming.isEmpty()) msg(Lang.t("fh.requests") + ": " + String.join(", ", incoming));
    }

    // ------------------------------------------------------------------ HUD

    public static List<String> hudLines() {
        List<String> out = new ArrayList<>();
        if (!mod().enabled) return out;
        if (mod().get(12).i() == 1) {
            if (!connected()) out.add("FriendsHelp: " + Lang.t("fh.hud_" + (netState.equals("off") ? "off" : "wait")));
            else {
                StringBuilder sb = new StringBuilder();
                int n = 0;
                for (Map.Entry<String, String> f : friends.entrySet()) {
                    if (f.getValue().equals("offline")) continue;
                    if (n++ < 5) sb.append(sb.length() > 0 ? ", " : "").append(f.getKey()).append(f.getValue().equals("online") ? "" : " (" + f.getValue() + ")");
                }
                out.add(Lang.t("fh.hud_friends") + " " + (n == 0 ? "-" : sb + (n > 5 ? " +" + (n - 5) : "")));
            }
        }
        Alert a = lastHelp;
        if (a != null && System.currentTimeMillis() - a.at() < 60_000) {
            Minecraft mc = Minecraft.getInstance();
            String d = "";
            if (a.hasCoords() && mc.player != null) {
                String[] ctx = Notifier.ctx(mc).split("\\|", 2);
                boolean same = ctx.length > 1 && ctx[1].equals(a.dim());
                d = same ? "  " + (int) Math.sqrt(mc.player.distanceToSqr(a.x(), a.y(), a.z())) + "m" : "";
            }
            out.add("HELP " + a.from() + ": " + a.text() + (a.hasCoords() ? "  " + a.x() + " " + a.y() + " " + a.z() + d : ""));
        }
        return out;
    }

    // ------------------------------------------------------------------ commands: /gl ... and /ghelp, optional /help

    public static void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            Minecraft mc = Minecraft.getInstance();
            dispatcher.register(ClientCommandManager.literal("ghelp")
                .executes(ctx -> { requestHelp(mc, false); return 1; })
                .then(ClientCommandManager.literal("coords").executes(ctx -> { requestHelp(mc, true); return 1; })));
            dispatcher.register(ClientCommandManager.literal("gl")
                .then(ClientCommandManager.literal("friends").executes(ctx -> { listFriends(); return 1; }))
                .then(ClientCommandManager.literal("add").then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> { friendOp("friend.add", StringArgumentType.getString(ctx, "name")); return 1; })))
                .then(ClientCommandManager.literal("accept").then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> { friendOp("friend.accept", StringArgumentType.getString(ctx, "name")); return 1; })))
                .then(ClientCommandManager.literal("decline").then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> { friendOp("friend.decline", StringArgumentType.getString(ctx, "name")); return 1; })))
                .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> { friendOp("friend.remove", StringArgumentType.getString(ctx, "name")); return 1; })))
                .then(ClientCommandManager.literal("msg").then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .then(ClientCommandManager.argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> { chat(StringArgumentType.getString(ctx, "name"), StringArgumentType.getString(ctx, "text")); return 1; }))))
                .then(ClientCommandManager.literal("say").then(ClientCommandManager.argument("text", StringArgumentType.greedyString())
                    .executes(ctx -> { chat("*", StringArgumentType.getString(ctx, "text")); return 1; })))
                .then(ClientCommandManager.literal("status").then(ClientCommandManager.argument("state", StringArgumentType.word())
                    .executes(ctx -> { setStatus(StringArgumentType.getString(ctx, "state"), null); return 1; })
                    .then(ClientCommandManager.argument("note", StringArgumentType.greedyString())
                        .executes(ctx -> { setStatus(StringArgumentType.getString(ctx, "state"), StringArgumentType.getString(ctx, "note")); return 1; }))))
                .then(ClientCommandManager.literal("help").executes(ctx -> { requestHelp(mc, false); return 1; }))
                .then(ClientCommandManager.literal("logout").executes(ctx -> { logout(); return 1; })));
        });
        // optional: plain /help sends a help request instead of the vanilla command
        ClientSendMessageEvents.ALLOW_COMMAND.register(command -> {
            if (mod().enabled && mod().get(11).i() == 1 && command.trim().equalsIgnoreCase("help")) {
                requestHelp(Minecraft.getInstance(), false);
                return false;
            }
            return true;
        });
    }
}

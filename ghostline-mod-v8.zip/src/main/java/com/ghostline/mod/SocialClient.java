package com.ghostline.mod;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Network side of FriendsHelp. No Minecraft dependencies. Talks to ghostline-server.js: a server-sent-events stream for
 * incoming events and small POST requests for outgoing ones. The session token is kept only in memory here and is sent
 * only in an Authorization header, never in a URL and never written to any log.
 */
public final class SocialClient {
    public interface Listener {
        void onEvent(Map<String, String> event);
        /** connecting, online, reconnecting, unauthorized, stopped */
        void onState(String state);
    }

    private final String base;
    private final String token;
    private final Listener listener;
    private volatile boolean running;
    private volatile Thread thread;
    private volatile HttpURLConnection current;

    public SocialClient(String base, String token, Listener listener) {
        this.base = base;
        this.token = token;
        this.listener = listener;
    }

    /** https is required except for this computer (localhost), so tokens never travel unencrypted over a network. */
    public static String checkUrl(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("server address is empty");
        URI u;
        try { u = URI.create(raw.trim()); } catch (RuntimeException e) { throw new IllegalArgumentException("bad server address"); }
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        String host = u.getHost();
        if (host == null || u.getUserInfo() != null) throw new IllegalArgumentException("bad server address");
        boolean local = host.equals("localhost") || host.equals("127.0.0.1") || host.equals("[::1]") || host.equals("::1");
        if (scheme.equals("https") || (scheme.equals("http") && local)) {
            String path = u.getPath() == null ? "" : u.getPath().replaceAll("/+$", "");
            return scheme + "://" + host + (u.getPort() > 0 ? ":" + u.getPort() : "") + path;
        }
        throw new IllegalArgumentException("use https:// (plain http is allowed only for localhost)");
    }

    private static HttpURLConnection open(String url, String method, String token) throws IOException {
        HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
        c.setInstanceFollowRedirects(false); // never forward the token to another address
        c.setConnectTimeout(5000);
        c.setReadTimeout(8000);
        c.setRequestMethod(method);
        c.setRequestProperty("Accept", "application/json, text/event-stream");
        if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
        return c;
    }

    private static String read(InputStream in) throws IOException {
        if (in == null) return "";
        byte[] b = in.readNBytes(20000);
        return new String(b, StandardCharsets.UTF_8);
    }

    private static Map<String, String> post(String url, String token, Map<String, Object> body) {
        Map<String, String> out = new LinkedHashMap<>();
        HttpURLConnection c = null;
        try {
            c = open(url, "POST", token);
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            c.getOutputStream().write(MiniJson.encode(body).getBytes(StandardCharsets.UTF_8));
            int code = c.getResponseCode();
            String text = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
            Map<String, String> m = MiniJson.decode(text);
            if (m != null) out.putAll(m);
            if (code >= 300 && !out.containsKey("error")) out.put("error", "HTTP " + code);
            out.put("status", String.valueOf(code));
        } catch (IOException e) {
            out.put("error", "no connection");
        } finally { if (c != null) c.disconnect(); }
        return out;
    }

    /** Exchanges a one-time pairing code for a session token. Returns {token, user} or {error}. */
    public static Map<String, String> claim(String base, String code) {
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("code", code == null ? "" : code.trim());
        return post(base + "/api/claim", null, b);
    }

    public void send(Map<String, Object> body, Consumer<Map<String, String>> done) {
        Async.net(() -> {
            Map<String, String> r = post(base + "/api/send", token, body);
            if (done != null) done.accept(r);
        });
    }

    public void logout() {
        post(base + "/api/logout", token, new LinkedHashMap<>());
    }

    public void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop, "ghostline-events");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        HttpURLConnection c = current;
        if (c != null) c.disconnect();
        Thread t = thread;
        if (t != null) t.interrupt();
        listener.onState("stopped");
    }

    private void loop() {
        int wait = 2000;
        boolean first = true;
        while (running) {
            listener.onState(first ? "connecting" : "reconnecting");
            first = false;
            HttpURLConnection c = null;
            try {
                c = open(base + "/api/events", "GET", token);
                c.setReadTimeout(70_000); // the server sends a heartbeat every 20 s
                current = c;
                int code = c.getResponseCode();
                if (code == 401) { listener.onState("unauthorized"); running = false; return; }
                if (code != 200) throw new IOException("HTTP " + code);
                wait = 2000;
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    boolean announced = false;
                    while (running && (line = r.readLine()) != null) {
                        if (!line.startsWith("data: ")) continue;
                        Map<String, String> ev = MiniJson.decode(line.substring(6));
                        if (ev == null) continue;
                        if (!announced) { listener.onState("online"); announced = true; }
                        listener.onEvent(ev);
                    }
                }
            } catch (IOException | RuntimeException e) {
                // fall through to the reconnect delay
            } finally {
                current = null;
                if (c != null) c.disconnect();
            }
            if (!running) return;
            try { Thread.sleep(wait); } catch (InterruptedException e) { return; }
            wait = Math.min(wait * 2, 30_000);
        }
    }
}

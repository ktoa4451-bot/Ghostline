package com.ghostline.mod;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Keeps tokens out of config files in plain text: AES-256-GCM with a key derived (PBKDF2) from a random salt file and
 * machine/user properties. This stops casual leaks (a config uploaded or synced to another machine, a screenshot of the
 * file). It cannot stop malware running as the same user on the same machine, which can ask the OS for the same inputs.
 */
public final class SecretStore {
    private SecretStore() { }

    public static final String PREFIX = "enc1:";
    private static Path dir;
    private static SecretKey key;
    private static final SecureRandom RNG = new SecureRandom();

    public static synchronized void init(Path configDir) {
        if (dir != null && dir.equals(configDir)) return;
        dir = configDir;
        key = null;
    }

    private static SecretKey key() throws Exception {
        if (key != null) return key;
        if (dir == null) throw new IllegalStateException("not initialised");
        Path saltFile = dir.resolve("ghostline.salt");
        byte[] salt;
        if (Files.exists(saltFile)) salt = Files.readAllBytes(saltFile);
        else { salt = new byte[16]; RNG.nextBytes(salt); Files.write(saltFile, salt); }
        String machine = System.getProperty("user.name", "") + "|" + System.getProperty("os.name", "") + "|"
            + System.getProperty("user.home", "") + "|ghostline-v1";
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] k = f.generateSecret(new PBEKeySpec(machine.toCharArray(), salt, 120_000, 256)).getEncoded();
        key = new SecretKeySpec(k, "AES");
        return key;
    }

    /** Derives the key now (PBKDF2 takes ~0.1 s), so the first save does not stall the game thread. Call off-thread. */
    public static synchronized void warm() {
        try { key(); } catch (Exception ignored) { }
    }

    public static boolean isEncrypted(String s) { return s != null && s.startsWith(PREFIX); }

    /** Returns "enc1:..." or an empty string when encryption is not possible. Never returns the plain text. */
    public static synchronized String encrypt(String plain) {
        if (plain == null || plain.isEmpty()) return "";
        try {
            byte[] iv = new byte[12];
            RNG.nextBytes(iv);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            byte[] all = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, all, 0, iv.length);
            System.arraycopy(ct, 0, all, iv.length, ct.length);
            return PREFIX + Base64.getEncoder().encodeToString(all);
        } catch (Exception e) { return ""; }
    }

    /** Decrypts a stored value. Legacy plain text (no prefix) is returned unchanged so old configs keep working. */
    public static synchronized String decrypt(String stored) {
        if (stored == null || stored.isEmpty()) return "";
        if (!isEncrypted(stored)) return stored;
        try {
            byte[] all = Base64.getDecoder().decode(stored.substring(PREFIX.length()));
            if (all.length < 13) return "";
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, all, 0, 12));
            return new String(c.doFinal(all, 12, all.length - 12), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
}

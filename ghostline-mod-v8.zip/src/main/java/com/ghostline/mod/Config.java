package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

public class Config {
    public static final int VERSION = 3;

    public static final String[] SWAP_ITEMS = {"Any", "Totem", "Enchanted totem", "Head", "Shield", "Gapple", "Pearl", "Firework", "Crystal"};
    private static final String[] POS = {"Top right", "Top left", "Bottom right", "Bottom left"};

    // categories: 0 Combat, 1 Movement, 2 Player, 3 Visuals, 4 Misc, 8 Cosmetics (pages 5-7 are Theme/HUD/Configs)

    // ---- Combat ----
    public static final Module AIM = new Module("AimAssist", 0)
        .add(new Setting("Speed", 0.4, 0.1, 1.0, 0.05).fmt("%.0f%%", 100))
        .add(new Setting("FOV", 70, 20, 180, 5).fmt("%.0f°", 1))
        .add(new Setting("Distance", 4.5, 1.0, 6.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Vertical", 1.0, 0.0, 1.0, 0.05).fmt("%.0f%%", 100))
        .add(Setting.bool("Weapon only", false))
        .add(new Setting("Priority", 0, "Angle", "Distance"))
        .add(Setting.bool("Only on click", false))
        .add(Setting.bool("Players", true))
        .add(Setting.bool("Mobs", true))
        .add(Setting.bool("Through walls", false))
        .add(Setting.bool("Invisible", true))
        .add(Setting.bool("Naked", true))
        .add(Setting.bool("In armor", true));
    public static final Module AUTOMACE = new Module("AutoMace", 0)
        .add(new Setting("Distance", 3.0, 1.0, 6.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Min fall height", 1.5, 0.0, 10.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Max fall height", 40, 5, 100, 5).fmt("%.0f m", 1))
        .add(Setting.bool("While falling", true))
        .add(Setting.bool("After charge", true))
        .add(Setting.bool("Swap to mace", true))
        .add(Setting.bool("Return slot", true))
        .add(Setting.bool("Players", true))
        .add(Setting.bool("Mobs", true));
    public static final Module AUTOSWAP = new Module("AutoSwap", 0)
        .add(new Setting("From", 3, SWAP_ITEMS))
        .add(new Setting("To", 1, SWAP_ITEMS))
        .add(new Setting("From name", ""))
        .add(new Setting("To name", ""))
        .add(new Setting("Hand", 0, "Offhand", "Mainhand"))
        .add(Setting.key("Swap key"))
        .add(Setting.bool("Wheel button", false));
    public static final Module TOTEM = new Module("AutoTotem", 0)
        .add(new Setting("Health threshold", 20, 1, 20, 1).fmt("%.0f HP", 1))
        .add(new Setting("Delay", 2, 0, 10, 1).fmt("%.0f t", 1))
        .add(Setting.bool("Not while eating", false));
    public static final Module PEARL = new Module("KeyPearl", 0).on()
        .add(Setting.bool("Switch back", true));
    public static final Module WIND = new Module("KeyWind", 0).on()
        .add(Setting.bool("Switch back", true))
        .add(Setting.bool("Look down", true));
    public static final Module NOFRIEND = new Module("NoFriendDamage", 0);
    public static final Module TRIGGER = new Module("TriggerBot", 0)
        .add(new Setting("Distance", 3.0, 1.0, 6.0, 0.5).fmt("%.1f m", 1))
        .add(new Setting("Charge", 0.95, 0.5, 1.0, 0.01).fmt("%.0f%%", 100))
        .add(new Setting("Delay", 0, 0, 10, 1).fmt("%.0f t", 1))
        .add(Setting.bool("Crits only", false))
        .add(Setting.bool("Players", true))
        .add(Setting.bool("Mobs", true));

    // ---- Movement ----
    public static final Module SPRINT = new Module("AutoSprint", 1);
    public static final Module FLY = new Module("Fly", 1)
        .add(new Setting("Fly speed", 1.0, 0.5, 5.0, 0.1).fmt("%.1fx", 1));
    public static final Module GUIMOVE = new Module("GuiMove", 1)
        .add(Setting.bool("Jump", true))
        .add(Setting.bool("In Ghostline menu", true));
    public static final Module SPEED = new Module("Speed", 1)
        .add(new Setting("Multiplier", 1.15, 1.0, 2.0, 0.01).fmt("%.2fx", 1));

    // ---- Player ----
    public static final Module AUTOTOOL = new Module("AutoTool", 2)
        .add(Setting.bool("Switch back", true));
    public static final Module CHEST = new Module("ChestStealer", 2)
        .add(new Setting("Delay", 1, 0, 10, 1).fmt("%.0f t", 1))
        .add(Setting.bool("Auto close", true));
    public static final Module FRIENDS = new Module("Friends", 2).on()
        .add(new Setting("Click range", 8, 3, 20, 1).fmt("%.0f m", 1));
    public static final Module AUTOWARDEN = new Module("AutoWarden", 2)
        .add(new Setting("Farm point", ""))
        .add(Setting.bool("Set farm here", false))
        .add(new Setting("Leave command", "/home base"))
        .add(new Setting("Return command", "/home warden"))
        .add(new Setting("Player radius", 20, 5, 50, 1).fmt("%.0f m", 1))
        .add(new Setting("Wait time", 10, 3, 120, 1).fmt("%.0f s", 1))
        .add(new Setting("Eat threshold", 15, 1, 20, 1).fmt("%.0f", 1))
        .add(Setting.bool("Auto respawn", true))
        .add(Setting.bool("Look along path", true))
        .add(new Setting("Telegram token", "").secret())
        .add(new Setting("Telegram chat", "").secret());

    // ---- Social: friends, chat and help requests (needs a Ghostline server) ----
    public static final Module FRIENDSHELP = new Module("FriendsHelp", 2)
        .add(new Setting("Server URL", "").secret())                                    // 0 never imported or shared
        .add(new Setting("Pairing code", "").noSave())                                  // 1 one-time, never stored
        .add(new Setting("Status", 0, "Online", "Away", "Busy", "Invisible"))           // 2
        .add(new Setting("Status note", ""))                                            // 3
        .add(new Setting("Visible to", 0, "Friends", "Nobody"))                         // 4
        .add(new Setting("Friend requests", 0, "Everyone", "Nobody"))                   // 5
        .add(Setting.bool("Notify friend online", true))                                // 6
        .add(Setting.bool("Show friend chat", true))                                    // 7
        .add(Setting.key("Help key"))                                                   // 8
        .add(new Setting("Share coordinates", 0, "Never", "Ask each time"))             // 9
        .add(new Setting("Help message", "Need help!"))                                 // 10
        .add(Setting.bool("Intercept /help", false))                                    // 11
        .add(Setting.bool("Friends on HUD", true));                                     // 12

    // ---- Raid Assistant (assist, not autopilot) and Invisibility Helper ----
    public static final Module RAID = new Module("RaidAssistant", 4)
        .add(new Setting("Valuables", "diamond,netherite,totem,elytra,enchanted_golden_apple,shulker_box,ancient_debris,emerald,gold_block,iron_block,beacon")) // 0
        .add(new Setting("Reserve slots", 2, 1, 8, 1).fmt("%.0f", 1))                    // 1
        .add(Setting.bool("Auto take valuables", false))                                 // 2
        .add(new Setting("Take delay", 4, 1, 20, 1).fmt("%.0f t", 1))                    // 3
        .add(new Setting("Tool warning", 15, 5, 50, 5).fmt("%.0f%%", 1))                 // 4
        .add(new Setting("Min totems", 1, 0, 8, 1).fmt("%.0f", 1))                       // 5
        .add(Setting.bool("Auto return", false))                                         // 6
        .add(new Setting("Return at HP", 6, 1, 19, 1).fmt("%.0f HP", 1))                 // 7
        .add(new Setting("Return to", 0, "Second point", "Base"))                        // 8
        .add(Setting.key("Stop key"))                                                    // 9
        .add(Setting.bool("Container hints", true))                                      // 10
        .add(Setting.bool("Log actions", true));                                         // 11
    public static final Module INVIS = new Module("InvisibilityHelper", 3)
        .add(Setting.bool("Own timer", true))                                            // 0
        .add(new Setting("Remind at", 20, 5, 120, 5).fmt("%.0f s", 1))                   // 1
        .add(Setting.bool("Remind on expiry", true))                                     // 2
        .add(new Setting("Item keywords", "invisibility,невидим"))                       // 3
        .add(Setting.bool("Watch nearby", true))                                         // 4
        .add(new Setting("Watch radius", 32, 8, 64, 4).fmt("%.0f m", 1))                 // 5
        .add(Setting.bool("Alert nearby", true))                                         // 6
        .add(Setting.bool("Show on HUD", true));                                         // 7

    // ---- Visuals ----
    public static final Module BRIGHT = new Module("Fullbright", 3);
    public static final Module WAYPOINTS = new Module("Waypoints", 3).on()
        .add(new Setting("Max shown", 4, 1, 8, 1).fmt("%.0f", 1));
    public static final Module VIEW = new Module("ViewModel", 3)
        .add(new Setting("X", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Y", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Z", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Scale", 1.0, 0.3, 2.0, 0.05));

    // ---- Misc ----
    public static final Module PANIC = new Module("Panic", 4).notToggle();

    // ---- Visuals: ESP and weather ----
    public static final Module ESP = new Module("PlayerESP", 3)
        .add(new Setting("Style", 1, "None", "Box", "Corners", "3D", "Filled"))
        .add(Setting.bool("Tracers", false))
        .add(Setting.bool("Arrows", true))
        .add(Setting.bool("Names", true))
        .add(Setting.bool("Health", true))
        .add(Setting.bool("Armor", false))
        .add(new Setting("Distance", 128, 16, 256, 8).fmt("%.0f m", 1))
        .add(new Setting("Color", 0, "Accent", "Red", "White", "Health", "Rainbow"))
        .add(Setting.bool("Mobs", false))
        .add(Setting.bool("Players", true));
    public static final Module WEATHER = new Module("Weather", 3)
        .add(new Setting("Mode", 0, "Clear", "Rain", "Thunder"));

    // ---- Misc: Base Finder and Tree Farm ----
    public static final Module BASEFINDER = new Module("BaseFinder", 4)
        .add(new Setting("Scan radius", 6, 2, 12, 1).fmt("%.0f ch", 1))                 // 0
        .add(new Setting("Vertical range", 24, 8, 64, 4).fmt("%.0f m", 1))              // 1
        .add(new Setting("Scan speed", 3000, 500, 10000, 500).fmt("%.0f/t", 1))            // 2
        .add(Setting.bool("World scanner", true))                                       // 3
        .add(new Setting("Min score", 40, 8, 200, 2).fmt("%.0f", 1))                    // 4
        .add(Setting.bool("Building blocks", true))                                     // 5
        .add(Setting.bool("Functional blocks", true))                                   // 6
        .add(new Setting("Extra blocks", ""))                                           // 7
        .add(Setting.bool("Chest ESP", true))                                           // 8
        .add(new Setting("ESP distance", 64, 16, 128, 4).fmt("%.0f m", 1))              // 9
        .add(Setting.bool("Chests", true))                                              // 10
        .add(Setting.bool("Trapped chests", true))                                      // 11
        .add(Setting.bool("Barrels", true))                                             // 12
        .add(Setting.bool("Shulker boxes", true))                                       // 13
        .add(Setting.bool("Ender chests", false))                                       // 14
        .add(Setting.bool("Workstations", false))                                       // 15
        .add(new Setting("Container threshold", 4, 1, 20, 1).fmt("%.0f", 1))            // 16
        .add(Setting.bool("Notify chat", true))                                         // 17
        .add(Setting.bool("Notify Telegram", false))                                    // 18
        .add(new Setting("Telegram token", "").secret())                                // 19
        .add(new Setting("Telegram chat", "").secret())                                 // 20
        .add(new Setting("Cooldown", 10, 1, 60, 1).fmt("%.0f min", 1))                  // 21
        .add(Setting.bool("Log on HUD", true))                                          // 22
        .add(Setting.bool("Log to file", true))                                         // 23
        .add(Setting.bool("Labels", true));                                             // 24
    public static final Module TREEFARM = new Module("TreeFarm", 4)
        .add(new Setting("Radius", 20, 8, 32, 2).fmt("%.0f m", 1))                      // 0
        .add(new Setting("Vertical range", 8, 4, 16, 1).fmt("%.0f m", 1))               // 1
        .add(new Setting("Preferred tree", 0, "Any tree", "Oak", "Spruce", "Birch", "Jungle", "Acacia", "Dark oak", "Mangrove", "Cherry", "Pale oak")) // 2
        .add(Setting.bool("Oak", true))                                                 // 3
        .add(Setting.bool("Spruce", true))                                              // 4
        .add(Setting.bool("Birch", true))                                               // 5
        .add(Setting.bool("Jungle", true))                                              // 6
        .add(Setting.bool("Acacia", true))                                              // 7
        .add(Setting.bool("Dark oak", true))                                            // 8
        .add(Setting.bool("Mangrove", true))                                            // 9
        .add(Setting.bool("Cherry", true))                                              // 10
        .add(Setting.bool("Pale oak", true))                                            // 11
        .add(Setting.bool("Require axe", true))                                         // 12
        .add(new Setting("Min tool durability", 10, 1, 100, 1).fmt("%.0f", 1))          // 13
        .add(new Setting("Stop at HP", 8, 1, 20, 1).fmt("%.0f HP", 1))                  // 14
        .add(Setting.bool("Stop near players", true))                                   // 15
        .add(new Setting("Player radius", 24, 8, 64, 2).fmt("%.0f m", 1))               // 16
        .add(Setting.bool("Stop on hostile", true))                                     // 17
        .add(new Setting("Stuck timeout", 6, 2, 15, 1).fmt("%.0f s", 1))                // 18
        .add(Setting.bool("Collect drops", true))                                       // 19
        .add(Setting.bool("Telegram on stop", false));                                  // 20

    // ---- Cosmetics ----
    public static final Module TRAIL = new Module("Trail", 8)
        .add(new Setting("Style", 0, "End rod", "Soul fire", "Heart", "Note", "Enchant", "Cloud"))
        .add(new Setting("Density", 2, 1, 5, 1).fmt("%.0f", 1))
        .add(Setting.bool("First person", false));

    public static final Module WINGS = new Module("Wings", 8)
        .add(new Setting("Style", 0, "Angel", "Demon", "Fairy", "Frost"))
        .add(new Setting("Scale", 1.0, 0.6, 2.0, 0.1).fmt("%.1fx", 1))
        .add(new Setting("Density", 3, 1, 6, 1).fmt("%.0f", 1))
        .add(Setting.bool("First person", false));

    public static final List<Module> ALL = List.of(
        AIM, AUTOMACE, AUTOSWAP, TOTEM, PEARL, WIND, NOFRIEND, TRIGGER,
        SPRINT, FLY, GUIMOVE, SPEED,
        AUTOTOOL, CHEST, FRIENDS, AUTOWARDEN,
        BRIGHT, WAYPOINTS, VIEW, ESP, WEATHER,
        BASEFINDER, TREEFARM, FRIENDSHELP, RAID, INVIS,
        PANIC,
        TRAIL, WINGS);

    // ---- Settings-only groups ----
    public static final Module THEME = new Module("Theme", 5)
        .add(new Setting("Preset", 0, Ui.PRESET_NAMES))
        .add(new Setting("Panel opacity", 0.92, 0.5, 1.0, 0.02).fmt("%.0f%%", 100))
        .add(Setting.bool("Background logo", true))
        .add(Setting.bool("Animations", true))
        .add(new Setting("Custom R", 123, 0, 255, 1).fmt("%.0f", 1))
        .add(new Setting("Custom G", 108, 0, 255, 1).fmt("%.0f", 1))
        .add(new Setting("Custom B", 217, 0, 255, 1).fmt("%.0f", 1))
        .add(new Setting("Wallpaper", 1, "None", "Snow", "Aurora", "Embers"));
    public static final Module HUD = new Module("HUD", 6).on()
        .add(Setting.bool("Module list", true))
        .add(Setting.bool("Watermark", true))
        .add(Setting.bool("Coordinates", false))
        .add(Setting.bool("Binds", false))
        .add(Setting.bool("Target", false))
        .add(Setting.bool("Armor", false))
        .add(Setting.bool("Potions", false))
        .add(new Setting("List position", 0, POS))
        .add(new Setting("Watermark position", 1, POS))
        .add(new Setting("Coords position", 3, POS))
        .add(new Setting("Extras position", 2, POS))
        .add(new Setting("Sort", 0, "Length", "A-Z"))
        .add(new Setting("Color", 0, "Accent", "White", "Rainbow"))
        .add(new Setting("Scale", 1.0, 0.7, 1.6, 0.05).fmt("%.2fx", 1))
        .add(new Setting("Opacity", 1.0, 0.3, 1.0, 0.05).fmt("%.0f%%", 100))
        .add(new Setting("Watermark style", 0, "Ghostline", "Compact", "Minimal"))   // 15
        .add(Setting.bool("Show FPS", true))                                          // 16
        .add(Setting.bool("Show version", true))                                      // 17
        .add(Setting.bool("Show ping", false))                                        // 18
        .add(Setting.bool("Show nick", true))                                         // 19
        .add(Setting.bool("Show clock", false))                                       // 20
        .add(Setting.key("Editor key"));                                              // 21
    /** On-screen notifications (toasts): queue, animations, per-source switches. */
    public static final Module NOTIFY = new Module("Notifications", 6).on()
        .add(new Setting("Duration", 4.0, 1.0, 10.0, 0.5).fmt("%.1f s", 1))           // 0
        .add(new Setting("Max visible", 4, 1, 6, 1).fmt("%.0f", 1))                    // 1
        .add(new Setting("Corner", 0, "Top right", "Top left", "Bottom right", "Bottom left")) // 2
        .add(new Setting("Animation", 0, "Slide", "Fade", "None"))                     // 3
        .add(Setting.bool("Modules", true))                                            // 4 module on/off
        .add(Setting.bool("Menu and configs", true))                                   // 5
        .add(Setting.bool("Friends", true))                                            // 6
        .add(Setting.bool("Warnings", true))                                           // 7 raid, invisibility, tree farm, base finder
        .add(Setting.bool("Progress bar", true));                                      // 8
    public static final List<Module> EXTRA = List.of(THEME, HUD, NOTIFY);

    public static int menuBind = org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT;
    public static int lang = 0;               // 0 = English, 1 = Russian
    public static boolean langChosen = false;
    public static boolean panic = false;      // never saved: lasts until game restart
    public static final Set<String> FRIENDS_SET = new LinkedHashSet<>();

    // Module Manager: favorites and sort mode (0 A-Z, 1 enabled first, 2 favorites first)
    public static final Set<String> FAVORITES = new LinkedHashSet<>();
    public static int sortMode = 0;
    public static boolean isFavorite(Module m) { return FAVORITES.contains(m.name); }
    public static void toggleFavorite(Module m) { if (!FAVORITES.remove(m.name)) FAVORITES.add(m.name); save(); }
    private static boolean moduleExists(String n) { for (Module m : ALL) if (m.name.equals(n)) return true; return false; }

    /** Who already uses a key: the menu key, module binds and key settings. */
    public record KeyOwner(String label, Module module, Setting setting, boolean menu) { }

    public static List<KeyOwner> keyOwners(int key, Module exceptModule, Setting exceptSetting, boolean exceptMenu) {
        List<KeyOwner> out = new ArrayList<>();
        if (key <= 0) return out;
        if (menuBind == key && !exceptMenu) out.add(new KeyOwner("Menu", null, null, true));
        for (Module m : ALL) if (m.bind == key && m != exceptModule) out.add(new KeyOwner(Lang.mod(m), m, null, false));
        List<Module> withKeys = new ArrayList<>(ALL);
        withKeys.addAll(EXTRA);
        for (Module m : withKeys)
            for (Setting s : m.settings)
                if (s.isKey && s != exceptSetting && s.i() == key) out.add(new KeyOwner(Lang.mod(m) + ": " + Lang.set(s), m, s, false));
        return out;
    }

    /** key code -> how many Ghostline functions use it (for highlighting duplicates). */
    public static java.util.Map<Integer, Integer> keyUse() {
        java.util.Map<Integer, Integer> use = new java.util.HashMap<>();
        if (menuBind > 0) use.merge(menuBind, 1, Integer::sum);
        List<Module> all = new ArrayList<>(ALL);
        all.addAll(EXTRA);
        for (Module m : all) {
            if (ALL.contains(m) && m.bind > 0) use.merge(m.bind, 1, Integer::sum);
            for (Setting s : m.settings) if (s.isKey && s.i() > 0) use.merge(s.i(), 1, Integer::sum);
        }
        return use;
    }

    /** A saved coordinate shown on the HUD with distance and direction. */
    public static final class Waypoint {
        public final String name;
        public final int x, y, z;
        public Waypoint(String name, int x, int y, int z) { this.name = name; this.x = x; this.y = y; this.z = z; }
    }
    public static final List<Waypoint> WAYPOINTS_LIST = new ArrayList<>();

    public static boolean isFriend(Entity e) {
        return e instanceof Player && FRIENDS_SET.contains(e.getName().getString().toLowerCase(Locale.ROOT));
    }

    private static Path file() {
        SecretStore.init(FabricLoader.getInstance().getConfigDir());
        return FabricLoader.getInstance().getConfigDir().resolve("ghostline.properties");
    }

    private static void put(Properties p, Module m, boolean global) {
        for (Setting s : m.settings) {
            if (s.noSave || (s.secret && !global)) continue;
            String v = s.isText ? s.text : String.valueOf(s.value);
            if (s.secret && s.isText) v = SecretStore.encrypt(v); // tokens are never written as plain text
            p.setProperty(m.name + "." + s.name, v);
        }
    }

    /** Current state as properties. global=true also stores menu key, language, friends and version. */
    public static Properties snapshot(boolean global) {
        Properties p = new Properties();
        if (global) {
            p.setProperty("cfg.version", String.valueOf(VERSION));
            p.setProperty("menu.bind", String.valueOf(menuBind));
            p.setProperty("lang", String.valueOf(lang));
            p.setProperty("lang.chosen", String.valueOf(langChosen));
            p.setProperty("favorites", String.join(",", FAVORITES));
            p.setProperty("sort.mode", String.valueOf(sortMode));
            p.setProperty("hud.layout", HudLayout.serialize());
            p.setProperty("friends", String.join(",", FRIENDS_SET));
            StringBuilder wp = new StringBuilder();
            for (Waypoint w : WAYPOINTS_LIST) {
                if (wp.length() > 0) wp.append(';');
                wp.append(w.name).append('|').append(w.x).append('|').append(w.y).append('|').append(w.z);
            }
            p.setProperty("waypoints", wp.toString());
        }
        for (Module m : ALL) {
            p.setProperty(m.name + ".on", String.valueOf(m.enabled));
            p.setProperty(m.name + ".bind", String.valueOf(m.bind));
            put(p, m, global);
        }
        for (Module m : EXTRA) {
            p.setProperty(m.name + ".on", String.valueOf(m.enabled));
            put(p, m, global);
        }
        return p;
    }

    private static void applySettings(Module m, Properties p, boolean global) {
        for (Setting s : m.settings) {
            if (s.noSave || (s.secret && !global)) continue; // secrets can only come from the main file
            String v = p.getProperty(m.name + "." + s.name);
            if (v == null) continue;
            if (s.isText) s.text = s.secret ? SecretStore.decrypt(v) : v;
            else s.value = Math.max(s.min, Math.min(s.max, Double.parseDouble(v)));
        }
    }

    /** Applies properties; missing keys keep their current values. */
    public static void apply(Properties p, boolean global) {
        if (global) {
            if (p.containsKey("menu.bind")) menuBind = Integer.parseInt(p.getProperty("menu.bind"));
            if (p.containsKey("lang")) lang = Integer.parseInt(p.getProperty("lang"));
            if (p.containsKey("lang.chosen")) langChosen = Boolean.parseBoolean(p.getProperty("lang.chosen"));
            if (p.containsKey("favorites")) {
                FAVORITES.clear();
                for (String f : p.getProperty("favorites", "").split(",")) { String n = f.trim(); if (!n.isEmpty() && moduleExists(n)) FAVORITES.add(n); }
            }
            if (p.containsKey("sort.mode")) {
                try { sortMode = Math.max(0, Math.min(2, Integer.parseInt(p.getProperty("sort.mode").trim()))); } catch (NumberFormatException ignored) { }
            }
            if (p.containsKey("hud.layout")) HudLayout.parse(p.getProperty("hud.layout"));
            if (p.containsKey("friends")) {
                FRIENDS_SET.clear();
                for (String f : p.getProperty("friends", "").split(",")) if (!f.isBlank()) FRIENDS_SET.add(f.trim());
            }
            if (p.containsKey("waypoints")) {
                WAYPOINTS_LIST.clear();
                for (String e : p.getProperty("waypoints", "").split(";")) {
                    String[] f = e.split("\\|");
                    if (f.length != 4) continue;
                    try { WAYPOINTS_LIST.add(new Waypoint(f[0], Integer.parseInt(f[1]), Integer.parseInt(f[2]), Integer.parseInt(f[3]))); }
                    catch (NumberFormatException ignored) { }
                }
            }
        }
        for (Module m : ALL) {
            if (m.toggleable && p.containsKey(m.name + ".on")) m.enabled = Boolean.parseBoolean(p.getProperty(m.name + ".on"));
            if (p.containsKey(m.name + ".bind")) m.bind = Integer.parseInt(p.getProperty(m.name + ".bind"));
            applySettings(m, p, global);
        }
        for (Module m : EXTRA) {
            if (p.containsKey(m.name + ".on")) m.enabled = Boolean.parseBoolean(p.getProperty(m.name + ".on"));
            applySettings(m, p, global);
        }
        RAID.enabled = false;
        TREEFARM.enabled = false; // never start walking and chopping by itself after a restart or a config load
        if (global) {
            // one-time reset of all binds left over from older versions
            int v = 0;
            try { v = Integer.parseInt(p.getProperty("cfg.version", "0")); } catch (NumberFormatException ignored) { }
            if (v < VERSION) clearBinds();
        }
    }

    public static void clearBinds() {
        for (Module m : ALL) {
            m.bind = -1;
            for (Setting s : m.settings) if (s.isKey) s.value = -1;
        }
    }

    private static final Debounce SAVE = new Debounce(400);

    /** Schedules a save. Many changes in a row (dragging a slider) cost one file write, done off the game thread. */
    public static void save() {
        if (panic) return;
        SAVE.mark(System.currentTimeMillis());
    }

    /** Called every client tick. */
    public static void tickSave() {
        if (SAVE.take(System.currentTimeMillis())) writeNow(false);
    }

    /** Writes pending changes immediately (game closing). */
    public static void saveNow() {
        if (panic || !SAVE.takeNow()) return;
        Async.flushIo(2000); // earlier queued writes must not land after this one
        writeNow(true);
    }

    private static void writeNow(boolean sync) {
        final Properties p = snapshot(true); // state is read on the game thread, the file write happens elsewhere
        final Path f = file();
        Runnable w = () -> {
            try (OutputStream o = Files.newOutputStream(f)) { p.store(o, "Ghostline"); } catch (Exception ignored) { }
        };
        if (sync) w.run(); else Async.io(w);
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream i = Files.newInputStream(file())) { p.load(i); }
            apply(p, true);
            Async.io(SecretStore::warm); // derive the encryption key off the game thread
            save();
        } catch (Exception ignored) { }
    }

    public static String keyName(int k) {
        if (k < 0) return Lang.t("ui.none");
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) return "RShift";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT) return "LShift";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCtrl";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_CONTROL) return "LCtrl";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_ALT) return "RAlt";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_ALT) return "LAlt";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_SPACE) return "Space";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_TAB) return "Tab";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER) return "Enter";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_INSERT) return "Insert";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_HOME) return "Home";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_END) return "End";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_PAGE_UP) return "PgUp";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_PAGE_DOWN) return "PgDn";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_UP) return "Up";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN) return "Down";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT) return "Left";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT) return "Right";
        if (k >= org.lwjgl.glfw.GLFW.GLFW_KEY_F1 && k <= org.lwjgl.glfw.GLFW.GLFW_KEY_F12) return "F" + (k - org.lwjgl.glfw.GLFW.GLFW_KEY_F1 + 1);
        String n = org.lwjgl.glfw.GLFW.glfwGetKeyName(k, 0);
        if (n != null) return n.toUpperCase();
        return "Key" + k;
    }
}

package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Invisibility Helper. Only reports what the client really receives:
 *  - the player's own Invisibility effect (with its remaining time), a reliable source for the timer;
 *  - the "invisible" flag the server sends for other players. Players the server does not send at all, or hides with
 *    its own anti-cheat, cannot be seen, and nothing here claims otherwise.
 */
public final class InvisHelper {
    private InvisHelper() { }

    private static final List<String> LINES = new ArrayList<>();
    private static final Map<String, Long> alerted = new HashMap<>();
    private static boolean had, warned, active;
    private static int potions;
    private static int lastCount = -1;

    public static List<String> hudLines() {
        Module m = Config.INVIS;
        if (!m.enabled || m.get(7).i() != 1) return List.of();
        return new ArrayList<>(LINES);
    }

    public static void stop() {
        if (!active) return;
        active = false;
        LINES.clear();
        alerted.clear();
        had = warned = false;
        lastCount = -1;
    }

    private static void bar(LocalPlayer p, String s) { Toasts.warn("Invisibility", s.replaceAll("§.", "")); }

    private static int countItems(LocalPlayer p, String keywords) {
        String[] kw = keywords.toLowerCase(Locale.ROOT).split("[,;]+");
        int n = 0;
        for (int i = 0; i < 37; i++) {
            ItemStack s = i < 36 ? p.getInventory().getItem(i) : p.getOffhandItem();
            if (s.isEmpty()) continue;
            String name = s.getHoverName().getString().toLowerCase(Locale.ROOT);
            for (String k : kw) {
                String t = k.trim();
                if (!t.isEmpty() && name.contains(t)) { n += s.getCount(); break; }
            }
        }
        return n;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.INVIS;
        active = true;
        if (p.tickCount % 10 != 0) return; // twice a second is enough
        LINES.clear();
        long now = System.currentTimeMillis();
        potions = m.get(3).text.isBlank() ? 0 : countItems(p, m.get(3).text);

        MobEffectInstance e = p.getEffect(MobEffects.INVISIBILITY);
        boolean effect = e != null;
        if (m.get(0).i() == 1) {
            if (effect) {
                if (e.isInfiniteDuration()) LINES.add(Lang.t("inv.infinite"));
                else {
                    int secs = (e.getDuration() + 19) / 20;
                    LINES.add(String.format(Lang.t("inv.timer"), secs / 60, secs % 60));
                    int at = m.get(1).i();
                    if (secs <= at && !warned) {
                        warned = true;
                        bar(p, "§e" + String.format(Lang.t("inv.ending"), secs) + (potions > 0 ? " §7(" + String.format(Lang.t("inv.left"), potions) + ")" : ""));
                    }
                    if (secs > at + 5) warned = false;
                }
                List<String> vis = new ArrayList<>();
                for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                    if (!p.getItemBySlot(s).isEmpty()) { vis.add(Lang.t("inv.armor")); break; }
                }
                if (!p.getMainHandItem().isEmpty() || !p.getOffhandItem().isEmpty()) vis.add(Lang.t("inv.hand"));
                if (!vis.isEmpty()) LINES.add(Lang.t("inv.visible") + " " + String.join(", ", vis));
            } else if (p.isInvisible()) {
                LINES.add(Lang.t("inv.unknown"));
            }
            if (had && !effect && m.get(2).i() == 1) {
                bar(p, "§c" + Lang.t("inv.ended") + (potions > 0 ? " §7(" + String.format(Lang.t("inv.left"), potions) + ")" : ""));
            }
            had = effect;
        }
        if (!m.get(3).text.isBlank() && (potions > 0 || effect)) LINES.add(String.format(Lang.t("inv.items"), potions));

        if (m.get(4).i() == 1 && mc.level != null) {
            double r = m.get(5).value;
            int shown = 0;
            for (Player o : mc.level.players()) {
                if (o == p || o.isSpectator() || !o.isInvisible()) continue;
                double d = p.distanceTo(o);
                if (d > r) continue;
                String name = o.getName().getString();
                if (shown++ < 3) LINES.add(Lang.t("inv.nearby") + " " + name + " " + (int) d + "m" + (Config.isFriend(o) ? " (friend)" : ""));
                Long last = alerted.get(name);
                if (m.get(6).i() == 1 && !Config.isFriend(o) && (last == null || now - last > 30_000)) {
                    alerted.put(name, now);
                    p.displayClientMessage(Component.literal("§8[§dGhostline§8] §e" + String.format(Lang.t("inv.alert"), name, (int) d)), false);
                    Toasts.warn("Invisibility", String.format(Lang.t("inv.alert"), name, (int) d));
                }
            }
            if (alerted.size() > 200) alerted.clear();
        }
    }
}

package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Tree Farm: finds trees, walks to them in a straight line, chops the part of the trunk within reach, picks up the logs
 * and repeats. It stops on danger, a missing tool, a full inventory or when it cannot reach anything.
 * Limits: no real pathfinding (obstacles are handled by jumping and giving a tree up when stuck) and only logs within
 * arm's reach from the ground are cut, so tall trunks keep their upper part.
 */
public final class TreeFarm {
    private TreeFarm() { }

    static final Block[] LOGS = {Blocks.OAK_LOG, Blocks.SPRUCE_LOG, Blocks.BIRCH_LOG, Blocks.JUNGLE_LOG, Blocks.ACACIA_LOG,
        Blocks.DARK_OAK_LOG, Blocks.MANGROVE_LOG, Blocks.CHERRY_LOG, Blocks.PALE_OAK_LOG};
    public static final String[] NAMES = {"Oak", "Spruce", "Birch", "Jungle", "Acacia", "Dark oak", "Mangrove", "Cherry", "Pale oak"};

    // ---- statistics of the current run
    public static String status = "";
    public static int total, trees, broken;
    public static final int[] BY_TYPE = new int[9];

    private enum Phase { SEARCH, TREE, COLLECT }

    private static boolean active;
    private static Phase phase = Phase.SEARCH;
    private static BlockPos base, cur;
    private static int baseType;
    private static final Set<Long> bad = new HashSet<>();
    private static int searchTicks, fails, collectTicks, stuck, mineTicks, prevSlot = -1;
    private static int[] lastByType = new int[9];
    private static Vec3 lastPos = Vec3.ZERO;

    private record Found(BlockPos pos, int type) { }

    // ------------------------------------------------------------------ lifecycle

    private static void start(LocalPlayer p) {
        active = true;
        phase = Phase.SEARCH;
        base = cur = null;
        bad.clear();
        searchTicks = fails = collectTicks = stuck = mineTicks = 0;
        total = trees = broken = 0;
        java.util.Arrays.fill(BY_TYPE, 0);
        lastByType = inventoryLogs(p);
        prevSlot = p.getInventory().getSelectedSlot();
        lastPos = p.position();
        status = Lang.t("tf.searching");
    }

    /** Called every tick while the module is on. */
    public static void tick(Minecraft mc, LocalPlayer p) {
        if (mc.gameMode == null || mc.level == null) return;
        Module m = Config.TREEFARM;
        if (!active) start(p);
        if (mc.screen != null) { release(mc); status = Lang.t("tf.paused"); return; }

        updateStats(p);
        String danger = danger(mc, p, m);
        if (danger != null) { stopWith(mc, p, danger); return; }

        switch (phase) {
            case SEARCH -> search(mc, p, m);
            case TREE -> tree(mc, p, m);
            case COLLECT -> collect(mc, p, m);
        }
    }

    /** Called when the module is off or on Panic. Releases keys, restores the slot and prints the summary once. */
    public static void stop(Minecraft mc) {
        if (!active) return;
        active = false;
        release(mc);
        LocalPlayer p = mc.player;
        if (mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        if (p != null) {
            if (prevSlot >= 0) p.getInventory().setSelectedSlot(prevSlot);
            if (total > 0 || trees > 0 || broken > 0) {
                p.displayClientMessage(Component.literal("[Ghostline] TreeFarm: " + summary()), false);
                Toasts.info("TreeFarm", summary());
            }
        }
        status = "";
    }

    public static String summary() {
        StringBuilder sb = new StringBuilder(String.format(Lang.t("tf.summary"), total, trees, broken));
        for (int i = 0; i < BY_TYPE.length; i++) if (BY_TYPE[i] > 0) sb.append(" | ").append(Lang.opt(NAMES[i])).append(' ').append(BY_TYPE[i]);
        return sb.toString();
    }

    private static void stopWith(Minecraft mc, LocalPlayer p, String reason) {
        Module m = Config.TREEFARM;
        status = reason;
        Config.TREEFARM.enabled = false;
        Config.save();
        p.displayClientMessage(Component.literal("[Ghostline] TreeFarm: " + reason), false);
        Toasts.warn("TreeFarm", reason);
        if (m.get(20).i() == 1) {
            Module bf = Config.BASEFINDER;
            Notifier.telegram(bf.get(19).text, bf.get(20).text, "TreeFarm: " + reason + " | " + summary());
        }
        stop(mc);
    }

    private static void release(Minecraft mc) {
        mc.options.keyUp.setDown(false);
        mc.options.keySprint.setDown(false);
        mc.options.keyJump.setDown(false);
    }

    // ------------------------------------------------------------------ inventory and safety

    private static int[] inventoryLogs(LocalPlayer p) {
        int[] n = new int[9];
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.isEmpty()) continue;
            for (int t = 0; t < 9; t++) if (s.is(LOGS[t].asItem())) { n[t] += s.getCount(); break; }
        }
        return n;
    }

    /** Logs that appear in the inventory count as collected wood. */
    private static void updateStats(LocalPlayer p) {
        int[] now = inventoryLogs(p);
        for (int t = 0; t < 9; t++) {
            int d = now[t] - lastByType[t];
            if (d > 0) { BY_TYPE[t] += d; total += d; }
        }
        lastByType = now;
    }

    private static int freeSlots(LocalPlayer p) {
        int n = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getItem(i).isEmpty()) n++;
        return n;
    }

    private static String danger(Minecraft mc, LocalPlayer p, Module m) {
        if (p.isDeadOrDying()) return Lang.t("tf.s.dead");
        if (p.getHealth() <= m.get(14).f()) return Lang.t("tf.s.hp");
        if (p.isInLava() || p.isOnFire()) return Lang.t("tf.s.fire");
        if (p.fallDistance > 3.5) return Lang.t("tf.s.fall");
        if (m.get(17).i() == 1) {
            List<Monster> mobs = mc.level.getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(7.0), e -> e.isAlive());
            if (!mobs.isEmpty()) return Lang.t("tf.s.mob");
        }
        if (m.get(15).i() == 1) {
            double rad = m.get(16).value;
            for (Player o : mc.level.players()) {
                if (o == p || o.isSpectator() || Config.isFriend(o)) continue;
                if (p.distanceTo(o) <= rad) return String.format(Lang.t("tf.s.player"), o.getName().getString());
            }
        }
        if (freeSlots(p) == 0) return Lang.t("tf.s.full");
        return null;
    }

    /** Picks the best hotbar tool for the block. Returns false when a required axe is missing or too worn. */
    private static boolean tool(LocalPlayer p, BlockState st, Module m) {
        boolean require = m.get(12).i() == 1;
        int minDur = m.get(13).i();
        int best = -1;
        float bs = 1.0f;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.isEmpty()) continue;
            if (s.isDamageableItem() && s.getMaxDamage() - s.getDamageValue() < minDur) continue;
            if (require && !s.is(ItemTags.AXES)) continue;
            float sp = s.getDestroySpeed(st);
            if (sp > bs) { bs = sp; best = i; }
        }
        if (best < 0) return !require;
        if (p.getInventory().getSelectedSlot() != best) p.getInventory().setSelectedSlot(best);
        return true;
    }

    // ------------------------------------------------------------------ search

    private static int typeOf(BlockState st) {
        for (int i = 0; i < LOGS.length; i++) if (st.is(LOGS[i])) return i;
        return -1;
    }

    private static boolean hasLeaves(Minecraft mc, BlockPos b) {
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int dy = 2; dy <= 9; dy++)
            for (int dx = -2; dx <= 2; dx++)
                for (int dz = -2; dz <= 2; dz++)
                    if (mc.level.getBlockState(mp.set(b.getX() + dx, b.getY() + dy, b.getZ() + dz)).is(BlockTags.LEAVES)) return true;
        return false;
    }

    /** A tree base is a log of an enabled type standing on dirt, with leaves above it. */
    private static Found findTree(Minecraft mc, LocalPlayer p, Module m) {
        int r = m.get(0).i(), vr = m.get(1).i();
        int pref = m.get(2).i() - 1;
        BlockPos pp = p.blockPosition();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        Found best = null;
        double bestScore = Double.MAX_VALUE;
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                for (int y = -vr; y <= vr; y++) {
                    mp.set(pp.getX() + x, pp.getY() + y, pp.getZ() + z);
                    BlockState st = mc.level.getBlockState(mp);
                    if (!st.is(BlockTags.LOGS)) continue;
                    int t = typeOf(st);
                    if (t < 0 || m.get(3 + t).i() != 1) continue;
                    if (bad.contains(mp.asLong())) continue;
                    if (!mc.level.getBlockState(mp.below()).is(BlockTags.DIRT)) continue;
                    BlockPos fixed = mp.immutable();
                    if (!hasLeaves(mc, fixed)) continue;
                    double score = p.distanceToSqr(fixed.getX() + 0.5, fixed.getY() + 0.5, fixed.getZ() + 0.5) - (t == pref ? 1.0e6 : 0.0);
                    if (score < bestScore) { bestScore = score; best = new Found(fixed, t); }
                }
            }
        }
        return best;
    }

    private static void search(Minecraft mc, LocalPlayer p, Module m) {
        release(mc);
        status = Lang.t("tf.searching");
        if (searchTicks % 20 == 0) {
            Found f = findTree(mc, p, m);
            if (f != null) {
                base = f.pos();
                baseType = f.type();
                phase = Phase.TREE;
                cur = null;
                stuck = mineTicks = searchTicks = 0;
                return;
            }
        }
        if (++searchTicks > 200) stopWith(mc, p, Lang.t("tf.s.notrees"));
    }

    // ------------------------------------------------------------------ chopping

    /** Logs of the tree type around the base that can be reached from the ground, nearest first. */
    private static BlockPos nextLog(Minecraft mc, LocalPlayer p) {
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        List<BlockPos> list = new ArrayList<>();
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                for (int dy = -1; dy <= 5; dy++) {
                    mp.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    if (mc.level.getBlockState(mp).is(LOGS[baseType])) list.add(mp.immutable());
                }
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        Vec3 eye = p.getEyePosition();
        for (BlockPos b : list) {
            double d = eye.distanceToSqr(b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5);
            if (d < bd) { bd = d; best = b; }
        }
        return best;
    }

    private static void lookAt(LocalPlayer p, Vec3 t) {
        Vec3 e = p.getEyePosition();
        double dx = t.x - e.x, dy = t.y - e.y, dz = t.z - e.z;
        p.setYRot((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setXRot(Mth.clamp((float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))), -90f, 90f));
    }

    /** Straight-line walking: sprint, jump over obstacles, give up when the position stops changing. Returns true if stuck too long. */
    private static boolean walk(Minecraft mc, LocalPlayer p, Vec3 goal, Module m) {
        Vec3 e = p.getEyePosition();
        double dx = goal.x - e.x, dz = goal.z - e.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        p.setYRot(yaw);
        p.setXRot(15f);
        // do not walk into lava
        double yr = Math.toRadians(yaw);
        BlockPos ahead = p.blockPosition().offset((int) Math.round(-Math.sin(yr)), 0, (int) Math.round(Math.cos(yr)));
        if (mc.level.getBlockState(ahead).is(Blocks.LAVA) || mc.level.getBlockState(ahead.below()).is(Blocks.LAVA)) {
            stopWith(mc, p, Lang.t("tf.s.lava"));
            return false;
        }
        mc.options.keyUp.setDown(true);
        mc.options.keySprint.setDown(true);
        mc.options.keyJump.setDown(p.horizontalCollision || p.isInWater());
        if (p.tickCount % 20 == 0) {
            if (p.position().distanceToSqr(lastPos) < 0.04) stuck += 20; else stuck = 0;
            lastPos = p.position();
        }
        return stuck > m.get(18).i() * 20;
    }

    private static void giveUp(Minecraft mc, LocalPlayer p) {
        if (base != null) bad.add(base.asLong());
        base = cur = null;
        release(mc);
        mc.gameMode.stopDestroyBlock();
        stuck = 0;
        phase = Phase.SEARCH;
        searchTicks = 0;
        if (++fails >= 4) stopWith(mc, p, Lang.t("tf.s.lost"));
    }

    private static void tree(Minecraft mc, LocalPlayer p, Module m) {
        if (base == null) { phase = Phase.SEARCH; return; }
        if (cur != null && !mc.level.getBlockState(cur).is(LOGS[baseType])) { // the block is gone
            broken++;
            fails = 0;
            cur = null;
            mineTicks = 0;
        }
        if (cur == null) {
            cur = nextLog(mc, p);
            if (cur == null) { // nothing left within reach: tree finished
                trees++;
                bad.add(base.asLong());
                base = null;
                release(mc);
                phase = m.get(19).i() == 1 ? Phase.COLLECT : Phase.SEARCH;
                collectTicks = 0;
                searchTicks = 0;
                stuck = 0;
                return;
            }
        }

        BlockState st = mc.level.getBlockState(cur);
        if (!tool(p, st, m)) { stopWith(mc, p, Lang.t("tf.s.notool")); return; }

        Vec3 eye = p.getEyePosition();
        Vec3 c = Vec3.atCenterOf(cur);
        double dist = eye.distanceTo(c);
        BlockHitResult hit = mc.level.clip(new ClipContext(eye, c, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
        BlockPos aim = cur;
        boolean seen = hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(cur);
        if (!seen) { // leaves or another log in the way: cut that first
            BlockState bs = mc.level.getBlockState(hit.getBlockPos());
            if (bs.is(BlockTags.LEAVES) || bs.is(BlockTags.LOGS)) { aim = hit.getBlockPos(); seen = true; }
        }

        if (dist <= 4.2 && seen) {
            release(mc);
            Vec3 ac = Vec3.atCenterOf(aim);
            lookAt(p, ac);
            Direction face = Direction.getApproximateNearest(eye.x - ac.x, eye.y - ac.y, eye.z - ac.z);
            mc.gameMode.continueDestroyBlock(aim, face);
            p.swing(InteractionHand.MAIN_HAND);
            stuck = 0;
            status = Lang.t("tf.chopping") + " " + Lang.opt(NAMES[baseType]);
            if (++mineTicks > 300) giveUp(mc, p);
        } else {
            status = Lang.t("tf.walking");
            if (walk(mc, p, c, m)) giveUp(mc, p);
        }
    }

    // ------------------------------------------------------------------ pick up drops

    private static void collect(Minecraft mc, LocalPlayer p, Module m) {
        ItemEntity nearest = null;
        double bd = Double.MAX_VALUE;
        for (ItemEntity ie : mc.level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(14.0, 6.0, 14.0),
                e -> e.isAlive() && e.getItem().is(ItemTags.LOGS))) {
            double d = p.distanceToSqr(ie);
            if (d < bd) { bd = d; nearest = ie; }
        }
        if (nearest == null || ++collectTicks > 400) {
            release(mc);
            phase = Phase.SEARCH;
            searchTicks = 0;
            stuck = 0;
            return;
        }
        status = Lang.t("tf.collecting");
        if (walk(mc, p, nearest.position(), m)) { release(mc); phase = Phase.SEARCH; searchTicks = 0; stuck = 0; }
    }
}

package com.ghostline.mod;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Background work, so the game thread never waits for disk or network:
 *  - io(): one ordered thread for small file writes (config, journals);
 *  - net(): a small pool for network requests (Telegram, friends server).
 * Both use daemon threads and are shared, instead of creating a new thread per task.
 */
public final class Async {
    private Async() { }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> daemon(r, "ghostline-io"));
    private static final ExecutorService NET = Executors.newFixedThreadPool(3, r -> daemon(r, "ghostline-net"));

    private static Thread daemon(Runnable r, String name) {
        Thread t = new Thread(r, name);
        t.setDaemon(true);
        return t;
    }

    public static void io(Runnable r) {
        try { IO.execute(guard(r)); } catch (RejectedExecutionException ignored) { }
    }

    public static void net(Runnable r) {
        try { NET.execute(guard(r)); } catch (RejectedExecutionException ignored) { }
    }

    private static Runnable guard(Runnable r) {
        return () -> { try { r.run(); } catch (Throwable ignored) { } };
    }

    /** Waits (up to ms) until everything queued with io() so far has been written. Used when the game closes. */
    public static void flushIo(long ms) {
        java.util.concurrent.CountDownLatch l = new java.util.concurrent.CountDownLatch(1);
        io(l::countDown);
        try { l.await(ms, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}

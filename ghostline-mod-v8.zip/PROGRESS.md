# Ghostline Mega Update - progress

## Part 1 (done in code, NOT built yet)
BaseFinder, TreeFarm, PlayerEsp, Project, Notifier, Visuals (weather), watermark styles (HUD settings 15-20).

## Part 2 (done in code, NOT built yet)
- Config Manager: CfgCodec (strict .cfg format, checksum, schema validation), ConfigIO (export/import, share codes "GL1."),
  SecretStore (AES-GCM for tokens in ghostline.properties), Setting.noSave(); named configs and old share codes are validated too.
- FriendsHelp: server/ghostline-server.js (Node, tested), SocialClient + MiniJson (tested), FriendsHelp (game side, /gl and /ghelp commands).
- RaidAssistant + Bases (tested logic), panel in the Misc > RaidAssistant card, BaseFinder marks opened containers.
- InvisHelper: own effect timer, reminders, item count, players flagged invisible by the server.

## Part 3 (done in code, NOT built yet)
- HUD Editor: HudLayout (positions as screen fractions, scale 0.5-2.0, per-element on/off, tested), HudEditorScreen (drag with snapping, wheel/buttons resize, Tab/arrows/R, live preview), Hud refactored into elements with place()/BOUNDS/preview; opened from menu (HUD page), key (HUD setting "Editor key") or /glhud. Layout saved in ghostline.properties (hud.layout).
- Module Manager: favorites, sort (A-Z / enabled first / favorites first), favorites filter, search by name/setting/description/category with ranking, hotkey conflict check (Ghostline binds + key settings, confirm by pressing again; Minecraft keys reported), duplicate highlighting in the hotkeys panel. Fixed: HUD page now shows the Watermark settings (they were unreachable since Part 1).
- Performance: Async (io + net pools), Debounce (Config.save -> one async write; flush on CLIENT_STOPPING), Perf + /glperf, cached ctx / HUD lists / ESP entity query per tick, adaptive BaseFinder scan budget, FriendsHelp.stop idle exit, no thread per request.
- Notifications: ToastQueue (tested) + Toasts (draw, module on/off watcher, sources), element "notifications" in the HUD; wired to modules, menu/config status, FriendsHelp, Raid, Invisibility, TreeFarm, BaseFinder.
- No Event Bus exists in the project; none was added (Fabric ClientTickEvents is the only event source).

## Tests that really ran (plain Java 21 + Node, no Minecraft): tests/
CfgCodecSecretStoreTest 36/36, BasesTest 20/20, FriendsProtocolTest 45/45 (needs the server running, see header), HudLayoutToastQueueTest 32/32, DebounceAsyncPerfTest 15/15.

## Not verified: anything that touches Minecraft / Fabric APIs (Gradle build was never run in the sandbox).
Likeliest compile risks: hasChunk / getChunk, stopDestroyBlock, setRainLevel/setThunderLevel, getPlayerInfo,
Fabric ClientCommandManager + ClientSendMessageEvents.ALLOW_COMMAND, MobEffectInstance.isInfiniteDuration, ClientLifecycleEvents.CLIENT_STOPPING, InputConstants.Type.KEYSYM.getOrCreate + KeyMapping.saveString (hotkey check), Level.getGameTime, Screen mouse/key event signatures in HudEditorScreen.

## Open for Part 4 (carry-over)
Event Bus (none yet), time of day and particles (Visuals), world-render ESP (Box/Outline/3D in the world), AutoWarden -> Notifier,
animations, Tree Farm full trunk height, friends GUI page (only commands + module settings now), mod-wide Telegram settings reuse.

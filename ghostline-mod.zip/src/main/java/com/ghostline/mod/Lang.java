package com.ghostline.mod;

import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

public class Lang {
    private static final Map<String, String[]> M = new HashMap<>();

    private static void p(String k, String en, String ru) { M.put(k, new String[]{en, ru}); }

    static {
        // modules
        p("mod.Fly", "Fly", "Полёт");
        p("mod.Speed", "Speed", "Скорость");
        p("mod.Fullbright", "Fullbright", "Ночное зрение");
        p("mod.AutoSprint", "AutoSprint", "Авто-бег");
        p("mod.TriggerBot", "TriggerBot", "Триггер-бот");
        p("mod.AimAssist", "AimAssist", "Аим-ассист");
        p("mod.ViewModel", "ViewModel", "Вью-модель");
        p("mod.AutoMace", "AutoMace", "Авто-булава");
        p("mod.AutoSwap 1", "AutoSwap 1", "Авто-свап 1");
        p("mod.AutoSwap 2", "AutoSwap 2", "Авто-свап 2");
        p("mod.AutoSwap 3", "AutoSwap 3", "Авто-свап 3");
        p("mod.AutoTotem", "AutoTotem", "Авто-тотем");
        p("mod.NoFriendDamage", "NoFriendDmg", "Друзья");
        p("mod.Ender Pearl", "Ender Pearl", "Эндер-жемчуг");
        p("mod.Wind Charge", "Wind Charge", "Заряд ветра");
        p("mod.Panic", "PANIC", "ПАНИКА");
        // settings
        p("set.Fly speed", "Fly speed", "Скорость полёта");
        p("set.Multiplier", "Multiplier", "Множитель");
        p("set.Targets", "Targets", "Цели");
        p("set.Min charge", "Min charge", "Мин. заряд удара");
        p("set.Smoothness", "Smoothness", "Плавность");
        p("set.FOV", "FOV", "Угол захвата");
        p("set.Range", "Range", "Дальность");
        p("set.Scale", "Scale", "Размер");
        p("set.Item", "Item", "Предмет");
        p("set.Name contains", "Name contains", "Имя содержит");
        p("set.Hand", "Hand", "Рука");
        p("set.Min fall", "Min fall", "Мин. падение");
        p("set.Switch back", "Switch back", "Вернуть слот");
        p("set.Delay", "Delay (ticks)", "Задержка (тики)");
        p("set.Min health", "Min health (0=always)", "Мин. здоровье (0=всегда)");
        // options
        p("opt.All", "All", "Все");
        p("opt.Mobs", "Mobs", "Мобы");
        p("opt.Players", "Players", "Игроки");
        p("opt.Sword", "Sword", "Меч");
        p("opt.Axe", "Axe", "Топор");
        p("opt.Mace", "Mace", "Булава");
        p("opt.Off", "Off", "Выкл");
        p("opt.On", "On", "Вкл");
        p("opt.Any", "Any (by name)", "Любой (по имени)");
        p("opt.Totem", "Totem", "Тотем");
        p("opt.Head", "Head (sphere)", "Голова (сфера)");
        p("opt.Shield", "Shield", "Щит");
        p("opt.Gapple", "Golden apple", "Золотое яблоко");
        p("opt.Pearl", "Ender pearl", "Эндер-жемчуг");
        p("opt.Firework", "Firework", "Фейерверк");
        p("opt.Crystal", "End crystal", "Кристалл");
        p("opt.Offhand", "Offhand", "Левая рука");
        p("opt.Mainhand", "Mainhand", "Основная рука");
        // tabs
        p("tab.0", "Fight", "Бой");
        p("tab.1", "Move", "Ход");
        p("tab.2", "View", "Вид");
        p("tab.3", "Swap", "Свап");
        p("tab.4", "Misc", "Ещё");
        // ui
        p("ui.on", "ON", "ВКЛ");
        p("ui.off", "OFF", "ВЫКЛ");
        p("ui.close", "Close", "Закрыть");
        p("ui.back", "Back", "Назад");
        p("ui.reset", "Reset", "Сброс");
        p("ui.menu_key", "Menu key", "Клавиша меню");
        p("ui.hint_bind", "Click a bind, then press a key. Backspace = unbind", "Нажми на бинд, затем на клавишу. Backspace = убрать");
        p("ui.friends", "Friends", "Друзья");
        p("ui.language", "Language: English", "Язык: Русский");
        p("ui.singleplayer", "Singleplayer", "Одиночная игра");
        p("ui.multiplayer", "Multiplayer", "Сетевая игра");
        p("ui.options", "Options", "Настройки игры");
        p("ui.quit", "Quit game", "Выйти");
        p("ui.ghost_menu", "Ghostline menu", "Меню Ghostline");
        p("ui.add", "Add", "Добавить");
        p("ui.add_looked", "Add player under crosshair", "Добавить игрока в прицеле");
        p("ui.friend_name", "Nickname", "Ник");
        p("ui.friends_title", "Friends", "Друзья");
        p("ui.none", "None", "Нет");
        p("ui.settings", "settings", "настройки");
        p("ui.choose_lang", "Choose language / Выберите язык", "Choose language / Выберите язык");
    }

    public static String t(String k) { String[] v = M.get(k); return v == null ? k : v[Config.lang == 1 ? 1 : 0]; }
    public static String tOr(String k, String fb) { String[] v = M.get(k); return v == null ? fb : v[Config.lang == 1 ? 1 : 0]; }
    public static Component c(String k) { return Component.literal(t(k)); }
    public static String mod(Module m) { return tOr("mod." + m.name, m.name); }
    public static String set(Setting s) { return tOr("set." + s.name, s.name); }
    public static String opt(String o) { return tOr("opt." + o, o); }
}

package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.ArrayList;
import java.util.Locale;

public class FriendsScreen extends Screen {
    private final Screen parent;
    private EditBox box;

    public FriendsScreen(Screen parent) {
        super(Component.literal("Friends"));
        this.parent = parent;
    }

    private void addFriend(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (n.isEmpty()) return;
        Config.FRIENDS.add(n);
        Config.save();
        rebuildWidgets();
    }

    @Override
    protected void init() {
        int w = 200, x = this.width / 2 - w / 2, y = Math.max(24, this.height / 2 - 100);

        box = new EditBox(this.font, x, y, w - 54, 20, Component.empty());
        box.setMaxLength(16);
        box.setHint(Lang.c("ui.friend_name"));
        addRenderableWidget(box);
        addRenderableWidget(Button.builder(Lang.c("ui.add"), b -> addFriend(box.getValue()))
            .bounds(x + w - 50, y, 50, 20).build());

        addRenderableWidget(Button.builder(Lang.c("ui.add_looked"), b -> {
            HitResult hit = this.minecraft.hitResult;
            if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof Player pl) {
                addFriend(pl.getName().getString());
            }
        }).bounds(x, y + 24, w, 20).build());

        int ly = y + 52, shown = 0;
        for (String name : new ArrayList<>(Config.FRIENDS)) {
            if (shown++ >= 6) break;
            addRenderableWidget(Button.builder(Component.literal(name + "   [x]"), b -> {
                Config.FRIENDS.remove(name);
                Config.save();
                rebuildWidgets();
            }).bounds(x, ly, w, 20).build());
            ly += 22;
        }

        addRenderableWidget(Button.builder(Lang.c("ui.back"), b -> onClose())
            .bounds(x, y + 52 + 6 * 22 + 6, w, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, Lang.t("ui.friends_title"), this.width / 2, 10, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        Config.save();
        this.minecraft.setScreen(parent);
    }
}

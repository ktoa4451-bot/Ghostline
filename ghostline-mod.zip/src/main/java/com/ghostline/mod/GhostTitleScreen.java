package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class GhostTitleScreen extends Screen {
    private final List<Button> buttons = new ArrayList<>();
    private int panelRight;

    public GhostTitleScreen() { super(Component.literal("Ghostline")); }

    private void addBtn(Button b) { buttons.add(b); addWidget(b); }

    @Override
    protected void init() {
        buttons.clear();
        int w = 150, h = 22, gap = 26;
        int x = Math.max(16, this.width / 14);
        int count = 7;
        int y = Math.max(10, this.height / 2 - (count * gap) / 2);
        panelRight = x + w + 16;

        addBtn(Button.builder(Lang.c("ui.singleplayer"), b -> this.minecraft.setScreen(new SelectWorldScreen(this)))
            .bounds(x, y, w, h).build());
        addBtn(Button.builder(Lang.c("ui.multiplayer"), b -> this.minecraft.setScreen(new JoinMultiplayerScreen(this)))
            .bounds(x, y + gap, w, h).build());
        addBtn(Button.builder(Lang.c("ui.options"), b -> this.minecraft.setScreen(new OptionsScreen(this, this.minecraft.options)))
            .bounds(x, y + gap * 2, w, h).build());
        addBtn(Button.builder(Lang.c("ui.ghost_menu"), b -> this.minecraft.setScreen(new MenuScreen()))
            .bounds(x, y + gap * 3, w, h).build());
        addBtn(Button.builder(Lang.c("ui.friends"), b -> this.minecraft.setScreen(new FriendsScreen(this)))
            .bounds(x, y + gap * 4, w, h).build());
        addBtn(Button.builder(Lang.c("ui.language"), b -> {
            Config.lang = Config.lang == 0 ? 1 : 0;
            Config.save();
            rebuildWidgets();
        }).bounds(x, y + gap * 5, w, h).build());
        addBtn(Button.builder(Lang.c("ui.quit"), b -> this.minecraft.stop())
            .bounds(x, y + gap * 6, w, h).build());
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fillGradient(0, 0, this.width, this.height, 0xFF07070D, 0xFF1B1238);
        g.fill(0, 0, panelRight, this.height, 0x66000000);
        g.fill(panelRight, 0, panelRight + 1, this.height, 0xFF5B4FD6);

        int areaW = this.width - panelRight;
        int size = Math.max(64, Math.min(256, Math.min(areaW - 24, this.height - 60)));
        int lx = panelRight + areaW / 2 - size / 2;
        int ly = this.height / 2 - size / 2 - 8;
        g.blit(RenderPipelines.GUI_TEXTURED, SplashScreen.LOGO, lx, ly, 0f, 0f, size, size, 256, 256, 256, 256);
        g.drawCenteredString(this.font, "G H O S T L I N E", panelRight + areaW / 2, ly + size + 6, 0xFFB9B2FF);

        for (Button b : buttons) b.render(g, mouseX, mouseY, delta);
        g.drawString(this.font, "Ghostline 1.0.0  |  Minecraft 1.21.11", 4, this.height - 12, 0xFF777777, false);
    }
}

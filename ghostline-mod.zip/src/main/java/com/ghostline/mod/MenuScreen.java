package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class MenuScreen extends Screen {
    private static final Object MENU = new Object();
    private static int tab = 0;
    private Object listening; // a Module, MENU, or null

    public MenuScreen() { super(Component.literal("Ghostline")); }

    private static Component label(Module m) {
        return Component.literal(Lang.mod(m) + ": " + Lang.t(m.enabled ? "ui.on" : "ui.off"));
    }

    private Component bindLabel(Object target, int key) {
        return Component.literal(listening == target ? "> ... <" : Config.keyName(key));
    }

    @Override
    protected void init() {
        int w1 = 116, w2 = 56, w3 = 20, gap = 4, rowH = 22;
        int totalW = w1 + w2 + w3 + gap * 2;
        int x = this.width / 2 - totalW / 2;
        int y0 = Math.max(6, (this.height - 250) / 2);

        // tabs
        int tw = 36;
        for (int i = 0; i < 5; i++) {
            final int ti = i;
            Button tb = Button.builder(Lang.c("tab." + i), b -> { tab = ti; rebuildWidgets(); })
                .bounds(x + 2 + i * (tw + gap), y0, tw, 20).build();
            tb.active = tab != i;
            addRenderableWidget(tb);
        }

        int y = y0 + 26;
        for (Module m : Config.ALL) {
            if (m.category != tab) continue;
            boolean isAction = m.action != null;

            Button main = Button.builder(isAction ? Component.literal(Lang.mod(m)) : label(m), b -> {
                if (m.action != null) {
                    if (m == Config.PANIC) CheatMod.panic(this.minecraft);
                    return;
                }
                m.enabled = !m.enabled;
                Config.save();
                b.setMessage(label(m));
            }).bounds(x, y, w1, 20).build();
            main.active = !isAction || m == Config.PANIC;
            addRenderableWidget(main);

            addRenderableWidget(Button.builder(bindLabel(m, m.bind), b -> {
                listening = m; rebuildWidgets();
            }).bounds(x + w1 + gap, y, w2, 20).build());

            boolean hasSettings = !m.settings.isEmpty() || m == Config.NOFRIEND;
            Button gear = Button.builder(Component.literal(hasSettings ? ">" : "-"), b -> {
                this.minecraft.setScreen(m == Config.NOFRIEND ? new FriendsScreen(this) : new SettingsScreen(this, m));
            }).bounds(x + w1 + w2 + gap * 2, y, w3, 20).build();
            gear.active = hasSettings;
            addRenderableWidget(gear);
            y += rowH;
        }

        int by = y0 + 26 + 5 * rowH + 4;
        int half = (totalW - gap) / 2;
        addRenderableWidget(Button.builder(Lang.c("ui.friends"), b -> this.minecraft.setScreen(new FriendsScreen(this)))
            .bounds(x, by, half, 20).build());
        addRenderableWidget(Button.builder(Lang.c("ui.language"), b -> {
            Config.lang = Config.lang == 0 ? 1 : 0;
            Config.save();
            rebuildWidgets();
        }).bounds(x + half + gap, by, half, 20).build());

        addRenderableWidget(Button.builder(
            Component.literal(Lang.t("ui.menu_key") + ": " + (listening == MENU ? "> ... <" : Config.keyName(Config.menuBind))), b -> {
                listening = MENU; rebuildWidgets();
            }).bounds(x, by + 24, totalW, 20).build());

        addRenderableWidget(Button.builder(Lang.c("ui.close"), b -> onClose())
            .bounds(x, by + 48, totalW, 20).build());
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                int v = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
                if (listening == MENU) { if (v > 0) Config.menuBind = v; }
                else ((Module) listening).bind = v;
                Config.save();
            }
            listening = null;
            rebuildWidgets();
            return true;
        }
        if (key == Config.menuBind) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, Lang.t("ui.hint_bind"), this.width / 2, this.height - 12, 0xFFAAAAAA);
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }
}

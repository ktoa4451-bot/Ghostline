package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class LanguageScreen extends Screen {
    public LanguageScreen() { super(Component.literal("Language")); }

    private void choose(int lang) {
        Config.lang = lang;
        Config.langChosen = true;
        Config.save();
        this.minecraft.setScreen(new GhostTitleScreen());
    }

    @Override
    protected void init() {
        int w = 160, x = this.width / 2 - w / 2, y = this.height / 2 - 24;
        addRenderableWidget(Button.builder(Component.literal("English"), b -> choose(0)).bounds(x, y, w, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Русский"), b -> choose(1)).bounds(x, y + 26, w, 20).build());
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, Lang.t("ui.choose_lang"), this.width / 2, this.height / 2 - 50, 0xFFFFFFFF);
    }
}

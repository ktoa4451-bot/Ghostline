package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

public class Config {
    public static final String[] TARGETS = {"All", "Mobs", "Players"};
    private static final String[] OFFON = {"Off", "On"};

    // ---- Combat (0) ----
    public static final Module TRIGGER = new Module("TriggerBot", 0)
        .add(new Setting("Targets", 0, TARGETS))
        .add(new Setting("Min charge", 0.95, 0.5, 1.0, 0.01));
    public static final Module AIM = new Module("AimAssist", 0)
        .add(new Setting("Targets", 0, TARGETS))
        .add(new Setting("Smoothness", 0.15, 0.02, 0.5, 0.01))
        .add(new Setting("FOV", 70, 20, 180, 5))
        .add(new Setting("Range", 6.0, 2.0, 6.0, 0.5));
    public static final Module AUTOMACE = new Module("AutoMace", 0)
        .add(new Setting("Min fall", 1.5, 0.0, 10.0, 0.5))
        .add(new Setting("Switch back", 0, OFFON));
    public static final Module NOFRIEND = new Module("NoFriendDamage", 0);

    // ---- Movement (1) ----
    public static final Module FLY = new Module("Fly", 1)
        .add(new Setting("Fly speed", 1.0, 0.5, 5.0, 0.1));
    public static final Module SPEED = new Module("Speed", 1)
        .add(new Setting("Multiplier", 1.15, 1.0, 2.0, 0.01));
    public static final Module SPRINT = new Module("AutoSprint", 1);

    // ---- Visual (2) ----
    public static final Module BRIGHT = new Module("Fullbright", 2);
    public static final Module VIEW = new Module("ViewModel", 2)
        .add(new Setting("X", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Y", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Z", 0.0, -1.0, 1.0, 0.05))
        .add(new Setting("Scale", 1.0, 0.3, 2.0, 0.05));

    // ---- Swap (3): bind a key, it moves the chosen item into your hand ----
    public static final String[] SWAP_ITEMS = {"Any", "Totem", "Head", "Shield", "Gapple", "Pearl", "Firework", "Crystal"};
    private static final String[] HANDS = {"Offhand", "Mainhand"};
    public static final Module SWAP1 = new Module("AutoSwap 1", 3)
        .add(new Setting("Item", 1, SWAP_ITEMS)).add(new Setting("Name contains", "")).add(new Setting("Hand", 0, HANDS));
    public static final Module SWAP2 = new Module("AutoSwap 2", 3)
        .add(new Setting("Item", 2, SWAP_ITEMS)).add(new Setting("Name contains", "")).add(new Setting("Hand", 0, HANDS));
    public static final Module SWAP3 = new Module("AutoSwap 3", 3)
        .add(new Setting("Item", 4, SWAP_ITEMS)).add(new Setting("Name contains", "")).add(new Setting("Hand", 0, HANDS));

    // ---- Misc (4) ----
    public static final Module TOTEM = new Module("AutoTotem", 4)
        .add(new Setting("Delay", 2, 0, 10, 1))
        .add(new Setting("Min health", 0, 0, 20, 1));
    public static final Module PEARL = new Module("Ender Pearl", 4).key(GLFW.GLFW_KEY_B)
        .add(new Setting("Switch back", 1, OFFON));
    public static final Module WIND = new Module("Wind Charge", 4).key(GLFW.GLFW_KEY_V)
        .add(new Setting("Switch back", 1, OFFON));
    public static final Module PANIC = new Module("Panic", 4);

    public static final List<Module> ALL = List.of(
        TRIGGER, AIM, AUTOMACE, NOFRIEND,
        FLY, SPEED, SPRINT,
        BRIGHT, VIEW,
        SWAP1, SWAP2, SWAP3,
        TOTEM, PEARL, WIND, PANIC);

    public static int menuBind = GLFW.GLFW_KEY_RIGHT_SHIFT;
    public static int lang = 0;               // 0 = English, 1 = Russian
    public static boolean langChosen = false;
    public static boolean panic = false;      // never saved: lasts until game restart
    public static final Set<String> FRIENDS = new LinkedHashSet<>();

    public static boolean isFriend(Entity e) {
        return e instanceof Player && FRIENDS.contains(e.getName().getString().toLowerCase(Locale.ROOT));
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ghostline.properties");
    }

    public static void save() {
        if (panic) return;
        try {
            Properties p = new Properties();
            p.setProperty("menu.bind", String.valueOf(menuBind));
            p.setProperty("lang", String.valueOf(lang));
            p.setProperty("lang.chosen", String.valueOf(langChosen));
            p.setProperty("friends", String.join(",", FRIENDS));
            for (Module m : ALL) {
                p.setProperty(m.name + ".on", String.valueOf(m.enabled));
                p.setProperty(m.name + ".bind", String.valueOf(m.bind));
                for (Setting s : m.settings) p.setProperty(m.name + "." + s.name, s.isText ? s.text : String.valueOf(s.value));
            }
            try (OutputStream o = Files.newOutputStream(file())) { p.store(o, "Ghostline"); }
        } catch (Exception ignored) { }
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream i = Files.newInputStream(file())) { p.load(i); }
            menuBind = Integer.parseInt(p.getProperty("menu.bind", String.valueOf(menuBind)));
            lang = Integer.parseInt(p.getProperty("lang", "0"));
            langChosen = Boolean.parseBoolean(p.getProperty("lang.chosen", "false"));
            FRIENDS.clear();
            for (String f : p.getProperty("friends", "").split(",")) if (!f.isBlank()) FRIENDS.add(f.trim());
            for (Module m : ALL) {
                m.enabled = m.action == null && Boolean.parseBoolean(p.getProperty(m.name + ".on", "false"));
                m.bind = Integer.parseInt(p.getProperty(m.name + ".bind", String.valueOf(m.defBind)));
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v != null) { if (s.isText) s.text = v; else s.value = Math.max(s.min, Math.min(s.max, Double.parseDouble(v))); }
                }
            }
        } catch (Exception ignored) { }
    }

    public static String keyName(int k) {
        if (k < 0) return Lang.t("ui.none");
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RShift";
        if (k == GLFW.GLFW_KEY_LEFT_SHIFT) return "LShift";
        if (k == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCtrl";
        if (k == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCtrl";
        if (k == GLFW.GLFW_KEY_RIGHT_ALT) return "RAlt";
        if (k == GLFW.GLFW_KEY_LEFT_ALT) return "LAlt";
        if (k == GLFW.GLFW_KEY_SPACE) return "Space";
        if (k == GLFW.GLFW_KEY_TAB) return "Tab";
        if (k == GLFW.GLFW_KEY_ENTER) return "Enter";
        if (k == GLFW.GLFW_KEY_INSERT) return "Insert";
        if (k == GLFW.GLFW_KEY_HOME) return "Home";
        if (k == GLFW.GLFW_KEY_END) return "End";
        if (k == GLFW.GLFW_KEY_PAGE_UP) return "PgUp";
        if (k == GLFW.GLFW_KEY_PAGE_DOWN) return "PgDn";
        if (k == GLFW.GLFW_KEY_UP) return "Up";
        if (k == GLFW.GLFW_KEY_DOWN) return "Down";
        if (k == GLFW.GLFW_KEY_LEFT) return "Left";
        if (k == GLFW.GLFW_KEY_RIGHT) return "Right";
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        String n = GLFW.glfwGetKeyName(k, 0);
        if (n != null) return n.toUpperCase();
        return "Key" + k;
    }
}

package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

public class SettingsScreen extends Screen {
    private final Screen parent;
    private final Module module;

    public SettingsScreen(Screen parent, Module module) {
        super(Component.literal(Lang.mod(module) + " (" + Lang.t("ui.settings") + ")"));
        this.parent = parent;
        this.module = module;
    }

    private static class SettingSlider extends AbstractSliderButton {
        private final Setting s;

        SettingSlider(int x, int y, int w, int h, Setting s) {
            super(x, y, w, h, Component.empty(), (s.value - s.min) / (s.max - s.min));
            this.s = s;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            if (s == null) return;
            setMessage(Component.literal(Lang.set(s) + ": " + s.display()));
        }

        @Override
        protected void applyValue() {
            double v = s.min + this.value * (s.max - s.min);
            v = Math.round(v / s.step) * s.step;
            s.value = Mth.clamp(v, s.min, s.max);
        }
    }

    @Override
    protected void init() {
        int w = 220, x = this.width / 2 - w / 2, y = this.height / 2 - (module.settings.size() * 24) / 2 - 10;
        for (Setting s : module.settings) {
            if (s.isText) {
                EditBox eb = new EditBox(this.font, x, y, w, 20, Component.empty());
                eb.setMaxLength(32);
                eb.setHint(Component.literal(Lang.set(s)));
                eb.setValue(s.text);
                eb.setResponder(v -> s.text = v);
                addRenderableWidget(eb);
            } else if (s.options != null) {
                addRenderableWidget(Button.builder(Component.literal(Lang.set(s) + ": " + s.display()), b -> {
                    s.value = (s.i() + 1) % s.options.length;
                    b.setMessage(Component.literal(Lang.set(s) + ": " + s.display()));
                }).bounds(x, y, w, 20).build());
            } else {
                addRenderableWidget(new SettingSlider(x, y, w, 20, s));
            }
            y += 24;
        }
        addRenderableWidget(Button.builder(Lang.c("ui.reset"), b -> {
            for (Setting s : module.settings) s.reset();
            rebuildWidgets();
        }).bounds(x, y + 6, 108, 20).build());
        addRenderableWidget(Button.builder(Lang.c("ui.back"), b -> onClose())
            .bounds(x + 112, y + 6, 108, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        Config.save();
        this.minecraft.setScreen(parent);
    }
}
